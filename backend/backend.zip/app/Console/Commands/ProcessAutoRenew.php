<?php

namespace App\Console\Commands;

use App\Models\Subscription;
use App\Services\NotificationService;
use App\Services\SubscriptionService;
use Illuminate\Console\Command;

/**
 * 处理开启了 auto_renew 的订阅：在到期前 24h 内自动扣费续费。
 *
 * 运行：每天 02:00 UTC+8（由 routes/console.php 注册）
 *
 * 逻辑：
 *   1. 扫描 auto_renew=1 && status='active' && 在未来 24h 内到期
 *   2. 每条尝试用当前价 + duration 续费一个周期
 *   3. 余额不足 → 触发 customer_low_balance 通知
 */
class ProcessAutoRenew extends Command
{
    protected $signature = 'subscriptions:auto-renew {--dry : 试运行}';
    protected $description = '扫描并处理开启了自动续费的订阅';

    public function handle(SubscriptionService $subService, NotificationService $notifier): int
    {
        $dry = (bool) $this->option('dry');

        $subs = Subscription::with('customer')
            ->where('auto_renew', 1)
            ->where('status', 'active')
            ->where('expires_at', '>', now())
            ->where('expires_at', '<=', now()->addDay())
            ->get();

        if ($subs->isEmpty()) {
            $this->info('✓ 无需自动续费的订阅');
            return self::SUCCESS;
        }

        $this->info("发现 {$subs->count()} 条待自动续费的订阅");

        $success = 0;
        $failed = 0;

        foreach ($subs as $sub) {
            $customerName = $sub->customer?->customer_name ?? '?';
            try {
                if ($dry) {
                    $this->line("  [DRY] sub#{$sub->id} 客户={$customerName} 价格=¥{$sub->price}");
                    continue;
                }

                $subService->renewOne($sub, [
                    'duration' => $sub->duration ?: 1,
                    'unit' => $sub->unit ?: 3,
                    'price' => (float) $sub->price,
                    'auto_renew_triggered' => true,
                ], null);

                $this->info("  ✓ sub#{$sub->id} 客户={$customerName} 已续费 ¥{$sub->price}");
                $success++;
            } catch (\Throwable $e) {
                $this->warn("  ✗ sub#{$sub->id} 客户={$customerName} 失败: {$e->getMessage()}");
                $failed++;

                // 余额不足 → 派发低余额通知
                if (str_contains($e->getMessage(), '余额不足')) {
                    $notifier->dispatch('customer_low_balance', [
                        'title' => '⚠️ 自动续费失败（余额不足）',
                        'content' => sprintf(
                            "客户：**%s**\n\n订阅：#%d\n\n当前余额：¥%.2f\n\n续费所需：¥%.2f\n\n订阅将在 24 小时内到期，请尽快充值。",
                            $customerName,
                            $sub->id,
                            (float) ($sub->customer?->balance ?? 0),
                            (float) $sub->price
                        ),
                        'related_type' => 'Subscription',
                        'related_id' => $sub->id,
                        'dedup_key' => "auto_renew_fail_{$sub->id}_" . now()->format('Ymd'),
                    ]);
                }
            }
        }

        $this->newLine();
        $this->info("完成：成功 {$success} 条，失败 {$failed} 条");
        return self::SUCCESS;
    }
}
