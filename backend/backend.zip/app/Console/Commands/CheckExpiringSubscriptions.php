<?php

namespace App\Console\Commands;

use App\Models\Customer;
use App\Models\Subscription;
use App\Models\WebhookConfig;
use App\Services\NotificationService;
use Illuminate\Console\Command;

/**
 * 扫描订阅到期情况，按各 webhook 配置的"提前天数"派发提醒。
 *
 * 建议在 Laravel Scheduler / Cron 每天 09:00 运行一次：
 *   php artisan subscriptions:check-expiring
 *
 * 逻辑：
 *   1. 收集所有活跃 webhook 订阅了 subscription_expiring 的配置
 *   2. 合并得到所有要检查的"提前天数集合"
 *   3. 对每个天数 N：查出 N 天后到期的订阅（0点~23:59 范围），触发事件
 *   4. 同时派发 subscription_expired 事件（今日已过期的）
 *   5. 检查 customer_low_balance（余额 < 阈值）
 */
class CheckExpiringSubscriptions extends Command
{
    protected $signature = 'subscriptions:check-expiring {--dry : 试运行，不实际发送}';

    protected $description = '扫描订阅到期 / 客户余额状态，向各 webhook 派发通知';

    public function handle(NotificationService $notifier): int
    {
        $dry = (bool) $this->option('dry');

        // 1. 收集提前天数
        $webhooks = WebhookConfig::where('is_active', 1)->get();
        $allDays = [];
        $hasExpired = false;
        $hasLowBalance = false;
        $balanceThreshold = 50.0;

        foreach ($webhooks as $w) {
            $events = $w->events ?? [];
            $expiring = $events['subscription_expiring'] ?? null;
            if ($expiring && !empty($expiring['enabled'])) {
                foreach (($expiring['days'] ?? [7, 3, 1]) as $d) {
                    $allDays[] = (int) $d;
                }
            }
            if (!empty($events['subscription_expired']['enabled'])) {
                $hasExpired = true;
            }
            if (!empty($events['customer_low_balance']['enabled'])) {
                $hasLowBalance = true;
                $t = $events['customer_low_balance']['threshold'] ?? 50;
                $balanceThreshold = max($balanceThreshold, (float) $t);
            }
        }

        $allDays = array_unique($allDays);
        sort($allDays);

        // 2. 过期提醒
        foreach ($allDays as $days) {
            $target = now()->addDays($days)->startOfDay();
            $targetEnd = now()->addDays($days)->endOfDay();

            $subs = Subscription::with(['customer:id,customer_name,sales_person', 'proxyIp:id,asset_name,ip_address,country_name,source_name'])
                ->where('status', 'active')
                ->whereBetween('expires_at', [$target, $targetEnd])
                ->get();

            $this->line("提前 {$days} 天：找到 {$subs->count()} 条待提醒");

            foreach ($subs as $sub) {
                $content = $this->formatExpiringContent($sub, $days);
                if ($dry) {
                    $this->line("  [DRY] sub#{$sub->id} 客户={$sub->customer?->customer_name}");
                    continue;
                }
                $notifier->dispatch('subscription_expiring', [
                    'title' => "⏰ IP即将到期（{$days}天）",
                    'content' => $content,
                    'related_type' => 'Subscription',
                    'related_id' => $sub->id,
                    'dedup_key' => "sub_expiring_{$sub->id}_{$days}d",
                ]);
            }
        }

        // 3. 已过期
        if ($hasExpired) {
            $todayStart = now()->startOfDay();
            $todayEnd = now()->endOfDay();
            $expired = Subscription::with(['customer:id,customer_name', 'proxyIp:id,asset_name,ip_address'])
                ->where('status', 'active')
                ->whereBetween('expires_at', [$todayStart, $todayEnd])
                ->where('expires_at', '<', now())
                ->get();

            $this->line("今日已过期：{$expired->count()} 条");
            foreach ($expired as $sub) {
                if ($dry) continue;
                $notifier->dispatch('subscription_expired', [
                    'title' => '❌ 订阅已到期',
                    'content' => "客户：**{$sub->customer?->customer_name}**\n\n"
                        . "资产：{$sub->proxyIp?->asset_name}\n\n"
                        . "到期时间：{$sub->expires_at}",
                    'related_type' => 'Subscription',
                    'related_id' => $sub->id,
                    'dedup_key' => "sub_expired_{$sub->id}",
                ]);
            }
        }

        // 4. 低余额
        if ($hasLowBalance) {
            $lowBalanceCustomers = Customer::where('status', 1)
                ->where('balance', '<', $balanceThreshold)
                ->where('balance', '>=', 0)
                ->get();

            $this->line("低余额客户（< {$balanceThreshold}）：{$lowBalanceCustomers->count()} 条");
            foreach ($lowBalanceCustomers as $c) {
                if ($dry) continue;
                $notifier->dispatch('customer_low_balance', [
                    'title' => '💰 客户余额不足',
                    'content' => "客户：**{$c->customer_name}**\n\n"
                        . "当前余额：<font color=\"warning\">¥" . number_format($c->balance, 2) . "</font>\n\n"
                        . "业务归属：{$c->sales_person}",
                    'related_type' => 'Customer',
                    'related_id' => $c->id,
                    'dedup_key' => "low_balance_{$c->id}_" . now()->format('Ymd'),
                ]);
            }
        }

        $this->info('✓ 检查完成' . ($dry ? '（试运行）' : ''));
        return self::SUCCESS;
    }

    private function formatExpiringContent(Subscription $sub, int $days): string
    {
        $customer = $sub->customer;
        $ip = $sub->proxyIp;

        return sprintf(
            "客户：**%s**\n\n资产：%s\n\nIP：`%s`\n\n地区：%s\n\nIP归属：%s\n\n"
            . "到期时间：<font color=\"warning\">%s</font>\n\n"
            . "剩余：<font color=\"warning\">%d 天</font>\n\n"
            . "业务归属：%s",
            $customer?->customer_name ?? '-',
            $ip?->asset_name ?? '-',
            $ip?->ip_address ?? '-',
            $ip?->country_name ?? '-',
            $ip?->source_name ?? '-',
            $sub->expires_at?->format('Y-m-d') ?? '-',
            $days,
            $customer?->sales_person ?? '-'
        );
    }
}
