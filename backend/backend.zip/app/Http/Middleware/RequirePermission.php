<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

/**
 * 用法: ->middleware('perm:customer.view')
 * 超级管理员自动放行
 */
class RequirePermission
{
    public function handle(Request $request, Closure $next, string $permission)
    {
        $user = $request->user();

        if (!$user) {
            return response()->json(['success' => false, 'message' => '未登录'], 401);
        }

        // 超级管理员放行
        if ($user->hasRole('super_admin')) {
            return $next($request);
        }

        if (!$user->can($permission)) {
            return response()->json([
                'success' => false,
                'message' => "无权限: {$permission}",
            ], 403);
        }

        return $next($request);
    }
}
