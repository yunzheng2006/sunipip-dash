<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\IpAssignmentLog;
use App\Models\ProxyIp;
use App\Models\Subscription;
use App\Models\Transaction;
use Illuminate\Http\JsonResponse;

class DashboardController extends Controller
{
    public function stats(): JsonResponse
    {
        return $this->success([
            'total_customers'      => Customer::count(),
            'total_ips'            => ProxyIp::count(),
            'available_ips'        => ProxyIp::where('status', 'available')->count(),
            'assigned_ips'         => ProxyIp::where('status', 'assigned')->count(),
            'active_subscriptions' => Subscription::where('status', 'active')->count(),
            'expiring_soon'        => Subscription::expiringSoon(7)->count(),
            'total_revenue'        => (float) Transaction::where('type', 'topup')->sum('amount'),
        ]);
    }

    public function expiring(): JsonResponse
    {
        $subscriptions = Subscription::with(['customer', 'proxyIp'])
            ->expiringSoon(7)
            ->orderBy('expires_at')
            ->get();

        return $this->success($subscriptions);
    }

    public function recent(): JsonResponse
    {
        $logs = IpAssignmentLog::with(['proxyIp', 'customer', 'operator'])
            ->latest('created_at')
            ->limit(20)
            ->get();

        return $this->success($logs);
    }
}
