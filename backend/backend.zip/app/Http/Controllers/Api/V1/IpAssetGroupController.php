<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\IpAssetGroup;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Spatie\QueryBuilder\AllowedFilter;
use Spatie\QueryBuilder\QueryBuilder;

class IpAssetGroupController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $groups = QueryBuilder::for(IpAssetGroup::class)
            ->allowedFilters([
                AllowedFilter::exact('source_type'),
                AllowedFilter::partial('source_name'),
                AllowedFilter::exact('country_code'),
            ])
            ->allowedSorts(['id', 'name', 'source_type', 'created_at'])
            ->defaultSort('-id')
            ->paginate($request->input('per_page', 15));

        return $this->paginated($groups);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name'         => 'required|string|max:100',
            'source_type'  => 'required|string|max:50',
            'source_name'  => 'required|string|max:100',
            'country_code' => 'nullable|string|max:10',
            'country_name' => 'nullable|string|max:100',
            'city'         => 'nullable|string|max:100',
            'description'  => 'nullable|string|max:500',
            'api_config'   => 'nullable|array',
            'status'       => 'nullable|integer|in:0,1',
        ]);

        $data['created_by'] = $request->user()?->id;

        $group = IpAssetGroup::create($data);

        return $this->success($group, '资产组创建成功');
    }

    public function show(IpAssetGroup $ipAssetGroup): JsonResponse
    {
        $ipAssetGroup->loadCount([
            'proxyIps',
            'proxyIps as available_ips_count' => function ($query) {
                $query->where('status', 'available');
            },
        ]);

        return $this->success($ipAssetGroup);
    }

    public function update(Request $request, IpAssetGroup $ipAssetGroup): JsonResponse
    {
        $data = $request->validate([
            'name'         => 'sometimes|string|max:100',
            'source_type'  => 'sometimes|string|max:50',
            'source_name'  => 'sometimes|string|max:100',
            'country_code' => 'nullable|string|max:10',
            'country_name' => 'nullable|string|max:100',
            'city'         => 'nullable|string|max:100',
            'description'  => 'nullable|string|max:500',
            'api_config'   => 'nullable|array',
            'status'       => 'nullable|integer|in:0,1',
        ]);

        $ipAssetGroup->update($data);

        return $this->success($ipAssetGroup, '资产组更新成功');
    }

    public function destroy(IpAssetGroup $ipAssetGroup): JsonResponse
    {
        $ipAssetGroup->delete();

        return $this->success(null, '资产组已删除');
    }

    // 不分页，下拉选择用
    public function all(): JsonResponse
    {
        $groups = IpAssetGroup::where('status', 1)
            ->select('id', 'name', 'source_type', 'source_name', 'country_code', 'country_name', 'city')
            ->get();

        return $this->success($groups);
    }
}
