<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\IpAssignmentLog;
use App\Models\IpImportLog;
use App\Models\ProxyIp;
use App\Models\Subscription;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Spatie\QueryBuilder\AllowedFilter;
use Spatie\QueryBuilder\QueryBuilder;

class ProxyIpController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = QueryBuilder::for(ProxyIp::class)
            ->allowedFilters([
                AllowedFilter::exact('status'),
                AllowedFilter::exact('country_code'),
                AllowedFilter::exact('source_name'),
                AllowedFilter::exact('asset_group_id'),
                AllowedFilter::exact('ip_group_id'),
                AllowedFilter::exact('assigned_customer_id'),
                AllowedFilter::exact('nature'),
                AllowedFilter::exact('ip_type'),
                AllowedFilter::partial('asset_name'),
                AllowedFilter::partial('ip_address'),
                AllowedFilter::partial('country_name'),
                AllowedFilter::callback('customer_name', function ($q, $value) {
                    $q->whereHas('assignedCustomer', fn($c) => $c->where('customer_name', 'like', "%{$value}%"));
                }),
                AllowedFilter::callback('date_from', fn($q, $v) => $q->where('created_at', '>=', $v)),
                AllowedFilter::callback('date_to', fn($q, $v) => $q->where('created_at', '<=', $v . ' 23:59:59')),
                AllowedFilter::callback('expires_from', fn($q, $v) => $q->where('upstream_expires_at', '>=', $v)),
                AllowedFilter::callback('expires_to', fn($q, $v) => $q->where('upstream_expires_at', '<=', $v . ' 23:59:59')),
            ])
            ->with([
                'assetGroup:id,name,source_name',
                'ipGroup:id,name',
                'assignedCustomer:id,customer_name,sales_person',
                'activeSubscription.forwardRule.deviceGroup:id,name,custom_connect_host,original_connect_host',
            ])
            ->allowedSorts(['id', 'ip_address', 'status', 'country_code', 'country_name', 'created_at'])
            ->defaultSort('-id');

        // 默认不显示已释放的IP（除非显式筛选）
        if (!$request->filled('filter.status') || $request->input('filter.status') !== 'released') {
            if (!$request->boolean('include_released')) {
                $query->where('status', '!=', 'released');
            }
        }

        // 业务员数据隔离
        $user = $request->user();
        if ($user && $user->hasRole('staff')) {
            $customerIds = Customer::where('sales_person', $user->name)->pluck('id');
            $query->where(function ($q) use ($customerIds) {
                $q->whereIn('assigned_customer_id', $customerIds)
                  ->orWhere('status', 'available');
            });
        }

        $ips = $query->paginate($request->input('per_page', 15));

        return $this->paginated($ips);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'asset_group_id'       => 'nullable|integer|exists:ip_asset_groups,id',
            'socks5_info'          => 'nullable|string|max:500',
            'ip_address'           => 'nullable|string|max:100',
            'port'                 => 'nullable|integer',
            'auth_username'        => 'nullable|string|max:100',
            'auth_password'        => 'nullable|string|max:100',
            'protocol'             => 'nullable|string|max:20',
            'asset_name'           => 'nullable|string|max:100',
            'country_code'         => 'required|string|max:10',
            'country_name'         => 'nullable|string|max:100',
            'city'                 => 'nullable|string|max:100',
            'ip_type'              => 'required|string|in:residential,datacenter,mobile',
            'nature'               => 'required|string|in:static,rotating',
            'net_type'             => 'nullable|string|max:50',
            'source_name'          => 'nullable|string|max:100',
            'status'               => 'nullable|string|in:available,assigned,offline,expired',
            'remark'               => 'nullable|string|max:1000',
            'upstream_expires_at'  => 'nullable|date',
        ]);

        if (!empty($data['socks5_info'])) {
            $parsed = ProxyIp::parseSocks5Info($data['socks5_info']);
            $data = array_merge($parsed, $data);
        }

        $data['status'] = $data['status'] ?? 'available';

        $proxyIp = ProxyIp::create($data);

        return $this->success($proxyIp, 'IP创建成功');
    }

    public function show(ProxyIp $proxyIp): JsonResponse
    {
        $proxyIp->load([
            'assetGroup:id,name,source_type,source_name',
            'ipGroup:id,name,isp_type,net_type',
            'assignedCustomer:id,customer_name,username,sales_person',
            'activeSubscription.forwardRule.deviceGroup:id,name,original_connect_host,custom_connect_host',
            'activeSubscription.forwardRule.panel:id,name',
            'subscriptions' => fn($q) => $q->with('customer:id,customer_name')->latest()->limit(10),
            'assignmentLogs' => fn($q) => $q->with(['customer:id,customer_name', 'operator:id,name'])->latest('created_at')->limit(20),
        ]);

        return $this->success($proxyIp);
    }

    public function update(Request $request, ProxyIp $proxyIp): JsonResponse
    {
        $data = $request->validate([
            'asset_group_id'       => 'nullable|integer|exists:ip_asset_groups,id',
            'socks5_info'          => 'nullable|string|max:500',
            'ip_address'           => 'nullable|string|max:100',
            'port'                 => 'nullable|integer',
            'auth_username'        => 'nullable|string|max:100',
            'auth_password'        => 'nullable|string|max:100',
            'protocol'             => 'nullable|string|max:20',
            'asset_name'           => 'nullable|string|max:100',
            'country_code'         => 'sometimes|string|max:10',
            'country_name'         => 'nullable|string|max:100',
            'city'                 => 'nullable|string|max:100',
            'ip_type'              => 'sometimes|string|in:residential,datacenter,mobile',
            'nature'               => 'sometimes|string|in:static,rotating',
            'net_type'             => 'nullable|string|max:50',
            'source_name'          => 'nullable|string|max:100',
            'status'               => 'nullable|string|in:available,assigned,offline,expired',
            'remark'               => 'nullable|string|max:1000',
            'upstream_expires_at'  => 'nullable|date',
        ]);

        if (!empty($data['socks5_info'])) {
            $parsed = ProxyIp::parseSocks5Info($data['socks5_info']);
            $data = array_merge($parsed, $data);
        }

        $proxyIp->update($data);

        return $this->success($proxyIp, 'IP更新成功');
    }

    public function destroy(ProxyIp $proxyIp): JsonResponse
    {
        if ($proxyIp->status !== 'available') {
            return $this->error('只能删除状态为可用的IP', 422);
        }

        $proxyIp->delete();

        return $this->success(null, 'IP已删除');
    }

    public function assign(Request $request, ProxyIp $proxyIp): JsonResponse
    {
        $data = $request->validate([
            'customer_id' => 'required|integer|exists:customers,id',
            'price'       => 'required|numeric|min:0',
            'duration'    => 'required|integer|min:1',
            'unit'        => 'required|integer|in:1,2,3,4',
        ]);

        if ($proxyIp->status !== 'available') {
            return $this->error('该IP当前不可分配', 422);
        }

        $result = DB::transaction(function () use ($proxyIp, $data, $request) {
            $expiresAt = match ((int) $data['unit']) {
                1 => now()->addDays($data['duration']),
                2 => now()->addWeeks($data['duration']),
                3 => now()->addMonths($data['duration']),
                4 => now()->addYears($data['duration']),
            };

            $subscription = Subscription::create([
                'customer_id'  => $data['customer_id'],
                'proxy_ip_id'  => $proxyIp->id,
                'price'        => $data['price'],
                'duration'     => $data['duration'],
                'unit'         => $data['unit'],
                'started_at'   => now(),
                'expires_at'   => $expiresAt,
                'status'       => 'active',
                'renewed_count' => 0,
                'created_by'   => $request->user()?->id,
            ]);

            $proxyIp->update([
                'status'               => 'assigned',
                'assigned_customer_id' => $data['customer_id'],
            ]);

            IpAssignmentLog::create([
                'proxy_ip_id'    => $proxyIp->id,
                'customer_id'    => $data['customer_id'],
                'subscription_id' => $subscription->id,
                'action'         => 'assign',
                'operated_by'    => $request->user()?->id,
                'remark'         => "分配IP给客户，价格{$data['price']}，时长{$data['duration']}",
                'created_at'     => now(),
            ]);

            return $subscription;
        });

        return $this->success($result, 'IP分配成功');
    }

    public function unassign(Request $request, ProxyIp $proxyIp): JsonResponse
    {
        if ($proxyIp->status !== 'assigned') {
            return $this->error('该IP当前未分配', 422);
        }

        DB::transaction(function () use ($proxyIp, $request) {
            $customerId = $proxyIp->assigned_customer_id;

            $activeSubscription = $proxyIp->activeSubscription;
            if ($activeSubscription) {
                $activeSubscription->update(['status' => 'cancelled']);
            }

            $proxyIp->update([
                'status'               => 'available',
                'assigned_customer_id' => null,
            ]);

            IpAssignmentLog::create([
                'proxy_ip_id'    => $proxyIp->id,
                'customer_id'    => $customerId,
                'subscription_id' => $activeSubscription?->id,
                'action'         => 'unassign',
                'operated_by'    => $request->user()?->id,
                'remark'         => '取消分配IP',
                'created_at'     => now(),
            ]);
        });

        return $this->success(null, 'IP已取消分配');
    }

    /**
     * 释放IP资产
     * POST /proxy-ips/{id}/release
     * - 设置 status=released，记录释放原因
     * - 保留历史记录
     * - 如果是 Spark IP，调用 DelProxy 自动释放
     */
    public function release(Request $request, ProxyIp $proxyIp): JsonResponse
    {
        $data = $request->validate([
            'reason' => 'nullable|string|max:255',
            'auto_release_spark' => 'nullable|boolean', // Spark IP 是否同时调用 DelProxy
        ]);

        if ($proxyIp->status === 'released') {
            return $this->error('该IP已释放', 422);
        }

        $autoReleaseSpark = $data['auto_release_spark'] ?? true;

        DB::transaction(function () use ($proxyIp, $request, $data, $autoReleaseSpark) {
            $userId = $request->user()->id;
            $customerId = $proxyIp->assigned_customer_id;

            // 取消关联的活跃订阅
            $activeSub = $proxyIp->activeSubscription;
            if ($activeSub) {
                $activeSub->update(['status' => 'cancelled']);
            }

            $updates = [
                'status' => 'released',
                'assigned_customer_id' => null,
                'released_at' => now(),
                'release_reason' => $data['reason'] ?? '手动释放',
                'released_by' => $userId,
            ];

            if ($autoReleaseSpark && $proxyIp->spark_instance_id) {
                $updates['spark_release_status'] = 'pending';
            }

            $proxyIp->update($updates);

            IpAssignmentLog::create([
                'proxy_ip_id' => $proxyIp->id,
                'customer_id' => $customerId,
                'subscription_id' => $activeSub?->id,
                'action' => 'release',
                'operated_by' => $userId,
                'remark' => '释放IP: ' . ($data['reason'] ?? '手动释放'),
                'created_at' => now(),
            ]);
        });

        // Spark API 调用放在事务外
        $sparkResult = null;
        if ($autoReleaseSpark && $proxyIp->fresh()->spark_instance_id) {
            $sparkResult = \App\Services\SparkReleaseService::releaseInstance($proxyIp->fresh(), 'manual_release');
        }

        $msg = '已释放';
        if ($sparkResult) {
            $msg .= $sparkResult['status'] === 'failed'
                ? '。⚠️ Spark 释放失败: ' . $sparkResult['message'] . '（IP 仍会从可用池移除，请到详情页手动核验）'
                : '。Spark: ' . $sparkResult['message'];
        }

        return $this->success([
            'spark_release' => $sparkResult,
        ], $msg);
    }

    /**
     * 主动核验 Spark 实例是否已真正释放
     * POST /proxy-ips/{proxy_ip}/verify-spark-release
     */
    public function verifySparkRelease(ProxyIp $proxyIp): JsonResponse
    {
        if (!$proxyIp->spark_instance_id) {
            return $this->error('该 IP 不是 Spark 实例', 422);
        }

        $result = \App\Services\SparkReleaseService::verifyReleaseStatus($proxyIp);

        return $this->success([
            'proxy_ip' => $proxyIp->fresh(),
            'verify' => $result,
        ], $result['message']);
    }

    /**
     * 手动重试 Spark 释放（用于 spark_release_status=failed 的记录）
     * POST /proxy-ips/{proxy_ip}/retry-spark-release
     */
    public function retrySparkRelease(ProxyIp $proxyIp): JsonResponse
    {
        if (!$proxyIp->spark_instance_id) {
            return $this->error('该 IP 不是 Spark 实例', 422);
        }

        $result = \App\Services\SparkReleaseService::releaseInstance($proxyIp, 'manual_retry');

        return $this->success([
            'proxy_ip' => $proxyIp->fresh(),
            'spark_release' => $result,
        ], $result['message']);
    }

    public function stats(): JsonResponse
    {
        $byStatus = ProxyIp::selectRaw('status, count(*) as count')
            ->groupBy('status')
            ->pluck('count', 'status');

        $byCountry = ProxyIp::selectRaw('country_code, count(*) as count')
            ->groupBy('country_code')
            ->pluck('count', 'country_code');

        return $this->success([
            'by_status'  => $byStatus,
            'by_country' => $byCountry,
        ]);
    }

    /**
     * 批量导入IP
     * POST /proxy-ips/import
     * CSV列: socks5, asset_name, country, customer_name, expires_at, sales_person, source_name, remark
     */
    public function import(Request $request): JsonResponse
    {
        $request->validate([
            'file' => 'required|file|mimes:csv,txt|max:5120',
            'asset_group_id' => 'required|exists:ip_asset_groups,id',
            'ip_group_id' => 'nullable|exists:ip_groups,id',
        ]);

        $file = $request->file('file');
        $assetGroupId = $request->input('asset_group_id');
        $ipGroupId = $request->input('ip_group_id');
        $userId = $request->user()->id;

        // 读取 CSV
        $handle = fopen($file->getPathname(), 'r');
        $header = fgetcsv($handle);
        if (!$header) {
            fclose($handle);
            return $this->error('CSV文件为空或格式错误');
        }

        // 去除 BOM
        $header[0] = preg_replace('/^\x{FEFF}/u', '', $header[0]);
        $header = array_map('trim', $header);

        // 创建导入记录
        $importLog = IpImportLog::create([
            'asset_group_id' => $assetGroupId,
            'source_type' => 'csv',
            'file_name' => $file->getClientOriginalName(),
            'total_count' => 0,
            'success_count' => 0,
            'fail_count' => 0,
            'status' => 'processing',
            'imported_by' => $userId,
        ]);

        $total = 0;
        $success = 0;
        $failed = 0;
        $errors = [];

        // 国家名→代码映射（简易）
        $countryMap = [
            '巴西' => 'BR', '墨西哥' => 'MX', '美国' => 'US', '印尼' => 'ID',
            '泰国' => 'TH', '德国' => 'DE', '日本' => 'JP', '韩国' => 'KR',
            '印度' => 'IN', '英国' => 'GB', '法国' => 'FR', '加拿大' => 'CA',
            '澳大利亚' => 'AU', '新加坡' => 'SG', '马来西亚' => 'MY', '越南' => 'VN',
            '菲律宾' => 'PH', '俄罗斯' => 'RU', '土耳其' => 'TR', '柬埔寨' => 'KH',
        ];

        while (($row = fgetcsv($handle)) !== false) {
            $total++;
            if (count($row) < 3) {
                $failed++;
                $errors[] = ['row' => $total + 1, 'message' => '列数不足'];
                continue;
            }

            $data = [];
            foreach ($header as $i => $col) {
                $data[trim($col)] = trim($row[$i] ?? '');
            }

            $socks5 = $data['socks5'] ?? '';
            $assetName = $data['asset_name'] ?? '';
            $country = $data['country'] ?? '';

            if (empty($socks5)) {
                $failed++;
                $errors[] = ['row' => $total + 1, 'message' => 'socks5为空'];
                continue;
            }

            // 解析 socks5 连接串
            $parts = explode(':', $socks5);
            $ipAddress = $parts[0] ?? '';
            $port = (int) ($parts[1] ?? 0);
            $authUser = $parts[2] ?? '';
            $authPass = $parts[3] ?? '';

            if (empty($ipAddress) || $port <= 0) {
                $failed++;
                $errors[] = ['row' => $total + 1, 'message' => "socks5格式错误: {$socks5}"];
                continue;
            }

            // 检查重复
            if (ProxyIp::where('ip_address', $ipAddress)->where('port', $port)->exists()) {
                $failed++;
                $errors[] = ['row' => $total + 1, 'message' => "IP已存在: {$ipAddress}:{$port}"];
                continue;
            }

            try {
                DB::transaction(function () use (
                    $data, $socks5, $assetName, $country, $ipAddress, $port, $authUser, $authPass,
                    $assetGroupId, $ipGroupId, $userId, $importLog, $countryMap, &$success
                ) {
                    $countryCode = $countryMap[$country] ?? strtoupper(substr($country, 0, 2));
                    $sourceName = $data['source_name'] ?? '';
                    $customerName = $data['customer_name'] ?? '';
                    $salesPerson = $data['sales_person'] ?? '';
                    $expiresAt = $this->parseExpiryDate($data['expires_at'] ?? '');

                    // 创建 IP 资产
                    $proxyIp = ProxyIp::create([
                        'asset_group_id' => $assetGroupId,
                        'ip_group_id' => $ipGroupId,
                        'socks5_info' => $socks5,
                        'ip_address' => $ipAddress,
                        'port' => $port,
                        'auth_username' => $authUser,
                        'auth_password' => $authPass,
                        'protocol' => 'socks5',
                        'asset_name' => $assetName ?: "{$country}-{$ipAddress}",
                        'country_code' => $countryCode,
                        'country_name' => $country,
                        'ip_type' => 'residential',
                        'nature' => 'static',
                        'source_name' => $sourceName ?: '手动导入',
                        'status' => $customerName ? 'assigned' : 'available',
                        'import_batch_id' => $importLog->id,
                        'upstream_expires_at' => $expiresAt,
                        'remark' => $data['remark'] ?? null,
                    ]);

                    // 如果有客户名，自动匹配/创建客户并分配
                    if ($customerName) {
                        $customer = Customer::where('customer_name', $customerName)->first();
                        if (!$customer) {
                            $customer = Customer::create([
                                'customer_name' => $customerName,
                                'username' => 'snp_' . Str::random(8),
                                'password' => Hash::make(Str::random(12)),
                                'sales_person' => $salesPerson,
                                'status' => 1,
                            ]);
                        }

                        $proxyIp->update(['assigned_customer_id' => $customer->id]);

                        // 创建订阅
                        if ($expiresAt) {
                            Subscription::create([
                                'customer_id' => $customer->id,
                                'proxy_ip_id' => $proxyIp->id,
                                'price' => 0,
                                'duration' => 1,
                                'unit' => 3,
                                'started_at' => now(),
                                'expires_at' => $expiresAt,
                                'status' => $expiresAt > now() ? 'active' : 'expired',
                                'created_by' => $userId,
                                'remark' => '批量导入',
                            ]);
                        }

                        // 记录分配日志
                        IpAssignmentLog::create([
                            'proxy_ip_id' => $proxyIp->id,
                            'customer_id' => $customer->id,
                            'action' => 'assign',
                            'operated_by' => $userId,
                            'remark' => '批量导入自动分配',
                            'created_at' => now(),
                        ]);
                    }

                    $success++;
                });
            } catch (\Exception $e) {
                $failed++;
                $errors[] = ['row' => $total + 1, 'message' => $e->getMessage()];
            }
        }

        fclose($handle);

        $importLog->update([
            'total_count' => $total,
            'success_count' => $success,
            'fail_count' => $failed,
            'error_details' => $errors ?: null,
            'status' => $failed === 0 ? 'completed' : ($success > 0 ? 'completed' : 'failed'),
        ]);

        return $this->success([
            'total_count' => $total,
            'success_count' => $success,
            'fail_count' => $failed,
            'errors' => array_slice($errors, 0, 50),
        ], "导入完成: 成功{$success}条, 失败{$failed}条");
    }

    /**
     * 解析到期时间（支持多种格式）
     */
    private function parseExpiryDate(string $value): ?\Carbon\Carbon
    {
        if (empty($value)) return null;

        $value = trim($value);

        // "3.26到期" → "2026-03-26"
        if (preg_match('/^(\d{1,2})\.(\d{1,2})/', $value, $m)) {
            $year = date('Y'); // 默认当年，如果已过则下一年
            $date = \Carbon\Carbon::createFromFormat('Y-m-d', "{$year}-{$m[1]}-{$m[2]}");
            if ($date->isPast()) {
                $date->addYear();
            }
            return $date;
        }

        // "2026-03-26" 或 "2026/03/26"
        try {
            return \Carbon\Carbon::parse($value);
        } catch (\Exception) {
            return null;
        }
    }
}
