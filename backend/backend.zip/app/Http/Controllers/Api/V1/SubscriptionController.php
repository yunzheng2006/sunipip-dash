<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\IpAssignmentLog;
use App\Models\PricingRule;
use App\Models\ProvisionOrder;
use App\Models\ProvisionOrderItem;
use App\Models\ProxyIp;
use App\Models\Subscription;
use App\Models\Transaction;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Spatie\QueryBuilder\AllowedFilter;
use Spatie\QueryBuilder\QueryBuilder;

class SubscriptionController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = QueryBuilder::for(Subscription::class)
            ->allowedFilters([
                AllowedFilter::exact('status'),
                AllowedFilter::exact('customer_id'),
                AllowedFilter::exact('proxy_ip_id'),
                AllowedFilter::callback('customer_name', function ($q, $value) {
                    $q->whereHas('customer', fn($c) => $c->where('customer_name', 'like', "%{$value}%"));
                }),
                AllowedFilter::callback('country', function ($q, $value) {
                    $q->whereHas('proxyIp', fn($p) => $p->where('country_name', 'like', "%{$value}%"));
                }),
                AllowedFilter::callback('expiring_soon', function ($q, $value) {
                    if ($value) {
                        $q->where('status', 'active')
                          ->where('expires_at', '<=', now()->addDays((int) $value))
                          ->where('expires_at', '>', now());
                    }
                }),
                AllowedFilter::callback('asset_name', function ($q, $value) {
                    $q->whereHas('proxyIp', fn($p) => $p->where('asset_name', 'like', "%{$value}%"));
                }),
                AllowedFilter::callback('source_name', function ($q, $value) {
                    $q->whereHas('proxyIp', fn($p) => $p->where('source_name', $value));
                }),
                AllowedFilter::callback('created_from', fn($q, $v) => $q->where('created_at', '>=', $v)),
                AllowedFilter::callback('created_to', fn($q, $v) => $q->where('created_at', '<=', $v . ' 23:59:59')),
                AllowedFilter::callback('expires_from', fn($q, $v) => $q->where('expires_at', '>=', $v)),
                AllowedFilter::callback('expires_to', fn($q, $v) => $q->where('expires_at', '<=', $v . ' 23:59:59')),
            ])
            ->with([
                'customer:id,customer_name,sales_person',
                'proxyIp:id,asset_name,ip_address,port,auth_username,auth_password,country_name,source_name,ip_group_id,asset_group_id',
                'proxyIp.ipGroup:id,name',
                'proxyIp.assetGroup:id,name',
                'forwardRule.deviceGroup:id,name,original_connect_host,custom_connect_host',
            ])
            ->allowedSorts(['id', 'expires_at', 'created_at', 'price'])
            ->defaultSort('expires_at');

        // 业务员数据隔离：staff角色只看自己客户的订阅
        $user = $request->user();
        if ($user && $user->hasRole('staff')) {
            $customerIds = Customer::where('sales_person', $user->name)->pluck('id');
            $query->whereIn('customer_id', $customerIds);
        }

        $subscriptions = $query->paginate($request->input('per_page', 15));

        return $this->paginated($subscriptions);
    }

    public function show(Subscription $subscription): JsonResponse
    {
        $subscription->load([
            'customer:id,customer_name,username,phone,email,sales_person,balance',
            'proxyIp.assetGroup:id,name,source_name',
            'proxyIp.ipGroup:id,name,isp_type,net_type',
            'provisionOrder',
            'creator:id,name',
            'forwardRule.deviceGroup:id,name,original_connect_host,custom_connect_host',
            'forwardRule.panel:id,name',
        ]);

        return $this->success($subscription);
    }

    public function renew(Request $request, Subscription $subscription): JsonResponse
    {
        if ($subscription->status !== 'active') {
            return $this->error('只能续费状态为激活的订阅', 422);
        }

        $data = $request->validate([
            'duration' => 'nullable|integer|min:1',
            'unit'     => 'nullable|integer|in:1,2,3,4',
            'price'    => 'nullable|numeric|min:0',
        ]);

        try {
            $result = $this->renewOne($subscription, [
                'duration' => $data['duration'] ?? $subscription->duration,
                'unit' => $data['unit'] ?? $subscription->unit,
                'price' => $data['price'] ?? null,
            ], $request->user()?->id);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }

        return $this->success($result, '续费成功');
    }

    /**
     * 批量续费
     * POST /subscriptions/bulk-renew
     * Body: { items: [{ id, price, duration?, unit? }], duration, unit }
     */
    public function bulkRenew(Request $request): JsonResponse
    {
        $data = $request->validate([
            'items' => 'required|array|min:1',
            'items.*.id' => 'required|integer|exists:subscriptions,id',
            'items.*.price' => 'required|numeric|min:0',
            'items.*.duration' => 'nullable|integer|min:1',
            'items.*.unit' => 'nullable|integer|in:1,2,3,4',
            'duration' => 'nullable|integer|min:1',  // 全局默认
            'unit' => 'nullable|integer|in:1,2,3,4',
        ]);

        $defaultDuration = $data['duration'] ?? 1;
        $defaultUnit = $data['unit'] ?? 3;
        $userId = $request->user()?->id;

        $succeeded = [];
        $failed = [];
        $totalCharged = 0;

        foreach ($data['items'] as $item) {
            $sub = Subscription::find($item['id']);
            if (!$sub) {
                $failed[] = ['id' => $item['id'], 'reason' => '订阅不存在'];
                continue;
            }
            if ($sub->status !== 'active') {
                $failed[] = ['id' => $item['id'], 'reason' => '订阅非活跃状态'];
                continue;
            }

            try {
                $renewed = $this->renewOne($sub, [
                    'duration' => $item['duration'] ?? $defaultDuration,
                    'unit' => $item['unit'] ?? $defaultUnit,
                    'price' => $item['price'],
                ], $userId);

                $succeeded[] = [
                    'id' => $sub->id,
                    'new_expires_at' => $renewed->expires_at,
                    'charged' => (float) $item['price'],
                ];
                $totalCharged += (float) $item['price'];
            } catch (\Exception $e) {
                $failed[] = [
                    'id' => $sub->id,
                    'customer' => $sub->customer?->customer_name,
                    'asset_name' => $sub->proxyIp?->asset_name,
                    'reason' => $e->getMessage(),
                ];
            }
        }

        return $this->success([
            'succeeded' => $succeeded,
            'failed' => $failed,
            'succeeded_count' => count($succeeded),
            'failed_count' => count($failed),
            'total_charged' => round($totalCharged, 2),
        ], sprintf('批量续费完成：成功 %d 条，失败 %d 条', count($succeeded), count($failed)));
    }

    /**
     * 单条续费的内部实现（委托给 SubscriptionService）
     */
    private function renewOne(Subscription $subscription, array $opts, ?int $userId): Subscription
    {
        return app(\App\Services\SubscriptionService::class)->renewOne($subscription, $opts, $userId);
    }

    /**
     * 批量为订阅创建 3x-ui vless+reality 中转（走队列）
     * POST /subscriptions/batch-attach-xui-forward
     *
     * Body: {
     *   subscription_ids: [1,2,3],
     *   xui_panel_id: 5,
     * }
     *
     * 和 NY 不同点：
     *   - 不带 speed / fee 参数（3x-ui 当前流程暂不收转发费）
     *   - 复用 XuiCreateForwardJob 走队列 + xray settings lock
     */
    public function batchAttachXuiForward(Request $request): JsonResponse
    {
        $data = $request->validate([
            'subscription_ids' => 'required|array|min:1|max:5000',
            'subscription_ids.*' => 'integer|exists:subscriptions,id',
            'xui_panel_id' => 'required|integer|exists:xui_panels,id',
        ]);

        $panel = \App\Models\XuiPanel::find($data['xui_panel_id']);
        if (!$panel || !$panel->is_active) {
            return $this->error('3x-ui 面板不可用或未启用', 422);
        }
        if ($panel->is_mirror) {
            return $this->error('不能向备机直接开单，请选主面板', 422);
        }

        $batchId = (string) \Illuminate\Support\Str::uuid();
        $queued = [];
        $skipped = [];

        foreach ($data['subscription_ids'] as $id) {
            $sub = Subscription::with('proxyIp')->find($id);

            if (!$sub) {
                $skipped[] = ['id' => $id, 'reason' => '订阅不存在'];
                continue;
            }
            if ($sub->status !== 'active') {
                $skipped[] = ['id' => $id, 'reason' => '订阅非活跃'];
                continue;
            }
            if (!$sub->proxyIp) {
                $skipped[] = ['id' => $id, 'reason' => '订阅未关联 IP'];
                continue;
            }

            // 跳过已有 active xui 中转的订阅（防重复）
            $hasXui = \App\Models\XuiInbound::where('xui_panel_id', $panel->id)
                ->where('subscription_id', $sub->id)
                ->where('status', 'active')
                ->exists();
            if ($hasXui) {
                $skipped[] = ['id' => $id, 'reason' => '该面板已有此订阅的 xui 中转'];
                continue;
            }

            $remark = $sub->proxyIp->asset_name
                ?: "{$sub->proxyIp->country_name}-{$sub->proxyIp->ip_address}";

            $record = \App\Models\XuiInbound::create([
                'xui_panel_id' => $panel->id,
                'proxy_ip_id' => $sub->proxyIp->id,
                'subscription_id' => $sub->id,
                'remark' => $remark,
                'protocol' => 'vless',
                'server_name' => 'www.intel.com',
                'status' => 'pending',
                'batch_id' => $batchId,
            ]);

            \App\Jobs\XuiCreateForwardJob::dispatch($record->id);
            $queued[] = $record->id;
        }

        return $this->success([
            'batch_id' => $batchId,
            'panel_id' => $panel->id,
            'total_selected' => count($data['subscription_ids']),
            'queued_count' => count($queued),
            'skipped' => $skipped,
            'skipped_count' => count($skipped),
        ], sprintf(
            '已提交到 3x-ui 队列：%d 条（跳过 %d 条）',
            count($queued),
            count($skipped)
        ));
    }

    /**
     * 查询 3x-ui 批次进度
     * GET /subscriptions/batch-xui-forward-status/{batchId}
     */
    public function batchXuiForwardStatus(string $batchId): JsonResponse
    {
        $rows = \App\Models\XuiInbound::where('batch_id', $batchId)
            ->with([
                'subscription.customer:id,customer_name',
                'proxyIp:id,asset_name,ip_address,port',
            ])
            ->get();

        if ($rows->isEmpty()) {
            return $this->error('批次不存在', 404);
        }

        $byStatus = $rows->groupBy('status')->map->count();
        $total = $rows->count();
        $pending = (int) $byStatus->get('pending', 0);
        $processing = (int) $byStatus->get('processing', 0);
        $active = (int) $byStatus->get('active', 0);
        $failed = (int) $byStatus->get('failed', 0);
        $finished = ($pending + $processing) === 0;

        $failedRows = [];
        if ($failed > 0) {
            $failedRows = $rows->where('status', 'failed')->map(fn($r) => [
                'id' => $r->id,
                'subscription_id' => $r->subscription_id,
                'customer' => $r->subscription?->customer?->customer_name,
                'asset_name' => $r->proxyIp?->asset_name,
                'error' => $r->error_message,
            ])->values();
        }

        return $this->success([
            'batch_id' => $batchId,
            'total' => $total,
            'pending' => $pending,
            'processing' => $processing,
            'active' => $active,
            'failed' => $failed,
            'finished' => $finished,
            'progress_pct' => $total > 0 ? round(($active + $failed) * 100 / $total, 1) : 0,
            'failed_rules' => $failedRows,
        ]);
    }

    /**
     * 批量修改订阅到期时间
     * POST /subscriptions/batch-update-expiry
     *
     * Body: {
     *   subscription_ids: [1,2,3],
     *   expires_at: "2026-12-31"   // 直接设置到这一天
     * }
     *
     * 用途：管理员手动调整一批订阅的到期日（不扣费、不调用 Spark）
     */
    public function batchUpdateExpiry(Request $request): JsonResponse
    {
        $data = $request->validate([
            'subscription_ids' => 'required|array|min:1|max:5000',
            'subscription_ids.*' => 'integer|exists:subscriptions,id',
            'expires_at' => 'required|date',
            'sync_proxy_ip' => 'nullable|boolean', // 是否同步更新 proxy_ips.upstream_expires_at
        ]);

        $expiresAt = \Carbon\Carbon::parse($data['expires_at'])->endOfDay();
        $syncIp = $data['sync_proxy_ip'] ?? true;
        $isFuture = $expiresAt->gt(now());

        $updated = 0;
        $ipsUpdated = 0;

        foreach ($data['subscription_ids'] as $id) {
            $sub = Subscription::find($id);
            if (!$sub) continue;

            $sub->update([
                'expires_at' => $expiresAt,
                'status' => $isFuture ? 'active' : 'expired',
            ]);
            $updated++;

            if ($syncIp && $sub->proxy_ip_id) {
                \App\Models\ProxyIp::where('id', $sub->proxy_ip_id)
                    ->update(['upstream_expires_at' => $expiresAt]);
                $ipsUpdated++;
            }
        }

        return $this->success([
            'updated_count' => $updated,
            'ips_updated' => $ipsUpdated,
            'expires_at' => $expiresAt->toIso8601String(),
        ], "已更新 {$updated} 条订阅到期时间");
    }

    /**
     * 批量为多条订阅创建端口转发
     * POST /subscriptions/batch-attach-forward
     *
     * Body: {
     *   subscription_ids: [1,2,3],
     *   device_group_id: 5,
     *   speed_limit_mbps: 15 | null,
     *   forward_fee: 70
     * }
     */
    public function batchAttachForward(Request $request): JsonResponse
    {
        $data = $request->validate([
            'subscription_ids' => 'required|array|min:1|max:5000',
            'subscription_ids.*' => 'integer|exists:subscriptions,id',
            'device_group_id' => 'required|integer|exists:ny_device_groups,id',
            'speed_limit_mbps' => 'nullable|integer|min:1|max:10000',
            'forward_fee' => 'required|numeric|min:0',
        ]);

        $deviceGroup = \App\Models\NyDeviceGroup::with('panel')->find($data['device_group_id']);
        if (!$deviceGroup || !$deviceGroup->is_enabled) {
            return $this->error('设备组不可用或未启用', 422);
        }
        if (!$deviceGroup->panel || !$deviceGroup->panel->is_active) {
            return $this->error('设备组所属 NY 面板未启用', 422);
        }

        $speed = $data['speed_limit_mbps'] ?? null;
        $fee = (float) $data['forward_fee'];
        $batchId = (string) \Illuminate\Support\Str::uuid();

        $skipped = [];
        $queuedRuleIds = [];

        foreach ($data['subscription_ids'] as $id) {
            $sub = Subscription::with('proxyIp')->find($id);

            if (!$sub) {
                $skipped[] = ['id' => $id, 'reason' => '订阅不存在'];
                continue;
            }
            if ($sub->status !== 'active') {
                $skipped[] = ['id' => $id, 'reason' => '订阅非活跃'];
                continue;
            }
            if ($sub->has_forward) {
                $skipped[] = ['id' => $id, 'reason' => '已有转发规则'];
                continue;
            }
            if (!$sub->proxyIp) {
                $skipped[] = ['id' => $id, 'reason' => '订阅未关联 IP'];
                continue;
            }

            // 预先创建 pending 规则，Job 会基于 rule_id 处理
            $rule = \App\Models\ForwardRule::create([
                'subscription_id' => $sub->id,
                'proxy_ip_id' => $sub->proxyIp->id,
                'ny_panel_id' => $deviceGroup->ny_panel_id,
                'ny_device_group_id' => $deviceGroup->id,
                'name' => sprintf(
                    'SNP-S%d-%s:%d',
                    $sub->id,
                    $sub->proxyIp->ip_address,
                    $sub->proxyIp->port
                ),
                'dest_host' => $sub->proxyIp->ip_address,
                'dest_port' => (int) $sub->proxyIp->port,
                'speed_limit_mbps' => $speed,
                'forward_fee' => $fee,
                'status' => 'pending',
                'batch_id' => $batchId,
            ]);

            \App\Jobs\AttachForwardJob::dispatch($rule->id);
            $queuedRuleIds[] = $rule->id;
        }

        return $this->success([
            'batch_id' => $batchId,
            'total_selected' => count($data['subscription_ids']),
            'queued_count' => count($queuedRuleIds),
            'skipped' => $skipped,
            'skipped_count' => count($skipped),
        ], sprintf(
            '已提交到队列：%d 条（跳过 %d 条）。稍候请查看进度。',
            count($queuedRuleIds),
            count($skipped)
        ));
    }

    /**
     * 查询批量转发进度
     * GET /subscriptions/batch-forward-status/{batchId}
     */
    public function batchForwardStatus(string $batchId): JsonResponse
    {
        $rules = \App\Models\ForwardRule::where('batch_id', $batchId)
            ->with(['subscription.customer:id,customer_name', 'proxyIp:id,asset_name,ip_address,port'])
            ->get();

        if ($rules->isEmpty()) {
            return $this->error('批次不存在', 404);
        }

        $byStatus = $rules->groupBy('status')->map->count();

        $total = $rules->count();
        $pending = (int) $byStatus->get('pending', 0);
        $processing = (int) $byStatus->get('processing', 0);
        $active = (int) $byStatus->get('active', 0);
        $failed = (int) $byStatus->get('failed', 0);
        $deleted = (int) $byStatus->get('deleted', 0);

        $finished = ($pending + $processing) === 0;

        $failedRules = [];
        if ($failed > 0) {
            $failedRules = $rules->where('status', 'failed')->map(fn($r) => [
                'id' => $r->id,
                'subscription_id' => $r->subscription_id,
                'customer' => $r->subscription?->customer?->customer_name,
                'asset_name' => $r->proxyIp?->asset_name,
                'error' => $r->error_message,
            ])->values();
        }

        return $this->success([
            'batch_id' => $batchId,
            'total' => $total,
            'pending' => $pending,
            'processing' => $processing,
            'active' => $active,
            'failed' => $failed,
            'deleted' => $deleted,
            'finished' => $finished,
            'progress_pct' => $total > 0 ? round(($active + $failed) * 100 / $total, 1) : 0,
            'failed_rules' => $failedRules,
        ]);
    }

    public function cancel(Request $request, Subscription $subscription): JsonResponse
    {
        if ($subscription->status !== 'active') {
            return $this->error('只能取消状态为激活的订阅', 422);
        }

        DB::transaction(function () use ($subscription, $request) {
            $subscription->update(['status' => 'cancelled']);

            $proxyIp = $subscription->proxyIp;
            if ($proxyIp && $proxyIp->status === 'assigned') {
                $proxyIp->update([
                    'status'               => 'available',
                    'assigned_customer_id' => null,
                ]);
            }

            IpAssignmentLog::create([
                'proxy_ip_id'    => $subscription->proxy_ip_id,
                'customer_id'    => $subscription->customer_id,
                'subscription_id' => $subscription->id,
                'action'         => 'unassign',
                'operated_by'    => $request->user()?->id,
                'remark'         => '取消订阅释放IP',
                'created_at'     => now(),
            ]);
        });

        // 事务外删除 NY 转发
        if ($subscription->fresh()->has_forward) {
            try {
                app(\App\Services\Ny\NyForwardService::class)
                    ->deleteForSubscription($subscription->fresh());
            } catch (\Throwable $e) {
                \Log::warning('cancel: delete forward failed', [
                    'subscription_id' => $subscription->id,
                    'error' => $e->getMessage(),
                ]);
            }
        }

        // 事务外删除 3x-ui 中转（如果有）
        try {
            app(\App\Services\Xui\XuiForwardService::class)
                ->deleteForSubscription($subscription->fresh());
        } catch (\Throwable $e) {
            \Log::warning('cancel: delete xui forward failed', [
                'subscription_id' => $subscription->id,
                'error' => $e->getMessage(),
            ]);
        }

        return $this->success(null, '订阅已取消');
    }

    /**
     * 退订 - 客户1天内可退订，释放IP+退款
     * POST /subscriptions/{id}/refund
     */
    public function refund(Request $request, Subscription $subscription): JsonResponse
    {
        $data = $request->validate([
            'reason' => 'nullable|string|max:500',
            'refund_amount' => 'nullable|numeric|min:0',
            'auto_release' => 'nullable|boolean', // 是否同时释放Spark IP
        ]);

        if ($subscription->status !== 'active') {
            return $this->error('只能退订状态为激活的订阅', 422);
        }

        // 检查1天限制
        $ageHours = $subscription->started_at?->diffInHours(now()) ?? 9999;
        if ($ageHours > 24 && !$request->user()->hasRole('super_admin')) {
            return $this->error("订阅已开通超过24小时({$ageHours}小时)，超过退订时限。如需处理请联系超级管理员", 422);
        }

        $refundAmount = $data['refund_amount'] ?? $subscription->price;
        $autoRelease = $data['auto_release'] ?? true;

        DB::transaction(function () use ($subscription, $request, $data, $refundAmount, $autoRelease) {
            $userId = $request->user()->id;
            $proxyIp = $subscription->proxyIp;

            // 更新订阅状态
            $subscription->update([
                'status' => 'refunded',
                'refunded_at' => now(),
                'refund_reason' => $data['reason'] ?? '客户退订',
                'refund_amount' => $refundAmount,
                'refunded_by' => $userId,
            ]);

            // 退款到客户余额
            if ($refundAmount > 0) {
                $customer = $subscription->customer()->lockForUpdate()->first();
                if ($customer) {
                    $balanceBefore = $customer->balance;
                    $customer->increment('balance', $refundAmount);

                    Transaction::create([
                        'customer_id' => $customer->id,
                        'type' => 'refund',
                        'amount' => $refundAmount,
                        'balance_before' => $balanceBefore,
                        'balance_after' => $customer->balance,
                        'related_type' => Subscription::class,
                        'related_id' => $subscription->id,
                        'description' => "退订 #{$subscription->id}: " . ($data['reason'] ?? '客户退订'),
                        'operated_by' => $userId,
                    ]);
                }
            }

            // 解绑并标记为已释放。退订场景下 IP 不回到可用池。
            if ($proxyIp) {
                $updates = [
                    'assigned_customer_id' => null,
                    'status' => 'released',
                    'released_at' => now(),
                    'release_reason' => '客户退订: ' . ($data['reason'] ?? ''),
                    'released_by' => $userId,
                ];

                // 如果是 Spark IP 且需要自动释放 → 标记为 pending，稍后发 API
                if ($autoRelease && $proxyIp->spark_instance_id) {
                    $updates['spark_release_status'] = 'pending';
                }

                $proxyIp->update($updates);

                IpAssignmentLog::create([
                    'proxy_ip_id' => $proxyIp->id,
                    'customer_id' => $subscription->customer_id,
                    'subscription_id' => $subscription->id,
                    'action' => 'unassign',
                    'operated_by' => $userId,
                    'remark' => '客户退订',
                    'created_at' => now(),
                ]);
            }
        });

        // 删除 NY 转发（事务外调用 NY API）
        $forwardDeleted = 0;
        if ($subscription->fresh()->has_forward) {
            try {
                $forwardDeleted = app(\App\Services\Ny\NyForwardService::class)
                    ->deleteForSubscription($subscription->fresh());
            } catch (\Throwable $e) {
                \Log::warning('SubscriptionController::refund - delete forward failed', [
                    'subscription_id' => $subscription->id,
                    'error' => $e->getMessage(),
                ]);
            }
        }

        // 删除 3x-ui 中转（如果有）
        try {
            app(\App\Services\Xui\XuiForwardService::class)
                ->deleteForSubscription($subscription->fresh());
        } catch (\Throwable $e) {
            \Log::warning('refund: delete xui forward failed', [
                'subscription_id' => $subscription->id,
                'error' => $e->getMessage(),
            ]);
        }

        // Spark API 调用放在事务之外：失败也不影响退订与退款的一致性
        $proxyIp = $subscription->fresh('proxyIp')->proxyIp;
        $sparkResult = null;
        if ($autoRelease && $proxyIp && $proxyIp->spark_instance_id) {
            $sparkResult = \App\Services\SparkReleaseService::releaseInstance($proxyIp, 'refund');
        }

        return $this->success([
            'refunded' => true,
            'forward_deleted' => $forwardDeleted,
            'spark_release' => $sparkResult,
        ], '退订成功，已退款到客户余额' . ($sparkResult ? ($sparkResult['status'] === 'failed' ? '。⚠️ Spark 释放失败: ' . $sparkResult['message'] : '。Spark 释放: ' . $sparkResult['status']) : ''));
    }

    public function expiring(Request $request): JsonResponse
    {
        $days = (int) $request->input('days', 7);

        $subscriptions = Subscription::with(['customer', 'proxyIp'])
            ->expiringSoon($days)
            ->orderBy('expires_at')
            ->paginate($request->input('per_page', 15));

        return $this->paginated($subscriptions);
    }

    public function createOrder(Request $request): JsonResponse
    {
        $data = $request->validate([
            'customer_id'              => 'required|exists:customers,id',
            'items'                    => 'required|array|min:1',
            'items.*.ip_group_id'      => 'required|exists:ip_groups,id',
            'items.*.asset_group_id'   => 'nullable|exists:ip_asset_groups,id',
            'items.*.quantity'         => 'required|integer|min:1',
            'items.*.unit_price'       => 'nullable|numeric|min:0',
            'items.*.duration'         => 'nullable|integer|min:1',
            'items.*.unit'             => 'nullable|integer|in:1,2,3,4',
            'remark'                   => 'nullable|string|max:500',
        ]);

        $customerId = $data['customer_id'];
        $items = $data['items'];

        // Pre-check: resolve prices and check IP availability before entering the transaction
        $resolvedItems = [];
        foreach ($items as $index => $item) {
            $ipGroupId = $item['ip_group_id'];
            $assetGroupId = $item['asset_group_id'] ?? null;
            $quantity = $item['quantity'];
            $duration = $item['duration'] ?? 1;
            $unit = $item['unit'] ?? 3;

            // Resolve unit price
            $unitPrice = $item['unit_price'] ?? null;
            if ($unitPrice === null) {
                $pricingRule = PricingRule::where('ip_group_id', $ipGroupId)
                    ->where('is_active', 1)
                    ->first();

                if (!$pricingRule) {
                    return $this->error("第 " . ($index + 1) . " 项: IP组(id={$ipGroupId})未找到定价规则", 422);
                }
                $unitPrice = $pricingRule->price;
            }

            // Check available IPs
            $query = ProxyIp::where('ip_group_id', $ipGroupId)
                ->where('status', 'available');
            if ($assetGroupId) {
                $query->where('asset_group_id', $assetGroupId);
            }
            $availableCount = $query->count();

            if ($availableCount < $quantity) {
                return $this->error(
                    "第 " . ($index + 1) . " 项: 可用IP不足，需要 {$quantity} 个，当前可用 {$availableCount} 个",
                    422
                );
            }

            $resolvedItems[] = [
                'ip_group_id'    => $ipGroupId,
                'asset_group_id' => $assetGroupId,
                'quantity'       => $quantity,
                'unit_price'     => $unitPrice,
                'duration'       => $duration,
                'unit'           => $unit,
            ];
        }

        $order = DB::transaction(function () use ($customerId, $resolvedItems, $data, $request) {
            $totalAmount = 0;
            foreach ($resolvedItems as $item) {
                $totalAmount = bcadd($totalAmount, bcmul($item['unit_price'], $item['quantity'], 2), 2);
            }

            // Create ProvisionOrder
            $order = ProvisionOrder::create([
                'order_no'     => ProvisionOrder::generateOrderNo(),
                'customer_id'  => $customerId,
                'status'       => 'completed',
                'total_amount' => $totalAmount,
                'remark'       => $data['remark'] ?? null,
                'created_by'   => $request->user()?->id,
            ]);

            $allSubscriptions = [];

            foreach ($resolvedItems as $item) {
                $ipGroupId = $item['ip_group_id'];
                $assetGroupId = $item['asset_group_id'];
                $quantity = $item['quantity'];
                $unitPrice = $item['unit_price'];
                $duration = $item['duration'];
                $unit = $item['unit'];

                // Find available IPs with lock
                $ipQuery = ProxyIp::where('ip_group_id', $ipGroupId)
                    ->where('status', 'available')
                    ->lockForUpdate();
                if ($assetGroupId) {
                    $ipQuery->where('asset_group_id', $assetGroupId);
                }
                $ips = $ipQuery->limit($quantity)->get();

                if ($ips->count() < $quantity) {
                    throw new \Exception("IP组(id={$ipGroupId})可用IP不足，需要 {$quantity} 个，当前可用 {$ips->count()} 个");
                }

                // Create ProvisionOrderItem
                $subtotal = bcmul($unitPrice, $quantity, 2);
                $firstIp = $ips->first();

                ProvisionOrderItem::create([
                    'order_id'     => $order->id,
                    'asset_group_id' => $assetGroupId ?? $firstIp->asset_group_id,
                    'country_code' => $firstIp->country_code ?? '',
                    'country_name' => $firstIp->country_name ?? '',
                    'city'         => $firstIp->city,
                    'quantity'     => $quantity,
                    'duration'     => $duration,
                    'unit'         => $unit,
                    'unit_price'   => $unitPrice,
                    'subtotal'     => $subtotal,
                    'status'       => 'completed',
                ]);

                $now = now();
                $expiresAt = match ($unit) {
                    1 => $now->copy()->addDays($duration),
                    2 => $now->copy()->addWeeks($duration),
                    3 => $now->copy()->addMonths($duration),
                    4 => $now->copy()->addYears($duration),
                    default => $now->copy()->addMonths($duration),
                };

                foreach ($ips as $ip) {
                    // Update proxy IP status
                    $ip->update([
                        'status'               => 'assigned',
                        'assigned_customer_id' => $customerId,
                    ]);

                    // Create subscription
                    $subscription = Subscription::create([
                        'customer_id'       => $customerId,
                        'proxy_ip_id'       => $ip->id,
                        'provision_order_id' => $order->id,
                        'price'             => $unitPrice,
                        'duration'          => $duration,
                        'unit'              => $unit,
                        'started_at'        => $now,
                        'expires_at'        => $expiresAt,
                        'status'            => 'active',
                        'created_by'        => $request->user()?->id,
                    ]);

                    $allSubscriptions[] = $subscription;

                    // Create assignment log
                    IpAssignmentLog::create([
                        'proxy_ip_id'     => $ip->id,
                        'customer_id'     => $customerId,
                        'subscription_id' => $subscription->id,
                        'action'          => 'assign',
                        'operated_by'     => $request->user()?->id,
                        'remark'          => "开通订单#{$order->order_no}",
                        'created_at'      => $now,
                    ]);
                }
            }

            return $order;
        });

        $order->load(['items', 'subscriptions.proxyIp', 'customer']);

        return $this->success($order, '订单创建成功');
    }

    public function availableIps(Request $request): JsonResponse
    {
        $request->validate([
            'ip_group_id'    => 'required|integer|exists:ip_groups,id',
            'asset_group_id' => 'nullable|integer|exists:ip_asset_groups,id',
        ]);

        $query = ProxyIp::where('ip_group_id', $request->input('ip_group_id'))
            ->where('status', 'available');

        if ($request->filled('asset_group_id')) {
            $query->where('asset_group_id', $request->input('asset_group_id'));
        }

        $count = $query->count();

        return $this->success([
            'ip_group_id'    => (int) $request->input('ip_group_id'),
            'asset_group_id' => $request->input('asset_group_id') ? (int) $request->input('asset_group_id') : null,
            'available_count' => $count,
        ]);
    }
}
