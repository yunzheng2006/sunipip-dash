<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RoleController extends Controller
{
    /**
     * 权限模块分组定义（用于前端渲染勾选表）
     */
    private array $permissionModules = [
        'dashboard' => [
            'label' => '仪表盘',
            'permissions' => [
                'dashboard.view' => '查看仪表盘',
                'dashboard.view_revenue' => '查看营收数据',
                'dashboard.view_full' => '查看完整统计(含成本)',
            ],
        ],
        'customer' => [
            'label' => '客户管理',
            'permissions' => [
                'customer.view' => '查看客户列表',
                'customer.view_own' => '查看自己的客户',
                'customer.view_all' => '查看所有客户',
                'customer.create' => '创建客户',
                'customer.edit' => '编辑客户',
                'customer.delete' => '删除客户',
                'customer.topup' => '客户充值',
                'customer.view_balance' => '查看余额和流水',
            ],
        ],
        'ip' => [
            'label' => 'IP资产',
            'permissions' => [
                'ip.view' => '查看IP列表',
                'ip.view_all' => '查看所有IP',
                'ip.create' => '添加IP',
                'ip.edit' => '编辑IP',
                'ip.delete' => '删除IP',
                'ip.import' => '批量导入IP',
                'ip.assign' => '分配IP给客户',
                'ip.unassign' => '取消IP分配',
                'ip.view_credentials' => '查看IP认证信息',
                'ip.export' => '导出IP列表',
            ],
        ],
        'asset_group' => [
            'label' => '资产组/IP组',
            'permissions' => [
                'asset_group.view' => '查看资产组',
                'asset_group.create' => '创建资产组',
                'asset_group.edit' => '编辑资产组',
                'asset_group.delete' => '删除资产组',
            ],
        ],
        'order' => [
            'label' => '开通订单',
            'permissions' => [
                'order.view' => '查看订单列表',
                'order.view_own' => '查看自己创建的订单',
                'order.view_all' => '查看所有订单',
                'order.create' => '创建开通订单',
                'order.cancel' => '取消订单',
            ],
        ],
        'subscription' => [
            'label' => '订阅管理',
            'permissions' => [
                'subscription.view' => '查看订阅列表',
                'subscription.view_own' => '查看自己客户的订阅',
                'subscription.view_all' => '查看所有订阅',
                'subscription.create' => '创建订阅',
                'subscription.renew' => '续费订阅',
                'subscription.cancel' => '取消订阅',
                'subscription.edit_price' => '修改订阅价格',
            ],
        ],
        'billing' => [
            'label' => '计费/定价',
            'permissions' => [
                'pricing.view' => '查看定价规则',
                'pricing.manage' => '管理定价规则',
                'transaction.view' => '查看交易流水',
                'transaction.view_all' => '查看所有流水',
                'transaction.export' => '导出流水',
            ],
        ],
        'spark' => [
            'label' => 'Spark API',
            'permissions' => [
                'spark.view' => '查看Spark订单',
                'spark.view_stock' => '查看Spark库存',
                'spark.manage' => '调用Spark API(下单/续费/释放)',
            ],
        ],
        'notification' => [
            'label' => '通知/Webhook',
            'permissions' => [
                'notification.view' => '查看通知记录',
                'webhook.view' => '查看Webhook配置',
                'webhook.manage' => '管理Webhook',
                'webhook.test' => '测试Webhook',
            ],
        ],
        'user' => [
            'label' => '后台用户',
            'permissions' => [
                'user.view' => '查看用户列表',
                'user.create' => '创建用户',
                'user.edit' => '编辑用户',
                'user.delete' => '删除用户',
                'user.assign_role' => '分配角色',
            ],
        ],
        'system' => [
            'label' => '系统/日志',
            'permissions' => [
                'setting.view' => '查看系统设置',
                'setting.manage' => '修改系统设置',
                'activity_log.view' => '查看操作日志',
                'activity_log.view_all' => '查看所有操作日志',
            ],
        ],
    ];

    /**
     * 角色中文名映射
     */
    private array $roleLabels = [
        'super_admin' => '超级管理员',
        'admin' => '管理员',
        'staff' => '业务员',
        'agent' => '代理商',
        'user' => '普通用户',
    ];

    /**
     * 列出所有角色
     */
    public function index(): JsonResponse
    {
        $roles = Role::withCount('permissions')->get();

        // 手动查 model_has_roles 获取用户数（避开 Spatie 多态关联的默认 User 模型问题）
        $userCounts = \DB::table('model_has_roles')
            ->where('model_type', \App\Models\User::class)
            ->selectRaw('role_id, COUNT(*) as total')
            ->groupBy('role_id')
            ->pluck('total', 'role_id');

        $data = $roles->map(fn($r) => [
            'id' => $r->id,
            'name' => $r->name,
            'label' => $this->roleLabels[$r->name] ?? $r->name,
            'guard_name' => $r->guard_name,
            'permissions_count' => $r->permissions_count,
            'users_count' => (int) ($userCounts[$r->id] ?? 0),
            'is_system' => in_array($r->name, ['super_admin', 'admin', 'staff', 'agent', 'user']),
        ]);

        return $this->success($data);
    }

    /**
     * 角色详情（含权限列表）
     */
    public function show(Role $role): JsonResponse
    {
        $permissions = $role->permissions->pluck('name')->toArray();

        return $this->success([
            'id' => $role->id,
            'name' => $role->name,
            'label' => $this->roleLabels[$role->name] ?? $role->name,
            'permissions' => $permissions,
            'is_system' => in_array($role->name, ['super_admin', 'admin', 'staff', 'agent', 'user']),
        ]);
    }

    /**
     * 创建角色
     */
    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name' => 'required|string|max:50|unique:roles,name|regex:/^[a-z_]+$/',
            'label' => 'nullable|string|max:50',
            'permissions' => 'nullable|array',
            'permissions.*' => 'string|exists:permissions,name',
        ]);

        $role = Role::create([
            'name' => $data['name'],
            'guard_name' => 'api',
        ]);

        if (!empty($data['permissions'])) {
            $role->syncPermissions($data['permissions']);
        }

        return $this->success($role, '角色创建成功');
    }

    /**
     * 更新角色权限
     */
    public function update(Request $request, Role $role): JsonResponse
    {
        // super_admin 不允许修改
        if ($role->name === 'super_admin') {
            return $this->error('超级管理员权限不允许修改', 403);
        }

        $data = $request->validate([
            'permissions' => 'required|array',
            'permissions.*' => 'string|exists:permissions,name',
        ]);

        $role->syncPermissions($data['permissions']);

        return $this->success($role->load('permissions'), '权限更新成功');
    }

    /**
     * 删除角色
     */
    public function destroy(Role $role): JsonResponse
    {
        if (in_array($role->name, ['super_admin', 'admin', 'staff', 'agent', 'user'])) {
            return $this->error('系统内置角色不允许删除', 403);
        }

        $userCount = \DB::table('model_has_roles')
            ->where('role_id', $role->id)
            ->where('model_type', \App\Models\User::class)
            ->count();

        if ($userCount > 0) {
            return $this->error('该角色下还有用户，无法删除', 422);
        }

        $role->delete();

        return $this->success(null, '角色已删除');
    }

    /**
     * 获取所有权限（按模块分组）
     */
    public function allPermissions(): JsonResponse
    {
        return $this->success([
            'modules' => $this->permissionModules,
        ]);
    }
}
