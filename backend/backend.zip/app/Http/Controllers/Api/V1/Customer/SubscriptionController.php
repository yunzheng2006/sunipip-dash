<?php

namespace App\Http\Controllers\Api\V1\Customer;

use App\Http\Controllers\Controller;
use App\Models\IpAssignmentLog;
use App\Models\Subscription;
use App\Models\Transaction;
use App\Services\SparkReleaseService;
use App\Services\SubscriptionService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * 客户自助面板 - 订阅管理
 *
 * 所有查询和操作都限制在 `customer_id = auth user` 内。
 */
class SubscriptionController extends Controller
{
    public function __construct(protected SubscriptionService $subService) {}

    /**
     * GET /customer/subscriptions
     */
    public function index(Request $request): JsonResponse
    {
        $customer = $request->user();

        $query = Subscription::with([
                'proxyIp:id,asset_name,ip_address,port,auth_username,auth_password,country_name,source_name,spark_instance_id',
                'forwardRule.deviceGroup:id,name,original_connect_host,custom_connect_host',
            ])
            ->where('customer_id', $customer->id);

        if ($request->filled('status')) {
            $query->where('status', $request->input('status'));
        }
        if ($request->filled('expiring_soon')) {
            $days = (int) $request->input('expiring_soon');
            $query->where('status', 'active')
                ->where('expires_at', '>', now())
                ->where('expires_at', '<=', now()->addDays($days));
        }

        $query->orderBy(
            $request->input('sort', 'expires_at'),
            $request->input('order', 'asc')
        );

        $paginated = $query->paginate($request->input('per_page', 20));
        return $this->paginated($paginated);
    }

    /**
     * GET /customer/subscriptions/{id}
     */
    public function show(Request $request, int $id): JsonResponse
    {
        $customer = $request->user();
        $sub = Subscription::with([
                'proxyIp',
                'forwardRule.deviceGroup:id,name,original_connect_host,custom_connect_host',
            ])
            ->where('customer_id', $customer->id)
            ->findOrFail($id);

        return $this->success($sub);
    }

    /**
     * POST /customer/subscriptions/{id}/renew
     */
    public function renew(Request $request, int $id): JsonResponse
    {
        $customer = $request->user();
        $sub = Subscription::where('customer_id', $customer->id)->findOrFail($id);

        if ($sub->status !== 'active') {
            return $this->error('只能续费状态为激活的订阅', 422);
        }

        $data = $request->validate([
            'duration' => 'nullable|integer|min:1|max:12',
            'unit' => 'nullable|integer|in:3', // 仅月
        ]);

        try {
            // 客户续费不允许自定义价格，用订阅当前价
            $result = $this->subService->renewOne($sub, [
                'duration' => $data['duration'] ?? 1,
                'unit' => $data['unit'] ?? 3,
                'price' => (float) $sub->price,
            ], null); // operated_by = null 代表客户自助
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }

        return $this->success([
            'subscription' => $result,
            'new_balance' => (float) $customer->fresh()->balance,
        ], '续费成功');
    }

    /**
     * POST /customer/subscriptions/{id}/refund
     * 24h 内可退订
     */
    public function refund(Request $request, int $id): JsonResponse
    {
        $customer = $request->user();
        $sub = Subscription::with('proxyIp')
            ->where('customer_id', $customer->id)
            ->findOrFail($id);

        if ($sub->status !== 'active') {
            return $this->error('只能退订状态为激活的订阅', 422);
        }

        $ageHours = $sub->started_at?->diffInHours(now()) ?? 9999;
        if ($ageHours > 24) {
            return $this->error("订阅已开通 {$ageHours} 小时，超过 24 小时退订时限", 422);
        }

        $data = $request->validate(['reason' => 'nullable|string|max:500']);
        $refundAmount = (float) $sub->price;

        DB::transaction(function () use ($sub, $customer, $data, $refundAmount) {
            $proxyIp = $sub->proxyIp;

            $sub->update([
                'status' => 'refunded',
                'refunded_at' => now(),
                'refund_reason' => $data['reason'] ?? '客户自助退订',
                'refund_amount' => $refundAmount,
                'refunded_by' => null,
            ]);

            // 退款
            if ($refundAmount > 0) {
                $fresh = $customer->fresh()->lockForUpdate()->first();
                $balanceBefore = $fresh->balance;
                $fresh->increment('balance', $refundAmount);
                Transaction::create([
                    'customer_id' => $fresh->id,
                    'type' => 'refund',
                    'amount' => $refundAmount,
                    'balance_before' => $balanceBefore,
                    'balance_after' => $fresh->balance,
                    'related_type' => Subscription::class,
                    'related_id' => $sub->id,
                    'description' => "自助退订 #{$sub->id}: " . ($data['reason'] ?? ''),
                    'operated_by' => null,
                ]);
            }

            // 解绑并释放 IP
            if ($proxyIp) {
                $updates = [
                    'assigned_customer_id' => null,
                    'status' => 'released',
                    'released_at' => now(),
                    'release_reason' => '客户自助退订',
                    'released_by' => null,
                ];
                if ($proxyIp->spark_instance_id) {
                    $updates['spark_release_status'] = 'pending';
                }
                $proxyIp->update($updates);

                IpAssignmentLog::create([
                    'proxy_ip_id' => $proxyIp->id,
                    'customer_id' => $sub->customer_id,
                    'subscription_id' => $sub->id,
                    'action' => 'unassign',
                    'operated_by' => 1, // 系统占位（FK NOT NULL）
                    'remark' => '客户自助退订',
                    'created_at' => now(),
                ]);
            }
        });

        // 事务外删除 NY 转发
        if ($sub->fresh()->has_forward) {
            try {
                app(\App\Services\Ny\NyForwardService::class)->deleteForSubscription($sub->fresh());
            } catch (\Throwable $e) {
                \Log::warning('Customer refund: delete forward failed', [
                    'subscription_id' => $sub->id,
                    'error' => $e->getMessage(),
                ]);
            }
        }

        // 事务外删除 3x-ui 中转
        try {
            app(\App\Services\Xui\XuiForwardService::class)->deleteForSubscription($sub->fresh());
        } catch (\Throwable $e) {
            \Log::warning('Customer refund: delete xui forward failed', [
                'subscription_id' => $sub->id,
                'error' => $e->getMessage(),
            ]);
        }

        // 事务外调 Spark DelProxy
        $proxyIp = $sub->fresh('proxyIp')->proxyIp;
        $sparkResult = null;
        if ($proxyIp && $proxyIp->spark_instance_id) {
            $sparkResult = SparkReleaseService::releaseInstance($proxyIp, 'customer_refund');
        }

        return $this->success([
            'refunded' => true,
            'refund_amount' => $refundAmount,
            'new_balance' => (float) $customer->fresh()->balance,
            'spark_release' => $sparkResult,
        ], '已退订并退款到余额');
    }

    /**
     * PUT /customer/subscriptions/{id}/auto-renew
     */
    public function toggleAutoRenew(Request $request, int $id): JsonResponse
    {
        $customer = $request->user();
        $sub = Subscription::where('customer_id', $customer->id)->findOrFail($id);

        $data = $request->validate(['enabled' => 'required|boolean']);

        $sub->update(['auto_renew' => $data['enabled'] ? 1 : 0]);
        return $this->success(['auto_renew' => (bool) $sub->auto_renew], $data['enabled'] ? '已开启自动续费' : '已关闭自动续费');
    }
}
