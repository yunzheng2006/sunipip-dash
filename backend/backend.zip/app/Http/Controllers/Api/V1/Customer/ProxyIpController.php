<?php

namespace App\Http\Controllers\Api\V1\Customer;

use App\Http\Controllers\Controller;
use App\Models\ProxyIp;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;

/**
 * 客户自助面板 - 我的 IP 资产
 */
class ProxyIpController extends Controller
{
    /**
     * GET /customer/ips
     */
    public function index(Request $request): JsonResponse
    {
        $customer = $request->user();

        $query = ProxyIp::with([
                'activeSubscription.forwardRule.deviceGroup:id,name,original_connect_host,custom_connect_host',
            ])
            ->where('assigned_customer_id', $customer->id)
            ->where('status', '!=', 'released');

        if ($request->filled('country')) {
            $query->where('country_code', strtoupper($request->input('country')));
        }
        if ($request->filled('status')) {
            $query->where('status', $request->input('status'));
        }
        if ($request->filled('keyword')) {
            $kw = $request->input('keyword');
            $query->where(function ($q) use ($kw) {
                $q->where('asset_name', 'like', "%{$kw}%")
                  ->orWhere('ip_address', 'like', "%{$kw}%");
            });
        }

        $query->orderByDesc('id');
        return $this->paginated($query->paginate($request->input('per_page', 20)));
    }

    /**
     * GET /customer/ips/{id}
     */
    public function show(Request $request, int $id): JsonResponse
    {
        $customer = $request->user();
        $ip = ProxyIp::with([
                'activeSubscription.forwardRule.deviceGroup:id,name,original_connect_host,custom_connect_host',
            ])
            ->where('assigned_customer_id', $customer->id)
            ->findOrFail($id);

        return $this->success($ip);
    }

    /**
     * GET /customer/ips/export
     * 导出 TXT，格式 ip:port:user:pass 每行一条
     */
    public function export(Request $request): StreamedResponse
    {
        $customer = $request->user();
        $format = $request->input('format', 'socks5'); // socks5 / csv / txt

        $ips = ProxyIp::with([
                'activeSubscription.forwardRule.deviceGroup:id,original_connect_host,custom_connect_host',
            ])
            ->where('assigned_customer_id', $customer->id)
            ->where('status', 'assigned')
            ->orderBy('country_code')
            ->get();

        // 对每个 IP 解析对客展示字段（优先转发地址）
        $rows = $ips->map(function ($ip) {
            $fwd = $ip->activeSubscription?->forwardRule;
            if ($fwd && $fwd->status === 'active' && $fwd->listen_port) {
                $host = $fwd->deviceGroup?->custom_connect_host
                    ?: $fwd->deviceGroup?->original_connect_host
                    ?: $ip->ip_address;
                $port = $fwd->listen_port;
            } else {
                $host = $ip->ip_address;
                $port = $ip->port;
            }
            return [
                'asset_name' => $ip->asset_name,
                'host' => $host,
                'port' => $port,
                'user' => $ip->auth_username,
                'pass' => $ip->auth_password,
                'country_name' => $ip->country_name,
                'expires_at' => $ip->upstream_expires_at?->format('Y-m-d'),
            ];
        });

        $filename = 'my_ips_' . now()->format('Ymd_His') . '.' . ($format === 'csv' ? 'csv' : 'txt');

        return response()->streamDownload(function () use ($rows, $format) {
            $out = fopen('php://output', 'w');
            if ($format === 'csv') {
                fputcsv($out, ['资产名', 'Host', '端口', '用户名', '密码', '地区', '到期时间']);
                foreach ($rows as $r) {
                    fputcsv($out, [$r['asset_name'], $r['host'], $r['port'], $r['user'], $r['pass'], $r['country_name'], $r['expires_at']]);
                }
            } else {
                foreach ($rows as $r) {
                    fwrite($out, implode(':', array_filter([
                        $r['host'], $r['port'], $r['user'], $r['pass'],
                    ])) . "\n");
                }
            }
            fclose($out);
        }, $filename, [
            'Content-Type' => $format === 'csv' ? 'text/csv' : 'text/plain',
        ]);
    }

    /**
     * GET /customer/ips/export-qr
     * 导出成可扫描表格（.xlsx）：每行一条 IP + V2Ray socks:// URL + 嵌入二维码
     *
     * 严格对齐 socks5_collect_and_build_batch.py 输出格式
     */
    public function exportQr(Request $request): \Symfony\Component\HttpFoundation\BinaryFileResponse
    {
        $customer = $request->user();

        $ips = ProxyIp::with([
                'activeSubscription.forwardRule.deviceGroup:id,name,original_connect_host,custom_connect_host',
            ])
            ->where('assigned_customer_id', $customer->id)
            ->where('status', 'assigned')
            ->orderBy('country_code')
            ->orderBy('id')
            ->get();

        if ($ips->isEmpty()) {
            abort(404, '暂无可导出的 IP');
        }

        @set_time_limit(180);
        @ini_set('memory_limit', '512M');

        $service = app(\App\Services\Export\QrXlsxExportService::class);
        $tempPath = $service->generate($ips);

        $filename = now()->format('Ymd_His') . '_最终结果.xlsx';

        return response()->download($tempPath, $filename, [
            'Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        ])->deleteFileAfterSend(true);
    }
}
