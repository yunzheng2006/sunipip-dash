<?php

namespace App\Http\Controllers\Api\V1\Customer;

use App\Http\Controllers\Controller;
use App\Models\SparkCountry;
use App\Models\SparkPricingRule;
use App\Services\Customer\CheckoutService;
use App\Services\SparkStockCacheService;
use App\Support\SparkContinents;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * 客户商店 - 浏览国家库存 + 下单
 */
class StoreController extends Controller
{
    public function __construct(protected CheckoutService $checkout) {}

    /**
     * GET /customer/store/countries
     * 只返回已定价且有库存的国家
     */
    public function countries(Request $request): JsonResponse
    {
        $byCountry = SparkStockCacheService::stockByCountry();
        $ruleMap = SparkPricingRule::boundCountryMap(); // code => rule_id

        $rules = SparkPricingRule::whereIn('id', array_unique(array_values($ruleMap)))
            ->where('is_active', 1)
            ->get(['id', 'name', 'monthly_price'])
            ->keyBy('id');

        // 关联 area_country 拿中文名
        $codes = array_keys($byCountry);
        $countries = SparkCountry::whereIn('code', $codes)
            ->get(['code', 'cname', 'name', 'continent_id'])
            ->keyBy('code');

        $result = [];
        foreach ($byCountry as $code => $info) {
            // 只展示：有对客定价 + 有库存
            $ruleId = $ruleMap[$code] ?? null;
            if (!$ruleId || !isset($rules[$ruleId]) || $info['stock'] <= 0) {
                continue;
            }
            $c = $countries->get($code);
            $continent = SparkContinents::CONTINENTS[$c?->continent_id] ?? ['name' => '其他'];

            $result[] = [
                'country_code' => $code,
                'country_name' => $c?->cname ?: ($c?->name ?: $code),
                'continent_id' => $c?->continent_id,
                'continent' => $continent['name'],
                'stock' => $info['stock'],
                'monthly_price' => (float) $rules[$ruleId]->monthly_price,
                'rule_name' => $rules[$ruleId]->name,
            ];
        }

        // 默认按库存降序
        usort($result, fn($a, $b) => $b['stock'] <=> $a['stock']);

        return $this->success([
            'countries' => $result,
            'continents' => SparkContinents::CONTINENTS,
            'last_refreshed_at' => SparkStockCacheService::lastRefreshedAt(),
            'total_countries' => count($result),
            'total_stock' => array_sum(array_column($result, 'stock')),
        ]);
    }

    /**
     * GET /customer/store/countries/{code}
     * 单国家详情 + 定价
     */
    public function show(string $code): JsonResponse
    {
        $code = strtoupper($code);
        $rule = SparkPricingRule::findByCountry($code);
        if (!$rule) {
            return $this->error('该国家暂未开放销售', 404);
        }

        $byCountry = SparkStockCacheService::stockByCountry();
        $stock = $byCountry[$code] ?? ['stock' => 0];

        $c = SparkCountry::where('code', $code)->first();
        $continent = SparkContinents::CONTINENTS[$c?->continent_id] ?? ['name' => '其他'];

        return $this->success([
            'country_code' => $code,
            'country_name' => $c?->cname ?: ($c?->name ?: $code),
            'continent' => $continent['name'],
            'stock' => $stock['stock'],
            'monthly_price' => (float) $rule->monthly_price,
            'rule_name' => $rule->name,
            'description' => $rule->description,
        ]);
    }

    /**
     * POST /customer/store/checkout
     * 自助下单核心
     */
    public function checkout(Request $request): JsonResponse
    {
        $data = $request->validate([
            'country_code' => 'required|string|max:10',
            'quantity' => 'required|integer|min:1|max:10',
            'duration' => 'required|integer|min:1|max:12',
            'unit' => 'nullable|integer|in:3', // 仅支持月
            'auto_renew' => 'nullable|boolean',
        ]);

        $customer = $request->user();

        $result = $this->checkout->purchase(
            $customer,
            $data['country_code'],
            (int) $data['quantity'],
            (int) $data['duration'],
            (int) ($data['unit'] ?? 3),
            (bool) ($data['auto_renew'] ?? false),
        );

        return $this->success($result, $result['status'] === 2 ? '购买成功' : '订单已提交，正在开通');
    }
}
