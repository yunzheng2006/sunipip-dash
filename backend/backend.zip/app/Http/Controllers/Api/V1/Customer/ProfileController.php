<?php

namespace App\Http\Controllers\Api\V1\Customer;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    public function show(Request $request): JsonResponse
    {
        $customer = $request->user();
        return $this->success([
            'id' => $customer->id,
            'username' => $customer->username,
            'customer_name' => $customer->customer_name,
            'email' => $customer->email,
            'phone' => $customer->phone,
            'company_name' => $customer->company_name,
            'company_id' => $customer->company_id,
            'address' => $customer->address,
            'balance' => (float) $customer->balance,
            'auto_renew_default' => (bool) $customer->auto_renew_default,
            'created_at' => $customer->created_at,
            'last_login_at' => $customer->last_login_at,
        ]);
    }

    public function update(Request $request): JsonResponse
    {
        $customer = $request->user();

        $data = $request->validate([
            'customer_name' => 'sometimes|string|max:100',
            'email' => 'nullable|email|max:191|unique:customers,email,' . $customer->id,
            'phone' => 'nullable|string|max:30',
            'company_name' => 'nullable|string|max:200',
            'company_id' => 'nullable|string|max:100',
            'address' => 'nullable|string|max:500',
            'auto_renew_default' => 'nullable|boolean',
        ]);

        $customer->update($data);
        return $this->success($customer->fresh(), '资料已更新');
    }
}
