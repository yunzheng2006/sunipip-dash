<?php

namespace App\Http\Controllers\Api\V1\Customer;

use App\Http\Controllers\Controller;
use App\Models\ProxyIp;
use App\Models\Subscription;
use App\Models\Transaction;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $customer = $request->user();

        $activeSubs = Subscription::where('customer_id', $customer->id)
            ->where('status', 'active')
            ->count();

        $expiringSoon = Subscription::where('customer_id', $customer->id)
            ->where('status', 'active')
            ->where('expires_at', '>', now())
            ->where('expires_at', '<=', now()->addDays(7))
            ->count();

        $expiringIn3 = Subscription::where('customer_id', $customer->id)
            ->where('status', 'active')
            ->where('expires_at', '>', now())
            ->where('expires_at', '<=', now()->addDays(3))
            ->count();

        $activeIps = ProxyIp::where('assigned_customer_id', $customer->id)
            ->where('status', 'assigned')
            ->count();

        // 本月消费（负数交易累加）
        $monthSpent = (float) Transaction::where('customer_id', $customer->id)
            ->where('amount', '<', 0)
            ->where('created_at', '>=', now()->startOfMonth())
            ->sum('amount');

        $recentTx = Transaction::where('customer_id', $customer->id)
            ->orderByDesc('id')
            ->limit(5)
            ->get(['id', 'type', 'amount', 'balance_after', 'description', 'created_at']);

        return $this->success([
            'balance' => (float) $customer->balance,
            'active_subscriptions' => $activeSubs,
            'expiring_7d' => $expiringSoon,
            'expiring_3d' => $expiringIn3,
            'active_ips' => $activeIps,
            'month_spent' => abs($monthSpent),
            'recent_transactions' => $recentTx,
        ]);
    }
}
