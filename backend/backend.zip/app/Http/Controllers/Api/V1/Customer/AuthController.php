<?php

namespace App\Http\Controllers\Api\V1\Customer;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Validation\ValidationException;

/**
 * 客户自助面板 - 认证控制器
 *
 * 全部使用 Sanctum token ability = ['customer']，与管理后台 ['admin'] token 隔离。
 */
class AuthController extends Controller
{
    /**
     * POST /customer/auth/register
     * 开放自助注册
     */
    public function register(Request $request): JsonResponse
    {
        $data = $request->validate([
            'username' => 'required|string|min:4|max:50|regex:/^[a-zA-Z0-9_]+$/|unique:customers,username',
            'password' => 'required|string|min:8|max:100|confirmed',
            'customer_name' => 'required|string|max:100',
            'email' => 'nullable|email|max:191|unique:customers,email',
            'phone' => 'nullable|string|max:30',
            'company_name' => 'nullable|string|max:200',
        ], [
            'username.regex' => '用户名只能包含字母、数字、下划线',
            'username.unique' => '该用户名已被占用',
            'email.unique' => '该邮箱已被注册',
            'password.confirmed' => '两次密码输入不一致',
        ]);

        $customer = Customer::create([
            'username' => $data['username'],
            'password' => $data['password'], // 自动 hashed (casts)
            'customer_name' => $data['customer_name'],
            'email' => $data['email'] ?? null,
            'phone' => $data['phone'] ?? null,
            'company_name' => $data['company_name'] ?? null,
            'balance' => 0,
            'status' => 1,
            'last_login_at' => now(),
            'last_login_ip' => $request->ip(),
        ]);

        $token = $customer->createToken('customer-portal', ['customer'])->plainTextToken;

        return $this->success([
            'token' => $token,
            'customer' => $this->presentCustomer($customer),
        ], '注册成功，欢迎使用 SuniPIP');
    }

    /**
     * POST /customer/auth/login
     */
    public function login(Request $request): JsonResponse
    {
        $request->validate([
            'username' => 'required|string',
            'password' => 'required|string',
        ]);

        // 登录限流：同一 IP + username 每分钟最多 5 次
        $key = 'customer-login:' . $request->ip() . ':' . $request->username;
        if (RateLimiter::tooManyAttempts($key, 5)) {
            $seconds = RateLimiter::availableIn($key);
            throw ValidationException::withMessages([
                'username' => "登录尝试过于频繁，请 {$seconds} 秒后再试",
            ]);
        }

        $customer = Customer::where('username', $request->username)->first();

        if (!$customer || !Hash::check($request->password, $customer->password)) {
            RateLimiter::hit($key, 60);
            return $this->error('用户名或密码错误', 401);
        }

        if ((int) $customer->status !== 1) {
            return $this->error('账号已被禁用，请联系管理员', 403);
        }

        RateLimiter::clear($key);

        $customer->update([
            'last_login_at' => now(),
            'last_login_ip' => $request->ip(),
        ]);

        $token = $customer->createToken('customer-portal', ['customer'])->plainTextToken;

        return $this->success([
            'token' => $token,
            'customer' => $this->presentCustomer($customer),
        ], '登录成功');
    }

    /**
     * GET /customer/auth/me
     */
    public function me(Request $request): JsonResponse
    {
        return $this->success($this->presentCustomer($request->user()));
    }

    /**
     * POST /customer/auth/logout
     */
    public function logout(Request $request): JsonResponse
    {
        $request->user()->currentAccessToken()->delete();
        return $this->success(null, '已退出登录');
    }

    /**
     * PUT /customer/auth/password
     */
    public function changePassword(Request $request): JsonResponse
    {
        $request->validate([
            'old_password' => 'required|string',
            'new_password' => 'required|string|min:8|confirmed',
        ]);

        $customer = $request->user();

        if (!Hash::check($request->old_password, $customer->password)) {
            return $this->error('原密码错误', 422);
        }

        $customer->update(['password' => $request->new_password]); // hashed by cast

        // 可选：撤销其他 token，强制其他设备重新登录
        $customer->tokens()->where('id', '!=', $customer->currentAccessToken()->id)->delete();

        return $this->success(null, '密码修改成功');
    }

    /**
     * 统一返回给前端的 customer 结构（不含敏感字段）
     */
    private function presentCustomer(Customer $customer): array
    {
        return [
            'id' => $customer->id,
            'username' => $customer->username,
            'customer_name' => $customer->customer_name,
            'email' => $customer->email,
            'phone' => $customer->phone,
            'company_name' => $customer->company_name,
            'balance' => (float) $customer->balance,
            'status' => $customer->status,
            'auto_renew_default' => (bool) $customer->auto_renew_default,
            'created_at' => $customer->created_at,
        ];
    }
}
