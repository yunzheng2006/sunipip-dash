<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Transaction;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Spatie\QueryBuilder\AllowedFilter;
use Spatie\QueryBuilder\QueryBuilder;

class CustomerController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = QueryBuilder::for(Customer::class)
            ->allowedFilters([
                AllowedFilter::exact('status'),
                AllowedFilter::partial('customer_name'),
                AllowedFilter::partial('sales_person'),
                AllowedFilter::callback('keyword', function ($query, $value) {
                    $query->where(function ($q) use ($value) {
                        $q->where('customer_name', 'like', "%{$value}%")
                          ->orWhere('username', 'like', "%{$value}%")
                          ->orWhere('phone', 'like', "%{$value}%")
                          ->orWhere('email', 'like', "%{$value}%")
                          ->orWhere('company_name', 'like', "%{$value}%");
                    });
                }),
            ])
            ->withCount(['proxyIps', 'activeSubscriptions'])
            ->allowedSorts(['id', 'customer_name', 'balance', 'created_at'])
            ->defaultSort('-id');

        // 业务员数据隔离
        $user = $request->user();
        if ($user && $user->hasRole('staff')) {
            $query->where('sales_person', $user->name);
        }

        $customers = $query->paginate($request->input('per_page', 15));

        return $this->paginated($customers);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'customer_name' => 'required|string|max:100',
            'username'      => 'nullable|string|max:50|unique:customers,username',
            'password'      => 'nullable|string|min:6',
            'phone'         => 'nullable|string|max:30',
            'email'         => 'nullable|email|max:100',
            'company_name'  => 'nullable|string|max:200',
            'company_id'    => 'nullable|string|max:100',
            'address'       => 'nullable|string|max:500',
            'balance'       => 'nullable|numeric|min:0',
            'sales_person'  => 'nullable|string|max:50',
            'status'        => 'nullable|integer|in:0,1',
            'remark'        => 'nullable|string|max:1000',
        ]);

        $user = $request->user();

        // 业务员（staff）创建：强制写成自己名下（不允许伪造他人业务归属）
        if ($user && $user->hasRole('staff')) {
            $data['sales_person'] = $user->name;
        }

        // 任何角色：如果前端没填业务归属，默认写成当前登录用户的 name
        // 超级管理员 / admin 可以在前端主动填别人的名字来覆盖
        if (empty($data['sales_person']) && $user) {
            $data['sales_person'] = $user->name;
        }

        // 重复客户名校验：customer_name 在数据库内必须唯一
        $exists = Customer::where('customer_name', $data['customer_name'])->exists();
        if ($exists) {
            return $this->error("客户名「{$data['customer_name']}」已存在，不能重复添加", 422);
        }

        $generatedUsername = null;
        $generatedPassword = null;

        if (empty($data['username'])) {
            $generatedUsername = 'snp_' . Str::random(8);
            $data['username'] = $generatedUsername;
        }

        if (empty($data['password'])) {
            $generatedPassword = Str::random(12);
            $data['password'] = $generatedPassword;
        }

        $rawPassword = $data['password'];
        $customer = Customer::create($data);

        return $this->success([
            'customer'   => $customer,
            'credentials' => [
                'username' => $generatedUsername ?? $customer->username,
                'password' => $rawPassword,
            ],
        ], '客户创建成功');
    }

    public function show(Customer $customer): JsonResponse
    {
        $customer->loadCount(['activeSubscriptions', 'proxyIps', 'subscriptions']);
        $customer->load([
            'proxyIps:id,assigned_customer_id,asset_name,ip_address,port,country_name,source_name,status,upstream_expires_at',
            'subscriptions' => fn($q) => $q->with([
                'proxyIp:id,asset_name,ip_address,country_name,source_name',
            ])->latest()->limit(50),
            'transactions' => fn($q) => $q->latest()->limit(20),
        ]);

        return $this->success($customer);
    }

    public function update(Request $request, Customer $customer): JsonResponse
    {
        $data = $request->validate([
            'customer_name' => 'sometimes|string|max:100',
            'phone'         => 'nullable|string|max:30',
            'email'         => 'nullable|email|max:100',
            'company_name'  => 'nullable|string|max:200',
            'company_id'    => 'nullable|string|max:100',
            'address'       => 'nullable|string|max:500',
            'sales_person'  => 'nullable|string|max:50',
            'status'        => 'nullable|integer|in:0,1',
            'remark'        => 'nullable|string|max:1000',
            'password'      => 'nullable|string|min:6|max:100',
        ]);

        // 空字符串不视为修改密码
        if (empty($data['password'])) {
            unset($data['password']);
        }

        // 改 customer_name 时检查重复（排除自身）
        if (isset($data['customer_name']) && $data['customer_name'] !== $customer->customer_name) {
            $duplicate = Customer::where('customer_name', $data['customer_name'])
                ->where('id', '!=', $customer->id)
                ->exists();
            if ($duplicate) {
                return $this->error("客户名「{$data['customer_name']}」已存在", 422);
            }
        }

        // 业务员（staff）只能编辑自己名下的客户，且不能改 sales_person
        $user = $request->user();
        if ($user && $user->hasRole('staff')) {
            if ($customer->sales_person !== $user->name) {
                return $this->error('无权编辑他人客户', 403);
            }
            unset($data['sales_person']);
        }

        $customer->update($data);

        return $this->success($customer->fresh(), '客户更新成功');
    }

    /**
     * 合并客户（仅 super_admin）
     * POST /customers/merge
     *
     * Body: {
     *   source_id: 1,    // 被合并掉的（小号）
     *   target_id: 2,    // 保留的（主号）
     * }
     *
     * 操作（事务内）：
     *   - source 的 balance → target.balance
     *   - source 的所有 proxy_ips / subscriptions / transactions /
     *     ip_assignment_logs / payment_orders / provision_orders 转移到 target
     *   - 写一条特殊的 transaction 记录"合并入账"
     *   - 软删除 source 客户
     */
    public function merge(Request $request): JsonResponse
    {
        $data = $request->validate([
            'source_id' => 'required|integer|exists:customers,id|different:target_id',
            'target_id' => 'required|integer|exists:customers,id',
        ]);

        $user = $request->user();
        if (!$user || !$user->hasRole('super_admin')) {
            return $this->error('仅超级管理员可执行合并操作', 403);
        }

        $source = Customer::lockForUpdate()->find($data['source_id']);
        $target = Customer::lockForUpdate()->find($data['target_id']);
        if (!$source || !$target) {
            return $this->error('客户不存在');
        }

        $stats = [];

        DB::transaction(function () use ($source, $target, $user, &$stats) {
            // 1. 余额转移
            $sourceBalance = (float) $source->balance;
            if ($sourceBalance != 0) {
                $balanceBefore = (float) $target->balance;
                $target->increment('balance', $sourceBalance);
                $balanceAfter = bcadd((string) $balanceBefore, (string) $sourceBalance, 2);

                Transaction::create([
                    'customer_id'    => $target->id,
                    'type'           => 'adjustment',
                    'amount'         => $sourceBalance,
                    'balance_before' => $balanceBefore,
                    'balance_after'  => $balanceAfter,
                    'description'    => sprintf(
                        '合并自客户「%s」(#%d) 的余额',
                        $source->customer_name,
                        $source->id
                    ),
                    'operated_by'    => $user->id,
                ]);
                // 把 source 余额清零，防止万一恢复时双倍
                $source->update(['balance' => 0]);
            }

            // 2. 转移关联数据
            $stats['proxy_ips'] = \App\Models\ProxyIp::where('assigned_customer_id', $source->id)
                ->update(['assigned_customer_id' => $target->id]);

            $stats['subscriptions'] = \App\Models\Subscription::where('customer_id', $source->id)
                ->update(['customer_id' => $target->id]);

            $stats['transactions'] = Transaction::where('customer_id', $source->id)
                ->update(['customer_id' => $target->id]);

            $stats['ip_logs'] = \App\Models\IpAssignmentLog::where('customer_id', $source->id)
                ->update(['customer_id' => $target->id]);

            // payment_orders / provision_orders 是可选的（取决于 PR3 是否上线）
            if (\Schema::hasTable('payment_orders')) {
                $stats['payment_orders'] = \DB::table('payment_orders')
                    ->where('customer_id', $source->id)
                    ->update(['customer_id' => $target->id]);
            }
            if (\Schema::hasTable('provision_orders')) {
                $stats['provision_orders'] = \DB::table('provision_orders')
                    ->where('customer_id', $source->id)
                    ->update(['customer_id' => $target->id]);
            }

            // 3. 软删除 source，并在 remark 留痕
            $source->update([
                'remark' => trim(($source->remark ?? '') . "\n[已合并到 #{$target->id} {$target->customer_name}]"),
                'status' => 0,
            ]);
            $source->delete();
        });

        return $this->success([
            'target_id' => $target->id,
            'target_name' => $target->customer_name,
            'merged_balance' => (float) $source->balance,
            'stats' => $stats,
        ], "已合并「{$source->customer_name}」到「{$target->customer_name}」");
    }

    /**
     * 管理员重置客户密码
     * POST /customers/{customer}/reset-password
     */
    public function resetPassword(Request $request, Customer $customer): JsonResponse
    {
        $data = $request->validate([
            'password' => 'nullable|string|min:6|max:100',
        ]);

        // 留空则自动生成
        $newPassword = $data['password'] ?? \Illuminate\Support\Str::random(10);

        $customer->update(['password' => $newPassword]);

        // 撤销该客户所有已登录的 token（强制重新登录）
        $customer->tokens()->delete();

        return $this->success([
            'password' => $newPassword, // 返回明文给 admin 抄录给客户
        ], '密码已重置，请告知客户');
    }

    public function destroy(Customer $customer): JsonResponse
    {
        $customer->delete();

        return $this->success(null, '客户已删除');
    }

    public function topup(Request $request, Customer $customer): JsonResponse
    {
        $data = $request->validate([
            'amount'      => 'required|numeric|gt:0',
            'description' => 'nullable|string|max:500',
        ]);

        $transaction = DB::transaction(function () use ($customer, $data, $request) {
            $customer = Customer::lockForUpdate()->findOrFail($customer->id);

            $balanceBefore = $customer->balance;
            $customer->increment('balance', $data['amount']);
            $balanceAfter = bcadd($balanceBefore, $data['amount'], 2);

            return Transaction::create([
                'customer_id'    => $customer->id,
                'type'           => 'topup',
                'amount'         => $data['amount'],
                'balance_before' => $balanceBefore,
                'balance_after'  => $balanceAfter,
                'description'    => $data['description'] ?? '余额充值',
                'operated_by'    => $request->user()?->id,
            ]);
        });

        $customer->refresh();

        return $this->success([
            'transaction' => $transaction,
            'balance'     => $customer->balance,
        ], '充值成功');
    }
}
