<?php

namespace App\Services;

use App\Models\Customer;
use App\Models\Subscription;
use App\Models\Transaction;
use Illuminate\Support\Facades\DB;

/**
 * 订阅续费的统一入口
 *
 * 目的：让管理后台批量续费 / 客户自助续费 / auto-renew cron 走同一份逻辑。
 */
class SubscriptionService
{
    /**
     * 单条续费（事务内 + 余额扣款 + 写流水）
     *
     * @throws \Exception 余额不足时抛
     */
    public function renewOne(Subscription $subscription, array $opts, ?int $userId = null): Subscription
    {
        $duration = (int) $opts['duration'];
        $unit = (int) $opts['unit'];
        $newPrice = isset($opts['price']) && $opts['price'] !== null
            ? (float) $opts['price']
            : (float) $subscription->price;
        $isAutoRenew = !empty($opts['auto_renew_triggered']);

        return DB::transaction(function () use ($subscription, $duration, $unit, $newPrice, $userId, $isAutoRenew) {
            $customer = Customer::lockForUpdate()->findOrFail($subscription->customer_id);

            if ((float) $customer->balance < $newPrice) {
                throw new \Exception("余额不足（当前 ¥{$customer->balance}，需要 ¥{$newPrice}）");
            }

            $balanceBefore = $customer->balance;
            $customer->decrement('balance', $newPrice);
            $balanceAfter = bcsub($balanceBefore, $newPrice, 2);

            $baseDate = $subscription->expires_at->isFuture()
                ? $subscription->expires_at
                : now();

            $newExpiresAt = match ($unit) {
                1 => $baseDate->copy()->addDays($duration),
                2 => $baseDate->copy()->addWeeks($duration),
                3 => $baseDate->copy()->addMonths($duration),
                4 => $baseDate->copy()->addYears($duration),
            };

            $subscription->update([
                'price' => $newPrice,
                'duration' => $duration,
                'unit' => $unit,
                'expires_at' => $newExpiresAt,
                'renewed_count' => $subscription->renewed_count + 1,
                'last_renewed_at' => now(),
            ]);

            Transaction::create([
                'customer_id' => $customer->id,
                'type' => 'subscription_renew',
                'amount' => -$newPrice,
                'balance_before' => $balanceBefore,
                'balance_after' => $balanceAfter,
                'related_type' => Subscription::class,
                'related_id' => $subscription->id,
                'description' => $isAutoRenew
                    ? "自动续费订阅#{$subscription->id}"
                    : "续费订阅#{$subscription->id}",
                'operated_by' => $userId,
            ]);

            return $subscription->fresh();
        });
    }
}
