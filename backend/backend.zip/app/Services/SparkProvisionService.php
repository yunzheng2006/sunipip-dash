<?php

namespace App\Services;

use App\Models\IpAssetGroup;
use App\Models\IpAssignmentLog;
use App\Models\ProxyIp;
use App\Models\SparkCountry;
use App\Models\SparkInstance;
use App\Models\SparkOrder;
use App\Models\Subscription;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

/**
 * Spark 开通流程的可复用编排层。
 *
 * 抽离自原 SparkController::provision() / processInstances()，
 * 让管理后台和客户自助面板都能调用相同的逻辑。
 *
 * 使用场景：
 *   - admin: SparkController::provision() HTTP endpoint
 *   - customer: Services\Customer\CheckoutService::purchase()
 *   - notify: Spark 异步回调同步 IP 实例
 */
class SparkProvisionService
{
    public function __construct(protected SparkApiService $spark) {}

    /**
     * 调 Spark CreateProxy 下单，并在立即完成时同步实例。
     *
     * @param array $params {
     *   product_id: string (必须),
     *   product_name?: string,
     *   country_code?: string,   // alpha-3
     *   country_cn?: string,
     *   sale_price?: float,       // 每条 IP 的售价（记录到订阅）
     *   quantity: int,
     *   duration: int,
     *   unit: int,                // 1=day 2=week 3=month 4=year
     *   asset_group_id: int,
     *   ip_group_id?: int,
     *   customer_id?: int,        // 传入则自动分配 + 创建订阅
     *   created_by?: int,         // 操作人 user_id（customer checkout 时传客户侧占位 1）
     * }
     *
     * @return array{
     *   spark_order: SparkOrder,
     *   subscription_ids: int[],
     *   proxy_ip_ids: int[],
     *   status: int,
     *   message: string
     * }
     *
     * @throws \Exception Spark API 失败会 bubble up 给调用方处理
     */
    public function createOrder(array $params): array
    {
        $reqOrderNo = SparkOrder::generateReqOrderNo();

        $result = $this->spark->createProxy(
            $reqOrderNo,
            $params['product_id'],
            (int) $params['duration'],
            (int) $params['unit'],
            (int) $params['quantity']
        );

        $sparkOrder = SparkOrder::create([
            'req_order_no' => $reqOrderNo,
            'spark_order_no' => $result['orderNo'] ?? null,
            'method' => 'CreateProxy',
            'product_id' => $params['product_id'],
            'amount' => (int) $params['quantity'],
            'duration' => (int) $params['duration'],
            'unit' => (int) $params['unit'],
            'cost_amount' => $result['amount'] ?? null,
            'status' => (int) ($result['status'] ?? 1),
            'request_data' => $params,   // 含 customer_id/country/price 等，后续同步时复用
            'response_data' => $result,
        ]);

        $subscriptionIds = [];
        $proxyIpIds = [];

        // status=2 表示 Spark 立即完成开通，直接拉取并落库
        // status=1 时由 spark/notify 异步回调走 syncOrder → processInstances
        // 两条路径都会自动挂转发（在 processInstances 内统一处理）
        if (((int) ($result['status'] ?? 1)) === 2) {
            try {
                $orderData = $this->spark->getOrder($reqOrderNo, $result['orderNo'] ?? null);
                if (!empty($orderData['ipInfo'])) {
                    $res = $this->processInstances($sparkOrder, $orderData['ipInfo'], $params);
                    $subscriptionIds = $res['subscription_ids'];
                    $proxyIpIds = $res['proxy_ip_ids'];
                }
            } catch (\Throwable $e) {
                Log::warning("SparkProvisionService: sync order instances failed: {$e->getMessage()}", [
                    'spark_order_id' => $sparkOrder->id,
                ]);
            }
        }

        return [
            'spark_order' => $sparkOrder,
            'subscription_ids' => $subscriptionIds,
            'proxy_ip_ids' => $proxyIpIds,
            'status' => (int) ($result['status'] ?? 1),
            'message' => match ((int) ($result['status'] ?? 1)) {
                1 => '开通中，请稍后查看',
                2 => '开通完成',
                3 => '开通失败',
                default => '未知状态',
            },
        ];
    }

    /**
     * 同步 Spark 返回的 ipInfo 列表，落库 ProxyIp + SparkInstance + Subscription + 分配日志。
     *
     * 被调场景：
     *   - createOrder 立即返回 status=2
     *   - SparkController::syncOrder() 管理员手动同步
     *   - SparkController::notify() 异步回调
     *
     * @return array{subscription_ids: int[], proxy_ip_ids: int[]}
     */
    public function processInstances(SparkOrder $sparkOrder, array $ipInfoList, array $requestData): array
    {
        $createdSubIds = [];
        $createdIpIds = [];

        DB::transaction(function () use ($sparkOrder, $ipInfoList, $requestData, &$createdSubIds, &$createdIpIds) {
            $customerId = $requestData['customer_id'] ?? null;
            $countryCode = $requestData['country_code'] ?? '';
            $countryCn = $requestData['country_cn'] ?? '';
            $productName = $requestData['product_name'] ?? '';
            $salePrice = (float) ($requestData['sale_price'] ?? 0);
            $duration = (int) ($requestData['duration'] ?? 1);
            $unit = (int) ($requestData['unit'] ?? 3);
            $autoRenew = !empty($requestData['auto_renew']);
            $createdBy = (int) ($requestData['created_by'] ?? auth()->id() ?? 1);

            // 兜底：从资产组读国家
            if (!$countryCode && !empty($requestData['asset_group_id'])) {
                $assetGroup = IpAssetGroup::find($requestData['asset_group_id']);
                if ($assetGroup && $assetGroup->country_code) {
                    $countryCode = $assetGroup->country_code;
                    $countryCn = $countryCn ?: $assetGroup->country_name;
                }
            }
            // 兜底：country_cn 为空时查 area_country
            if ($countryCode && !$countryCn) {
                $countryCn = SparkCountry::getNameByCode($countryCode) ?: $countryCode;
            }

            foreach ($ipInfoList as $ipInfo) {
                $instanceId = $ipInfo['instanceId'];

                // 跳过已存在的实例（幂等）
                if (SparkInstance::where('instance_id', $instanceId)->exists()) {
                    continue;
                }

                $socks5Parts = array_filter([
                    $ipInfo['ip'] ?? '',
                    $ipInfo['port'] ?? '',
                    $ipInfo['username'] ?? '',
                    $ipInfo['password'] ?? '',
                ]);
                $socks5Info = implode(':', $socks5Parts);

                $customerName = null;
                if ($customerId) {
                    $customer = \App\Models\Customer::find($customerId);
                    $customerName = $customer?->customer_name;
                }

                // 每条实例的国家兜底：stateCode 前 3 位
                $ipCountryCode = $countryCode;
                $ipCountryCn = $countryCn;
                if (!$ipCountryCode && !empty($ipInfo['stateCode'])) {
                    $ipCountryCode = substr($ipInfo['stateCode'], 0, 3);
                }
                if ($ipCountryCode && !$ipCountryCn) {
                    $ipCountryCn = SparkCountry::getNameByCode($ipCountryCode) ?: $ipCountryCode;
                }

                $assetName = $customerName
                    ? "{$customerName}-" . ($ipCountryCn ?: $ipCountryCode) . "-{$ipInfo['ip']}"
                    : ($productName ? "{$productName}-{$ipInfo['ip']}" : "Spark-{$ipInfo['ip']}");

                $proxyIp = ProxyIp::create([
                    'asset_group_id' => $requestData['asset_group_id'] ?? null,
                    'ip_group_id' => $requestData['ip_group_id'] ?? null,
                    'socks5_info' => $socks5Info,
                    'ip_address' => $ipInfo['ip'] ?? '',
                    'port' => $ipInfo['port'] ?? 0,
                    'auth_username' => $ipInfo['username'] ?? null,
                    'auth_password' => $ipInfo['password'] ?? null,
                    'protocol' => 'socks5',
                    'asset_name' => $assetName,
                    'country_code' => $ipCountryCode,
                    'country_name' => $ipCountryCn,
                    'ip_type' => 'residential',
                    'nature' => 'static',
                    'source_name' => '斯帕克',
                    'status' => $customerId ? 'assigned' : 'available',
                    'assigned_customer_id' => $customerId,
                    'spark_instance_id' => $instanceId,
                    'upstream_expires_at' => isset($ipInfo['expireAt']) ? date('Y-m-d H:i:s', $ipInfo['expireAt']) : null,
                ]);
                $createdIpIds[] = $proxyIp->id;

                SparkInstance::create([
                    'spark_order_id' => $sparkOrder->id,
                    'proxy_ip_id' => $proxyIp->id,
                    'instance_id' => $instanceId,
                    'ip' => $ipInfo['ip'] ?? null,
                    'port' => $ipInfo['port'] ?? null,
                    'username' => $ipInfo['username'] ?? null,
                    'password' => $ipInfo['password'] ?? null,
                    'type' => $ipInfo['type'] ?? 1,
                    'use_type' => $ipInfo['useType'] ?? 1,
                    'status' => $ipInfo['status'] ?? 1,
                    'flow' => $ipInfo['flow'] ?? null,
                    'balance_flow' => $ipInfo['balanceFlow'] ?? null,
                    'expire_at' => isset($ipInfo['expireAt']) ? date('Y-m-d H:i:s', $ipInfo['expireAt']) : null,
                ]);

                if ($customerId) {
                    $expiresAt = isset($ipInfo['expireAt'])
                        ? \Carbon\Carbon::createFromTimestamp($ipInfo['expireAt'])
                        : now()->addDays(max(1, $duration));

                    $sub = Subscription::create([
                        'customer_id' => $customerId,
                        'proxy_ip_id' => $proxyIp->id,
                        'price' => $salePrice,
                        'duration' => $duration,
                        'unit' => $unit,
                        'started_at' => now(),
                        'expires_at' => $expiresAt,
                        'status' => 'active',
                        'auto_renew' => $autoRenew ? 1 : 0,
                        'created_by' => $createdBy,
                        'remark' => !empty($requestData['source_remark'])
                            ? $requestData['source_remark']
                            : 'Spark API 开通',
                    ]);
                    $createdSubIds[] = $sub->id;

                    IpAssignmentLog::create([
                        'proxy_ip_id' => $proxyIp->id,
                        'customer_id' => $customerId,
                        'subscription_id' => $sub->id,
                        'action' => 'assign',
                        'operated_by' => $createdBy,
                        'remark' => 'Spark 自动开通分配',
                        'created_at' => now(),
                    ]);
                }
            }
        });

        // 转发编排（事务外）— 任何调用 processInstances 的入口都会自动挂转发
        // 注意：requestData 来自 spark_orders.request_data（createOrder 写入时已包含 forward / xui_forward）
        if (!empty($createdSubIds)) {
            if (!empty($requestData['forward'])) {
                $this->attachForwards($createdSubIds, $requestData['forward']);
            }
            if (!empty($requestData['xui_forward'])) {
                $this->attachXuiForwards($createdSubIds, $requestData['xui_forward'], $createdIpIds);
            }
        }

        return [
            'subscription_ids' => $createdSubIds,
            'proxy_ip_ids' => $createdIpIds,
        ];
    }

    /**
     * 为新创建的一批订阅挂 3x-ui vless+reality 中转
     *
     * @param int[] $subscriptionIds
     * @param int[] $proxyIpIds 平行数组，和 subscriptionIds 一一对应（按 processInstances 创建顺序）
     * @param array $xuiForward { xui_panel_id: int }
     */
    private function attachXuiForwards(array $subscriptionIds, array $xuiForward, array $proxyIpIds): void
    {
        $panelId = (int) ($xuiForward['xui_panel_id'] ?? 0);
        if (!$panelId) {
            return;
        }

        $panel = \App\Models\XuiPanel::find($panelId);
        if (!$panel || !$panel->is_active || $panel->is_mirror) {
            Log::warning('SparkProvisionService: invalid xui panel', ['panel_id' => $panelId]);
            return;
        }

        $service = app(\App\Services\Xui\XuiForwardService::class);
        foreach ($subscriptionIds as $idx => $subId) {
            $sub = \App\Models\Subscription::find($subId);
            if (!$sub) continue;
            $proxyIp = \App\Models\ProxyIp::find($proxyIpIds[$idx] ?? 0);
            if (!$proxyIp) {
                $proxyIp = $sub->proxyIp;
            }
            if (!$proxyIp) continue;

            try {
                $service->createForward($panel, $proxyIp, $sub);
            } catch (\Throwable $e) {
                Log::error('SparkProvisionService: attach xui forward failed', [
                    'subscription_id' => $subId,
                    'error' => $e->getMessage(),
                ]);
            }
        }
    }

    /**
     * 为新创建的一批订阅挂转发规则（事务外调用）
     *
     * @param int[] $subscriptionIds
     * @param array $forward {
     *   device_group_id: int (ny_device_groups.id 本地),
     *   speed_limit_mbps: int|null,
     *   forward_fee: float (单条单月费用)
     * }
     */
    private function attachForwards(array $subscriptionIds, array $forward): void
    {
        $deviceGroupId = (int) ($forward['device_group_id'] ?? 0);
        if (!$deviceGroupId) {
            return;
        }

        $deviceGroup = \App\Models\NyDeviceGroup::find($deviceGroupId);
        if (!$deviceGroup || !$deviceGroup->is_enabled) {
            Log::warning('SparkProvisionService: invalid device_group_id for forward', [
                'device_group_id' => $deviceGroupId,
            ]);
            return;
        }

        $speedMbps = isset($forward['speed_limit_mbps']) && $forward['speed_limit_mbps'] !== null
            ? (int) $forward['speed_limit_mbps']
            : null;
        $fee = (float) ($forward['forward_fee'] ?? 0);

        $service = app(\App\Services\Ny\NyForwardService::class);
        foreach ($subscriptionIds as $subId) {
            $sub = \App\Models\Subscription::find($subId);
            if (!$sub) continue;
            try {
                $service->attachToSubscription($sub, $deviceGroup, $speedMbps, $fee);
            } catch (\Throwable $e) {
                Log::error('SparkProvisionService: attach forward failed', [
                    'subscription_id' => $subId,
                    'error' => $e->getMessage(),
                ]);
                // 失败的 forward 会标 status=failed，admin 可手动重试
            }
        }
    }
}
