<?php

namespace App\Services\Customer;

use App\Models\Customer;
use App\Models\IpAssetGroup;
use App\Models\SparkPricingRule;
use App\Models\Subscription;
use App\Models\Transaction;
use App\Services\SparkProvisionService;
use App\Services\SparkStockCacheService;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * 客户自助下单流程。
 *
 * 步骤：
 *   1. 查 SparkPricingRule 拿对客售价；无则拒绝
 *   2. 从缓存产品列表中按 country_code 筛选有库存的 Spark 产品
 *   3. 计算总价 = 单价 × 数量 × 时长倍数
 *   4. 事务内：锁客户余额 → 校验 → 扣款 → 写 Transaction → 调 SparkProvisionService
 *   5. 返回：订阅 ID、扣款金额、新余额
 *
 * 说明：
 *   - 目前仅支持 unit=3(月)，避免时长换算歧义
 *   - Spark API 失败会整个事务回滚（余额不动）
 */
class CheckoutService
{
    public function __construct(protected SparkProvisionService $provision) {}

    /**
     * @param Customer $customer
     * @param string $countryCode  alpha-3
     * @param int $quantity
     * @param int $duration  时长数值
     * @param int $unit      仅支持 3 (月)
     * @param bool $autoRenew
     *
     * @return array{
     *   spark_order_id: int,
     *   subscription_ids: int[],
     *   proxy_ip_ids: int[],
     *   charged: float,
     *   new_balance: float,
     *   status: int,
     *   message: string,
     * }
     *
     * @throws ValidationException
     */
    public function purchase(
        Customer $customer,
        string $countryCode,
        int $quantity,
        int $duration,
        int $unit = 3,
        bool $autoRenew = false,
    ): array {
        $countryCode = strtoupper($countryCode);

        if ($quantity < 1 || $quantity > 10) {
            throw ValidationException::withMessages(['quantity' => '数量需在 1-10 之间']);
        }
        if ($duration < 1 || $duration > 12) {
            throw ValidationException::withMessages(['duration' => '时长需在 1-12 之间']);
        }
        if ($unit !== 3) {
            throw ValidationException::withMessages(['unit' => '当前仅支持按月购买']);
        }

        // 1. 查定价规则
        $rule = SparkPricingRule::findByCountry($countryCode);
        if (!$rule) {
            throw ValidationException::withMessages(['country_code' => '该国家暂未配置定价，请联系客服']);
        }
        $unitPrice = (float) $rule->monthly_price;

        // 2. 库存校验
        $byCountry = SparkStockCacheService::stockByCountry();
        $stockInfo = $byCountry[$countryCode] ?? null;
        if (!$stockInfo || $stockInfo['stock'] < $quantity) {
            throw ValidationException::withMessages([
                'quantity' => sprintf('库存不足，当前可用 %d 条', $stockInfo['stock'] ?? 0),
            ]);
        }

        // 3. 选一个可用 Spark 产品
        $products = SparkStockCacheService::products();
        $candidates = array_values(array_filter(
            $products,
            fn($p) => strtoupper($p['country_code'] ?? '') === $countryCode
                  && ($p['inventory'] ?? 0) >= $quantity
        ));
        if (empty($candidates)) {
            throw ValidationException::withMessages([
                'country_code' => '该国家暂无足够的产品库存（单产品需 ≥ 数量）',
            ]);
        }
        // 选库存最多的那个，失败率最低
        usort($candidates, fn($a, $b) => ($b['inventory'] ?? 0) <=> ($a['inventory'] ?? 0));
        $product = $candidates[0];

        // 4. Spark 资产组（去取一个 spark_api 类型的组作为容器）
        $assetGroup = IpAssetGroup::where('source_type', 'spark_api')
            ->where('status', 1)
            ->first();
        if (!$assetGroup) {
            throw ValidationException::withMessages([
                'country_code' => '平台暂未配置 Spark 资产组，请联系客服',
            ]);
        }

        // 5. 总价计算：月单价 × 数量 × 月数
        $total = round($unitPrice * $quantity * $duration, 2);

        // 6. 事务：锁余额 → 扣款 → 调 Spark
        try {
            $result = DB::transaction(function () use (
                $customer, $total, $quantity, $duration, $unit, $autoRenew,
                $countryCode, $product, $rule, $assetGroup, $unitPrice
            ) {
                $fresh = Customer::lockForUpdate()->findOrFail($customer->id);
                if ((float) $fresh->balance < $total) {
                    throw ValidationException::withMessages([
                        'balance' => sprintf('余额不足：当前 ¥%.2f，需要 ¥%.2f', $fresh->balance, $total),
                    ]);
                }

                $balanceBefore = $fresh->balance;
                $fresh->decrement('balance', $total);
                $balanceAfter = bcsub($balanceBefore, $total, 2);

                // country_cn 用于 asset_name 拼装
                $countryCn = \App\Models\SparkCountry::getNameByCode($countryCode) ?: $countryCode;

                Transaction::create([
                    'customer_id' => $fresh->id,
                    'type' => 'purchase', // VARCHAR(20)，避免 subscription_purchase 溢出
                    'amount' => -$total,
                    'balance_before' => $balanceBefore,
                    'balance_after' => $balanceAfter,
                    'description' => sprintf(
                        '自助购买 %s × %d 条 × %d 月',
                        $countryCn, $quantity, $duration
                    ),
                    'operated_by' => null, // 客户自助
                ]);

                // 调 Spark 下单（同步或挂起）
                $provisionResult = $this->provision->createOrder([
                    'product_id' => $product['product_id'],
                    'product_name' => $product['product_name'] ?? '',
                    'country_code' => $countryCode,
                    'country_cn' => $countryCn,
                    'sale_price' => round($unitPrice * $duration, 2), // 每条 IP 的总售价（duration 个月）
                    'quantity' => $quantity,
                    'duration' => $duration,
                    'unit' => $unit,
                    'asset_group_id' => $assetGroup->id,
                    'customer_id' => $fresh->id,
                    'auto_renew' => $autoRenew,
                    'source_remark' => '客户自助下单',
                    'created_by' => 1, // 系统占位
                ]);

                return [
                    'spark_order' => $provisionResult['spark_order'],
                    'subscription_ids' => $provisionResult['subscription_ids'],
                    'proxy_ip_ids' => $provisionResult['proxy_ip_ids'],
                    'charged' => $total,
                    'new_balance' => (float) $balanceAfter,
                    'status' => $provisionResult['status'],
                    'message' => $provisionResult['message'],
                ];
            });
        } catch (ValidationException $e) {
            throw $e;
        } catch (\Throwable $e) {
            // 其他异常：事务已回滚，余额未变
            throw ValidationException::withMessages([
                'spark' => '开通失败：' . $e->getMessage(),
            ]);
        }

        return [
            'spark_order_id' => $result['spark_order']->id,
            'subscription_ids' => $result['subscription_ids'],
            'proxy_ip_ids' => $result['proxy_ip_ids'],
            'charged' => $result['charged'],
            'new_balance' => $result['new_balance'],
            'status' => $result['status'],
            'message' => $result['message'],
        ];
    }
}
