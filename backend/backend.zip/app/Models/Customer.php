<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Sanctum\HasApiTokens;

class Customer extends Authenticatable
{
    use HasApiTokens, HasFactory, SoftDeletes;

    protected $fillable = [
        'customer_name', 'username', 'password', 'phone', 'email',
        'email_verified_at', 'company_name', 'company_id', 'address', 'balance',
        'sales_person', 'status', 'remark',
        'last_login_at', 'last_login_ip', 'auto_renew_default',
    ];

    protected $hidden = ['password'];

    protected function casts(): array
    {
        return [
            'password' => 'hashed',
            'balance' => 'decimal:2',
            'status' => 'integer',
            'email_verified_at' => 'datetime',
            'last_login_at' => 'datetime',
            'auto_renew_default' => 'boolean',
        ];
    }

    public function toArray(): array
    {
        $array = parent::toArray();
        $map = [
            'proxyIps' => 'proxy_ips',
            'activeSubscriptions' => 'active_subscriptions',
            'proxy_ips_count' => 'proxy_ips_count',
            'active_subscriptions_count' => 'active_subscriptions_count',
        ];
        if (array_key_exists('proxyIps', $array)) {
            $array['proxy_ips'] = $array['proxyIps'];
            unset($array['proxyIps']);
        }
        if (array_key_exists('activeSubscriptions', $array)) {
            $array['active_subscriptions'] = $array['activeSubscriptions'];
            unset($array['activeSubscriptions']);
        }
        return $array;
    }

    public function subscriptions()
    {
        return $this->hasMany(Subscription::class);
    }

    public function activeSubscriptions()
    {
        return $this->hasMany(Subscription::class)->where('status', 'active');
    }

    public function transactions()
    {
        return $this->hasMany(Transaction::class);
    }

    public function proxyIps()
    {
        return $this->hasMany(ProxyIp::class, 'assigned_customer_id');
    }

    public function provisionOrders()
    {
        return $this->hasMany(ProvisionOrder::class);
    }
}
