<?php

use App\Http\Controllers\Api\V1\ActivityLogController;
use App\Http\Controllers\Api\V1\AuthController;
use App\Http\Controllers\Api\V1\Customer\AuthController as CustomerAuthController;
use App\Http\Controllers\Api\V1\Customer\BalanceController as CustomerBalanceController;
use App\Http\Controllers\Api\V1\Customer\DashboardController as CustomerDashboardController;
use App\Http\Controllers\Api\V1\Customer\ProfileController as CustomerProfileController;
use App\Http\Controllers\Api\V1\Customer\ProxyIpController as CustomerProxyIpController;
use App\Http\Controllers\Api\V1\Customer\StoreController as CustomerStoreController;
use App\Http\Controllers\Api\V1\Customer\SubscriptionController as CustomerSubscriptionController;
use App\Http\Controllers\Api\V1\CustomerController;
use App\Http\Controllers\Api\V1\DashboardController;
use App\Http\Controllers\Api\V1\IpAssetGroupController;
use App\Http\Controllers\Api\V1\IpGroupController;
use App\Http\Controllers\Api\V1\AgentApiController;
use App\Http\Controllers\Api\V1\DnsMonitorController;
use App\Http\Controllers\Api\V1\NyPanelController;
use App\Http\Controllers\Api\V1\XuiPanelController;
use App\Http\Controllers\Api\V1\Payment\EPayNotifyController;
use App\Http\Controllers\Api\V1\PaymentGatewayController;
use App\Http\Controllers\Api\V1\PricingRuleController;
use App\Http\Controllers\Api\V1\ProxyIpController;
use App\Http\Controllers\Api\V1\RoleController;
use App\Http\Controllers\Api\V1\SparkController;
use App\Http\Controllers\Api\V1\SparkPricingRuleController;
use App\Http\Controllers\Api\V1\SubscriptionController;
use App\Http\Controllers\Api\V1\TransactionController;
use App\Http\Controllers\Api\V1\UserController;
use App\Http\Controllers\Api\V1\WebhookController;
use Illuminate\Support\Facades\Route;

// 公开接口
Route::prefix('v1')->group(function () {
    Route::post('auth/login', [AuthController::class, 'login']);

    // Spark 回调 (公开，不需要认证)
    Route::get('spark/notify', [SparkController::class, 'notify']);

    // 客户自助面板 - 公开
    Route::prefix('customer')->group(function () {
        Route::post('auth/register', [CustomerAuthController::class, 'register']);
        Route::post('auth/login', [CustomerAuthController::class, 'login']);
    });

    // 支付网关异步回调（公开路由，签名校验代替身份认证）
    // EPay 使用 GET 方式回调
    Route::match(['get', 'post'], 'payment/epay/notify/{gateway}', [EPayNotifyController::class, 'notify']);

    // DNS 容灾 Agent 接口（公开，X-Agent-Key header 鉴权）
    Route::post('agent/heartbeat', [AgentApiController::class, 'heartbeat']);
    Route::post('agent/report', [AgentApiController::class, 'report']);
});

// 客户自助面板 - 需登录
// auth:sanctum: 校验 token 合法
// ability:customer: 校验 token 签发时的 ability，仅 customer 登录的 token 能通过
// customer.auth: 额外校验 tokenable 是 Customer 实例且账号启用
Route::prefix('v1/customer')
    ->middleware(['auth:sanctum', 'ability:customer', 'customer.auth'])
    ->group(function () {
        // 认证 + 资料
        Route::get('auth/me', [CustomerAuthController::class, 'me']);
        Route::post('auth/logout', [CustomerAuthController::class, 'logout']);
        Route::put('auth/password', [CustomerAuthController::class, 'changePassword']);

        Route::get('profile', [CustomerProfileController::class, 'show']);
        Route::put('profile', [CustomerProfileController::class, 'update']);

        // 首页
        Route::get('dashboard', [CustomerDashboardController::class, 'index']);

        // 商店
        Route::get('store/countries', [CustomerStoreController::class, 'countries']);
        Route::get('store/countries/{code}', [CustomerStoreController::class, 'show']);
        Route::post('store/checkout', [CustomerStoreController::class, 'checkout']);

        // 订阅
        Route::get('subscriptions', [CustomerSubscriptionController::class, 'index']);
        Route::get('subscriptions/{id}', [CustomerSubscriptionController::class, 'show']);
        Route::post('subscriptions/{id}/renew', [CustomerSubscriptionController::class, 'renew']);
        Route::post('subscriptions/{id}/refund', [CustomerSubscriptionController::class, 'refund']);
        Route::put('subscriptions/{id}/auto-renew', [CustomerSubscriptionController::class, 'toggleAutoRenew']);

        // 我的 IP
        Route::get('ips', [CustomerProxyIpController::class, 'index']);
        Route::get('ips/export', [CustomerProxyIpController::class, 'export']);
        Route::get('ips/export-qr', [CustomerProxyIpController::class, 'exportQr']);
        Route::get('ips/{id}', [CustomerProxyIpController::class, 'show']);

        // 账单
        Route::get('balance', [CustomerBalanceController::class, 'balance']);
        Route::get('transactions', [CustomerBalanceController::class, 'transactions']);

        // 充值
        Route::get('topup/methods', [CustomerBalanceController::class, 'topupMethods']);
        Route::post('topup/create', [CustomerBalanceController::class, 'createTopup']);
        Route::get('topup/orders', [CustomerBalanceController::class, 'topupOrders']);
        Route::get('topup/orders/{orderNo}', [CustomerBalanceController::class, 'topupOrder']);
    });

// 需要认证的接口 + 活动日志记录
// ability:admin 确保只接受 admin token（阻止 customer token 误入管理 API）
Route::prefix('v1')->middleware(['auth:sanctum', 'ability:admin', 'log.activity'])->group(function () {

    // 认证（所有登录用户可访问）
    Route::get('auth/me', [AuthController::class, 'me']);
    Route::post('auth/logout', [AuthController::class, 'logout']);
    Route::put('auth/password', [AuthController::class, 'changePassword']);

    // 仪表盘
    Route::get('dashboard/stats', [DashboardController::class, 'stats'])->middleware('perm:dashboard.view');
    Route::get('dashboard/expiring', [DashboardController::class, 'expiring'])->middleware('perm:dashboard.view');
    Route::get('dashboard/recent', [DashboardController::class, 'recent'])->middleware('perm:dashboard.view');

    // 客户管理
    Route::get('customers', [CustomerController::class, 'index'])->middleware('perm:customer.view');
    Route::post('customers', [CustomerController::class, 'store'])->middleware('perm:customer.create');
    // 注意：merge 必须放在 {customer} 之前，否则会被 route-model-binding 拦截
    Route::post('customers/merge', [CustomerController::class, 'merge'])->middleware('perm:customer.edit');
    Route::get('customers/{customer}', [CustomerController::class, 'show'])->middleware('perm:customer.view');
    Route::put('customers/{customer}', [CustomerController::class, 'update'])->middleware('perm:customer.edit');
    Route::delete('customers/{customer}', [CustomerController::class, 'destroy'])->middleware('perm:customer.delete');
    Route::post('customers/{customer}/topup', [CustomerController::class, 'topup'])->middleware('perm:customer.topup');
    Route::post('customers/{customer}/reset-password', [CustomerController::class, 'resetPassword'])->middleware('perm:customer.edit');

    // IP资产管理
    Route::get('proxy-ips', [ProxyIpController::class, 'index'])->middleware('perm:ip.view');
    Route::post('proxy-ips', [ProxyIpController::class, 'store'])->middleware('perm:ip.create');
    Route::get('proxy-ips/{proxy_ip}', [ProxyIpController::class, 'show'])->middleware('perm:ip.view');
    Route::put('proxy-ips/{proxy_ip}', [ProxyIpController::class, 'update'])->middleware('perm:ip.edit');
    Route::delete('proxy-ips/{proxy_ip}', [ProxyIpController::class, 'destroy'])->middleware('perm:ip.delete');
    Route::post('proxy-ips/import', [ProxyIpController::class, 'import'])->middleware('perm:ip.import');
    Route::post('proxy-ips/{proxy_ip}/assign', [ProxyIpController::class, 'assign'])->middleware('perm:ip.assign');
    Route::post('proxy-ips/{proxy_ip}/unassign', [ProxyIpController::class, 'unassign'])->middleware('perm:ip.unassign');
    Route::post('proxy-ips/{proxy_ip}/release', [ProxyIpController::class, 'release'])->middleware('perm:ip.delete');
    Route::post('proxy-ips/{proxy_ip}/verify-spark-release', [ProxyIpController::class, 'verifySparkRelease'])->middleware('perm:spark.manage');
    Route::post('proxy-ips/{proxy_ip}/retry-spark-release', [ProxyIpController::class, 'retrySparkRelease'])->middleware('perm:spark.manage');
    Route::get('proxy-ips-stats', [ProxyIpController::class, 'stats'])->middleware('perm:ip.view');

    // 资产组管理
    Route::get('asset-groups/all', [IpAssetGroupController::class, 'all'])->middleware('perm:asset_group.view');
    Route::get('asset-groups', [IpAssetGroupController::class, 'index'])->middleware('perm:asset_group.view');
    Route::get('asset-groups/{ipAssetGroup}', [IpAssetGroupController::class, 'show'])->middleware('perm:asset_group.view');
    Route::post('asset-groups', [IpAssetGroupController::class, 'store'])->middleware('perm:asset_group.create');
    Route::put('asset-groups/{ipAssetGroup}', [IpAssetGroupController::class, 'update'])->middleware('perm:asset_group.edit');
    Route::delete('asset-groups/{ipAssetGroup}', [IpAssetGroupController::class, 'destroy'])->middleware('perm:asset_group.delete');

    // IP组管理
    Route::get('ip-groups/all', [IpGroupController::class, 'all'])->middleware('perm:asset_group.view');
    Route::get('ip-groups', [IpGroupController::class, 'index'])->middleware('perm:asset_group.view');
    Route::get('ip-groups/{ipGroup}', [IpGroupController::class, 'show'])->middleware('perm:asset_group.view');
    Route::post('ip-groups', [IpGroupController::class, 'store'])->middleware('perm:asset_group.create');
    Route::put('ip-groups/{ipGroup}', [IpGroupController::class, 'update'])->middleware('perm:asset_group.edit');
    Route::delete('ip-groups/{ipGroup}', [IpGroupController::class, 'destroy'])->middleware('perm:asset_group.delete');

    // Spark API
    Route::get('spark/debug', [SparkController::class, 'debug'])->middleware('perm:spark.view');
    Route::get('spark/products', [SparkController::class, 'products'])->middleware('perm:spark.view_stock');
    Route::get('spark/stock-by-country', [SparkController::class, 'stockByCountry'])->middleware('perm:spark.view_stock');
    Route::post('spark/provision', [SparkController::class, 'provision'])->middleware('perm:spark.manage');
    Route::post('spark/sync-order/{sparkOrder}', [SparkController::class, 'syncOrder'])->middleware('perm:spark.manage');
    Route::post('spark/renew', [SparkController::class, 'renew'])->middleware('perm:spark.manage');
    Route::post('spark/release', [SparkController::class, 'release'])->middleware('perm:spark.manage');
    Route::get('spark/orders', [SparkController::class, 'orders'])->middleware('perm:spark.view');
    Route::post('spark/match', [SparkController::class, 'matchInstance'])->middleware('perm:spark.manage');
    Route::post('spark/bulk-match', [SparkController::class, 'bulkMatch'])->middleware('perm:spark.manage');
    Route::post('spark/sync-all', [SparkController::class, 'syncAll'])->middleware('perm:spark.manage');

    // Spark 地区查询（基础数据，所有登录用户可查）
    Route::get('spark/areas/countries', [SparkController::class, 'countries']);
    Route::get('spark/areas/states', [SparkController::class, 'states']);
    Route::get('spark/areas/cities', [SparkController::class, 'cities']);
    Route::post('spark/areas/translate', [SparkController::class, 'translateCountries']);

    // 订阅管理
    Route::get('subscriptions/expiring', [SubscriptionController::class, 'expiring'])->middleware('perm:subscription.view');
    Route::get('subscriptions/available-ips', [SubscriptionController::class, 'availableIps'])->middleware('perm:subscription.view');
    Route::post('subscriptions/create-order', [SubscriptionController::class, 'createOrder'])->middleware('perm:subscription.create');
    Route::get('subscriptions', [SubscriptionController::class, 'index'])->middleware('perm:subscription.view');
    // 注意：静态路径必须放在 {subscription} 之前，否则会被 route-model-binding 拦截
    Route::get('subscriptions/batch-forward-status/{batchId}', [SubscriptionController::class, 'batchForwardStatus'])->middleware('perm:subscription.view');
    Route::get('subscriptions/batch-xui-forward-status/{batchId}', [SubscriptionController::class, 'batchXuiForwardStatus'])->middleware('perm:subscription.view');
    Route::post('subscriptions/bulk-renew', [SubscriptionController::class, 'bulkRenew'])->middleware('perm:subscription.renew');
    Route::post('subscriptions/batch-attach-forward', [SubscriptionController::class, 'batchAttachForward'])->middleware('perm:subscription.edit_price');
    Route::post('subscriptions/batch-attach-xui-forward', [SubscriptionController::class, 'batchAttachXuiForward'])->middleware('perm:subscription.create');
    Route::post('subscriptions/batch-update-expiry', [SubscriptionController::class, 'batchUpdateExpiry'])->middleware('perm:subscription.edit_price');
    Route::get('subscriptions/{subscription}', [SubscriptionController::class, 'show'])->middleware('perm:subscription.view');
    Route::post('subscriptions/{subscription}/renew', [SubscriptionController::class, 'renew'])->middleware('perm:subscription.renew');
    Route::post('subscriptions/{subscription}/cancel', [SubscriptionController::class, 'cancel'])->middleware('perm:subscription.cancel');
    Route::post('subscriptions/{subscription}/refund', [SubscriptionController::class, 'refund'])->middleware('perm:subscription.cancel');

    // 交易流水
    Route::get('transactions', [TransactionController::class, 'index'])->middleware('perm:transaction.view');
    Route::get('transactions/{transaction}', [TransactionController::class, 'show'])->middleware('perm:transaction.view');

    // 定价规则
    Route::get('pricing-rules/lookup', [PricingRuleController::class, 'lookup'])->middleware('perm:pricing.view');
    Route::get('pricing-rules', [PricingRuleController::class, 'index'])->middleware('perm:pricing.view');
    Route::get('pricing-rules/{pricingRule}', [PricingRuleController::class, 'show'])->middleware('perm:pricing.view');
    Route::post('pricing-rules', [PricingRuleController::class, 'store'])->middleware('perm:pricing.manage');
    Route::put('pricing-rules/{pricingRule}', [PricingRuleController::class, 'update'])->middleware('perm:pricing.manage');
    Route::delete('pricing-rules/{pricingRule}', [PricingRuleController::class, 'destroy'])->middleware('perm:pricing.manage');

    // Spark IP 定价（按国家代码绑定）
    Route::get('spark-pricing/countries', [SparkPricingRuleController::class, 'countries'])->middleware('perm:pricing.view');
    Route::get('spark-pricing/lookup', [SparkPricingRuleController::class, 'lookup'])->middleware('perm:pricing.view');
    Route::get('spark-pricing', [SparkPricingRuleController::class, 'index'])->middleware('perm:pricing.view');
    Route::post('spark-pricing', [SparkPricingRuleController::class, 'store'])->middleware('perm:pricing.manage');
    Route::get('spark-pricing/{sparkPricingRule}', [SparkPricingRuleController::class, 'show'])->middleware('perm:pricing.view');
    Route::put('spark-pricing/{sparkPricingRule}', [SparkPricingRuleController::class, 'update'])->middleware('perm:pricing.manage');
    Route::delete('spark-pricing/{sparkPricingRule}', [SparkPricingRuleController::class, 'destroy'])->middleware('perm:pricing.manage');

    // 后台用户管理
    Route::get('users', [UserController::class, 'index'])->middleware('perm:user.view');
    Route::get('users/{user}', [UserController::class, 'show'])->middleware('perm:user.view');
    Route::post('users', [UserController::class, 'store'])->middleware('perm:user.create');
    Route::put('users/{user}', [UserController::class, 'update'])->middleware('perm:user.edit');
    Route::delete('users/{user}', [UserController::class, 'destroy'])->middleware('perm:user.delete');
    Route::post('users/{user}/reset-password', [UserController::class, 'resetPassword'])->middleware('perm:user.edit');

    // 角色与权限管理
    Route::get('roles/all-permissions', [RoleController::class, 'allPermissions'])->middleware('perm:user.assign_role');
    Route::get('roles', [RoleController::class, 'index'])->middleware('perm:user.assign_role');
    Route::get('roles/{role}', [RoleController::class, 'show'])->middleware('perm:user.assign_role');
    Route::post('roles', [RoleController::class, 'store'])->middleware('perm:user.assign_role');
    Route::put('roles/{role}', [RoleController::class, 'update'])->middleware('perm:user.assign_role');
    Route::delete('roles/{role}', [RoleController::class, 'destroy'])->middleware('perm:user.assign_role');

    // 活动日志
    Route::get('activity-logs', [ActivityLogController::class, 'index'])->middleware('perm:activity_log.view');
    Route::get('activity-logs/{activityLog}', [ActivityLogController::class, 'show'])->middleware('perm:activity_log.view');
    Route::post('activity-logs/clean', [ActivityLogController::class, 'clean'])->middleware('perm:activity_log.view_all');

    // NY 面板管理（超级管理员）
    Route::get('ny-panels/enabled-device-groups', [NyPanelController::class, 'enabledDeviceGroups'])->middleware('perm:subscription.create');
    Route::get('ny-panels', [NyPanelController::class, 'index'])->middleware('perm:setting.manage');
    Route::post('ny-panels', [NyPanelController::class, 'store'])->middleware('perm:setting.manage');
    Route::get('ny-panels/{nyPanel}', [NyPanelController::class, 'show'])->middleware('perm:setting.manage');
    Route::put('ny-panels/{nyPanel}', [NyPanelController::class, 'update'])->middleware('perm:setting.manage');
    Route::delete('ny-panels/{nyPanel}', [NyPanelController::class, 'destroy'])->middleware('perm:setting.manage');
    Route::post('ny-panels/{nyPanel}/test', [NyPanelController::class, 'testConnection'])->middleware('perm:setting.manage');
    Route::post('ny-panels/{nyPanel}/sync-device-groups', [NyPanelController::class, 'syncDeviceGroups'])->middleware('perm:setting.manage');
    Route::put('ny-panels/{nyPanel}/device-groups', [NyPanelController::class, 'updateDeviceGroups'])->middleware('perm:setting.manage');

    // 3x-ui 面板管理
    // 注意：xui_inbound 模型必须走显式参数名 {xuiInbound} 才能被 Laravel 自动 RMB
    Route::delete('xui-panels/inbounds/{xuiInbound}', [XuiPanelController::class, 'deleteInbound'])->middleware('perm:setting.manage');
    // 低权限入口：业务员下单 / 批量转发时调（只返回启用中的主面板，不含密钥）
    Route::get('xui-panels/usable', [XuiPanelController::class, 'usable'])->middleware('perm:subscription.create');
    Route::get('xui-panels', [XuiPanelController::class, 'index'])->middleware('perm:setting.manage');
    Route::post('xui-panels', [XuiPanelController::class, 'store'])->middleware('perm:setting.manage');
    Route::get('xui-panels/{xuiPanel}', [XuiPanelController::class, 'show'])->middleware('perm:setting.manage');
    Route::put('xui-panels/{xuiPanel}', [XuiPanelController::class, 'update'])->middleware('perm:setting.manage');
    Route::delete('xui-panels/{xuiPanel}', [XuiPanelController::class, 'destroy'])->middleware('perm:setting.manage');
    Route::post('xui-panels/{xuiPanel}/test', [XuiPanelController::class, 'testConnection'])->middleware('perm:setting.manage');
    Route::post('xui-panels/{xuiPanel}/create-forward', [XuiPanelController::class, 'createForward'])->middleware('perm:setting.manage');
    Route::post('xui-panels/{xuiPanel}/batch-create-forward', [XuiPanelController::class, 'batchCreateForward'])->middleware('perm:setting.manage');
    Route::get('xui-panels/{xuiPanel}/batch-status/{batchId}', [XuiPanelController::class, 'batchStatus'])->middleware('perm:setting.manage');
    Route::post('xui-panels/{xuiPanel}/sync-all-to-mirror', [XuiPanelController::class, 'syncAllToMirror'])->middleware('perm:setting.manage');
    Route::post('xui-panels/inbounds/{xuiInbound}/resync-mirror', [XuiPanelController::class, 'resyncMirror'])->middleware('perm:setting.manage');
    Route::get('xui-panels/{xuiPanel}/inbounds', [XuiPanelController::class, 'listInbounds'])->middleware('perm:setting.manage');

    // DNS 容灾监控（超级管理员）
    Route::get('dns-agents', [DnsMonitorController::class, 'agents'])->middleware('perm:setting.manage');
    Route::post('dns-agents', [DnsMonitorController::class, 'storeAgent'])->middleware('perm:setting.manage');
    Route::delete('dns-agents/{dnsAgent}', [DnsMonitorController::class, 'deleteAgent'])->middleware('perm:setting.manage');
    Route::post('dns-agents/{dnsAgent}/regenerate-key', [DnsMonitorController::class, 'regenerateAgentKey'])->middleware('perm:setting.manage');

    Route::get('dns-targets', [DnsMonitorController::class, 'targets'])->middleware('perm:setting.manage');
    Route::post('dns-targets', [DnsMonitorController::class, 'storeTarget'])->middleware('perm:setting.manage');
    Route::get('dns-targets/{dnsTarget}', [DnsMonitorController::class, 'showTarget'])->middleware('perm:setting.manage');
    Route::put('dns-targets/{dnsTarget}', [DnsMonitorController::class, 'updateTarget'])->middleware('perm:setting.manage');
    Route::delete('dns-targets/{dnsTarget}', [DnsMonitorController::class, 'deleteTarget'])->middleware('perm:setting.manage');
    Route::get('dns-targets/{dnsTarget}/probes', [DnsMonitorController::class, 'probeHistory'])->middleware('perm:setting.manage');
    Route::get('dns-targets/{dnsTarget}/events', [DnsMonitorController::class, 'failoverHistory'])->middleware('perm:setting.manage');
    Route::post('dns-targets/{dnsTarget}/failover', [DnsMonitorController::class, 'manualFailover'])->middleware('perm:setting.manage');
    Route::post('dns-targets/{dnsTarget}/failback', [DnsMonitorController::class, 'manualFailback'])->middleware('perm:setting.manage');

    // 支付网关管理（超级管理员）
    Route::get('payment-gateways', [PaymentGatewayController::class, 'index'])->middleware('perm:setting.manage');
    Route::post('payment-gateways', [PaymentGatewayController::class, 'store'])->middleware('perm:setting.manage');
    Route::get('payment-gateways/{paymentGateway}', [PaymentGatewayController::class, 'show'])->middleware('perm:setting.manage');
    Route::put('payment-gateways/{paymentGateway}', [PaymentGatewayController::class, 'update'])->middleware('perm:setting.manage');
    Route::delete('payment-gateways/{paymentGateway}', [PaymentGatewayController::class, 'destroy'])->middleware('perm:setting.manage');
    Route::post('payment-gateways/{paymentGateway}/test-sign', [PaymentGatewayController::class, 'testSign'])->middleware('perm:setting.manage');

    // Webhook 通知管理
    Route::get('webhooks/events', [WebhookController::class, 'events'])->middleware('perm:webhook.view');
    Route::get('webhooks/logs', [WebhookController::class, 'logs'])->middleware('perm:notification.view');
    Route::get('webhooks', [WebhookController::class, 'index'])->middleware('perm:webhook.view');
    Route::post('webhooks', [WebhookController::class, 'store'])->middleware('perm:webhook.manage');
    Route::get('webhooks/{webhook}', [WebhookController::class, 'show'])->middleware('perm:webhook.view');
    Route::put('webhooks/{webhook}', [WebhookController::class, 'update'])->middleware('perm:webhook.manage');
    Route::delete('webhooks/{webhook}', [WebhookController::class, 'destroy'])->middleware('perm:webhook.manage');
    Route::post('webhooks/{webhook}/test', [WebhookController::class, 'test'])->middleware('perm:webhook.test');
});
