<?php

use Illuminate\Support\Facades\Schedule;

// 每天 09:00 检查订阅到期 / 客户余额，触发 webhook 通知
Schedule::command('subscriptions:check-expiring')
    ->dailyAt('09:00')
    ->timezone('Asia/Shanghai')
    ->withoutOverlapping()
    ->runInBackground();

// 每 5 分钟刷新 Spark 产品库存缓存（客户自助面板用）
Schedule::command('spark:refresh-stock')
    ->everyFiveMinutes()
    ->withoutOverlapping(10)
    ->runInBackground();

// 每天 02:00 处理开启自动续费的订阅
Schedule::command('subscriptions:auto-renew')
    ->dailyAt('02:00')
    ->timezone('Asia/Shanghai')
    ->withoutOverlapping()
    ->runInBackground();
