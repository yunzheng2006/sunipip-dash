<?php

use Illuminate\Support\Facades\Route;

// 所有非 API 请求都返回 Vue SPA 的 index.html
Route::get('/{any?}', function () {
    $indexPath = public_path('index.html');
    if (file_exists($indexPath)) {
        return file_get_contents($indexPath);
    }
    return 'Frontend not built yet. Run: cd frontend && npm run build';
})->where('any', '^(?!api).*$');
