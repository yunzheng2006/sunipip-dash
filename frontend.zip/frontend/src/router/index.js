import { createRouter, createWebHistory } from 'vue-router'
import { isLoggedIn } from '@/utils/auth'

const routes = [
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/views/auth/Login.vue'),
    meta: { requiresAuth: false },
  },
  {
    path: '/',
    component: () => import('@/components/layout/AppLayout.vue'),
    meta: { requiresAuth: true },
    children: [
      {
        path: '',
        redirect: '/dashboard',
      },
      {
        path: 'dashboard',
        name: 'Dashboard',
        component: () => import('@/views/dashboard/Index.vue'),
        meta: { title: '仪表盘' },
      },
      {
        path: 'customers',
        name: 'CustomerList',
        component: () => import('@/views/customers/Index.vue'),
        meta: { title: '客户列表' },
      },
      {
        path: 'customers/create',
        name: 'CustomerCreate',
        component: () => import('@/views/customers/Create.vue'),
        meta: { title: '新建客户' },
      },
      {
        path: 'customers/:id',
        name: 'CustomerDetail',
        component: () => import('@/views/customers/Detail.vue'),
        meta: { title: '客户详情' },
      },
      {
        path: 'proxy-ips',
        name: 'ProxyIpList',
        component: () => import('@/views/proxy-ips/Index.vue'),
        meta: { title: 'IP列表' },
      },
      {
        path: 'proxy-ips/import',
        name: 'ProxyIpImport',
        component: () => import('@/views/proxy-ips/Import.vue'),
        meta: { title: '批量导入' },
      },
      {
        path: 'proxy-ips/:id',
        name: 'ProxyIpDetail',
        component: () => import('@/views/proxy-ips/Detail.vue'),
        meta: { title: 'IP详情' },
      },
      {
        path: 'asset-groups',
        name: 'AssetGroupList',
        component: () => import('@/views/asset-groups/Index.vue'),
        meta: { title: '资产组' },
      },
      {
        path: 'ip-groups',
        name: 'IpGroupList',
        component: () => import('@/views/ip-groups/Index.vue'),
        meta: { title: 'IP组' },
      },
      {
        path: 'subscriptions',
        name: 'SubscriptionList',
        component: () => import('@/views/subscriptions/Index.vue'),
        meta: { title: '订阅列表' },
      },
      {
        path: 'subscriptions/create',
        name: 'CreateOrder',
        component: () => import('@/views/subscriptions/CreateOrder.vue'),
        meta: { title: '创建订单' },
      },
      {
        path: 'subscriptions/:id',
        name: 'SubscriptionDetail',
        component: () => import('@/views/subscriptions/Detail.vue'),
        meta: { title: '订阅详情' },
      },
      {
        path: 'billing/transactions',
        name: 'TransactionList',
        component: () => import('@/views/billing/Transactions.vue'),
        meta: { title: '交易流水' },
      },
      {
        path: 'billing/pricing',
        name: 'PricingRuleList',
        component: () => import('@/views/billing/PricingRules.vue'),
        meta: { title: '定价规则' },
      },
      {
        path: 'users',
        name: 'UserList',
        component: () => import('@/views/users/Index.vue'),
        meta: { title: '用户管理', permission: 'user.view' },
      },
      {
        path: 'roles',
        name: 'RoleList',
        component: () => import('@/views/roles/Index.vue'),
        meta: { title: '权限组管理', permission: 'user.assign_role' },
      },
      {
        path: 'activity-logs',
        name: 'ActivityLogs',
        component: () => import('@/views/activity-logs/Index.vue'),
        meta: { title: '操作日志' },
      },
      {
        path: 'settings',
        name: 'Settings',
        component: () => import('@/views/settings/Index.vue'),
        meta: { title: '系统设置' },
      },
      {
        path: 'settings/webhooks',
        name: 'Webhooks',
        component: () => import('@/views/settings/Webhooks.vue'),
        meta: { title: 'Webhook 通知', permission: 'webhook.view' },
      },
      {
        path: 'settings/notification-logs',
        name: 'NotificationLogs',
        component: () => import('@/views/settings/NotificationLogs.vue'),
        meta: { title: '通知记录', permission: 'notification.view' },
      },
      {
        path: 'settings/payment-gateways',
        name: 'PaymentGateways',
        component: () => import('@/views/settings/PaymentGateways.vue'),
        meta: { title: '支付网关', permission: 'setting.manage' },
      },
      {
        path: 'settings/ny-panels',
        name: 'NyPanels',
        component: () => import('@/views/settings/NyPanels.vue'),
        meta: { title: 'NY 面板', permission: 'setting.manage' },
      },
      {
        path: 'settings/xui-panels',
        name: 'XuiPanels',
        component: () => import('@/views/settings/XuiPanels.vue'),
        meta: { title: '3x-ui 面板', permission: 'setting.manage' },
      },
      {
        path: 'settings/dns-monitor',
        name: 'DnsMonitor',
        component: () => import('@/views/settings/DnsMonitor.vue'),
        meta: { title: 'DNS 容灾监控', permission: 'setting.manage' },
      },
    ],
  },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

router.beforeEach(async (to, from, next) => {
  const requiresAuth = to.matched.some((record) => record.meta.requiresAuth !== false)

  if (requiresAuth && !isLoggedIn()) {
    return next('/login')
  }
  if (to.path === '/login' && isLoggedIn()) {
    return next('/dashboard')
  }

  // 权限检查
  if (requiresAuth && to.meta?.permission) {
    const { useAuthStore } = await import('@/stores/auth')
    const auth = useAuthStore()
    // 确保用户信息已加载
    if (!auth.user) {
      try { await auth.fetchUser() } catch { /* ignore */ }
    }
    if (auth.user) {
      const isSuper = auth.user.roles?.includes('super_admin')
      const hasPerm = isSuper || (auth.user.permissions || []).includes(to.meta.permission)
      if (!hasPerm) {
        return next('/dashboard')
      }
    }
  }

  next()
})

export default router
