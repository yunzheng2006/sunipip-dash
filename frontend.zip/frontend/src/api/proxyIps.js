import request from '@/utils/request'

export function getProxyIps(params) {
  return request.get('/proxy-ips', { params })
}

export function getProxyIp(id) {
  return request.get(`/proxy-ips/${id}`)
}

export function createProxyIp(data) {
  return request.post('/proxy-ips', data)
}

export function updateProxyIp(id, data) {
  return request.put(`/proxy-ips/${id}`, data)
}

export function deleteProxyIp(id) {
  return request.delete(`/proxy-ips/${id}`)
}

export function assignProxyIp(id, data) {
  return request.post(`/proxy-ips/${id}/assign`, data)
}

export function unassignProxyIp(id) {
  return request.post(`/proxy-ips/${id}/unassign`)
}

export function getProxyIpStats() {
  return request.get('/proxy-ips/stats')
}

export function importProxyIps(formData) {
  return request.post('/proxy-ips/import', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

export function releaseProxyIp(id, data) {
  return request.post(`/proxy-ips/${id}/release`, data)
}

export function verifySparkRelease(id) {
  return request.post(`/proxy-ips/${id}/verify-spark-release`)
}

export function retrySparkRelease(id) {
  return request.post(`/proxy-ips/${id}/retry-spark-release`)
}
