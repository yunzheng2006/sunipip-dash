import request from '@/utils/request'

export function getSparkProducts(params) {
  return request.get('/spark/products', { params })
}

export function sparkProvision(data) {
  return request.post('/spark/provision', data)
}

export function sparkRenew(data) {
  return request.post('/spark/renew', data)
}

export function sparkRelease(data) {
  return request.post('/spark/release', data)
}

export function getSparkOrders(params) {
  return request.get('/spark/orders', { params })
}

export function syncSparkOrder(sparkOrderId) {
  return request.post(`/spark/sync-order/${sparkOrderId}`)
}
