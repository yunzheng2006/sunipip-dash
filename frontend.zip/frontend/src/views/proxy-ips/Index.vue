<template>
  <div class="proxy-ip-list">
    <h2 class="page-title">IP资产管理</h2>

    <el-card class="search-card">
      <el-form :inline="true" :model="searchForm">
        <el-form-item label="状态">
          <el-select v-model="searchForm.status" placeholder="全部" clearable style="width: 120px">
            <el-option label="可用" value="available" />
            <el-option label="已分配" value="assigned" />
            <el-option label="已过期" value="expired" />
            <el-option label="已停用" value="disabled" />
            <el-option label="已释放" value="released" />
          </el-select>
        </el-form-item>
        <el-form-item label="资产名称">
          <el-input v-model="searchForm.asset_name" placeholder="模糊搜索" clearable style="width: 150px" />
        </el-form-item>
        <el-form-item label="IP地址">
          <el-input v-model="searchForm.ip_address" placeholder="模糊搜索" clearable style="width: 150px" />
        </el-form-item>
        <el-form-item label="IP归属">
          <el-input v-model="searchForm.source_name" placeholder="如斯帕克" clearable style="width: 120px" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="handleSearch"><el-icon><Search /></el-icon>搜索</el-button>
          <el-button @click="handleReset">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-card>
      <el-table :data="tableData" v-loading="loading" stripe>
        <el-table-column prop="id" label="ID" width="60" />
        <el-table-column label="资产名称" min-width="200" show-overflow-tooltip>
          <template #default="{ row }">
            <span style="font-weight: 500">{{ row.asset_name || '-' }}</span>
          </template>
        </el-table-column>
        <el-table-column label="IP:端口" min-width="200">
          <template #default="{ row }">
            <div class="mono">{{ row.ip_address }}:{{ row.port }}</div>
            <div v-if="row.active_subscription?.forward_rule?.status === 'active'" class="forward-display">
              <el-icon :size="11"><Share /></el-icon>
              <span class="mono">
                {{ row.active_subscription.forward_rule.device_group?.custom_connect_host
                   || row.active_subscription.forward_rule.device_group?.original_connect_host }}:{{ row.active_subscription.forward_rule.listen_port }}
              </span>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="地区" width="100">
          <template #default="{ row }">{{ row.country_name || '-' }}</template>
        </el-table-column>
        <el-table-column label="IP归属" width="100">
          <template #default="{ row }">
            <el-tag size="small" type="info" effect="plain">{{ row.source_name || '-' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="归属客户" min-width="120">
          <template #default="{ row }">
            <span v-if="row.assigned_customer" style="color: #E8913A; font-weight: 500">
              {{ row.assigned_customer.customer_name }}
            </span>
            <span v-else style="color: #C0C4CC">未分配</span>
          </template>
        </el-table-column>
        <el-table-column label="状态" width="90" align="center">
          <template #default="{ row }">
            <el-tag :type="statusTag(row.status)" size="small">{{ statusLabel(row.status) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="到期时间" width="110">
          <template #default="{ row }">
            <span :style="{ color: isExpiringSoon(row.upstream_expires_at) ? '#F56C6C' : '' }">
              {{ formatDate(row.upstream_expires_at) }}
            </span>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="200" align="center" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" link size="small" @click="$router.push(`/proxy-ips/${row.id}`)">详情</el-button>
            <el-button v-if="row.status !== 'released'" type="warning" link size="small" @click="openRelease(row)">释放</el-button>
            <el-button type="danger" link size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-wrap">
        <el-pagination
          v-model:current-page="pagination.page"
          v-model:page-size="pagination.per_page"
          :total="pagination.total"
          :page-sizes="[20, 50, 100, 200]"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="fetchData"
          @current-change="fetchData"
        />
      </div>
    </el-card>

    <!-- Release Dialog -->
    <el-dialog v-model="releaseVisible" title="释放IP资产" width="500px">
      <el-alert type="warning" :closable="false" show-icon style="margin-bottom: 16px">
        释放后该IP将不再出现在可分配资源池，但历史记录会保留。此操作不可逆。
      </el-alert>
      <el-form :model="releaseForm" label-width="100px">
        <el-form-item label="资产名称">
          <el-input :value="releaseTarget?.asset_name" disabled />
        </el-form-item>
        <el-form-item label="IP地址">
          <el-input :value="releaseTarget ? `${releaseTarget.ip_address}:${releaseTarget.port}` : ''" disabled />
        </el-form-item>
        <el-form-item label="IP归属">
          <el-input :value="releaseTarget?.source_name" disabled />
        </el-form-item>
        <el-form-item label="释放原因">
          <el-input v-model="releaseForm.reason" type="textarea" :rows="3" placeholder="选填，如IP失效、无法使用等" />
        </el-form-item>
        <el-form-item v-if="releaseTarget?.source_name === '斯帕克' && releaseTarget?.spark_instance_id" label="Spark释放">
          <el-switch v-model="releaseForm.auto_release_spark" />
          <span style="margin-left: 8px; font-size: 12px; color: #909399">
            同时调用 Spark API 释放（可获得上游退款）
          </span>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="releaseVisible = false">取消</el-button>
        <el-button type="danger" :loading="releaseLoading" @click="submitRelease">确认释放</el-button>
      </template>
    </el-dialog>

  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import dayjs from 'dayjs'
import { getProxyIps, deleteProxyIp, releaseProxyIp } from '@/api/proxyIps'

const loading = ref(false)
const tableData = ref([])
const searchForm = reactive({ status: '', asset_name: '', ip_address: '', source_name: '' })
const pagination = reactive({ page: 1, per_page: 20, total: 0 })

function formatDate(d) { return d ? dayjs(d).format('YYYY-MM-DD') : '-' }
function isExpiringSoon(d) { return d && dayjs(d).diff(dayjs(), 'day') <= 7 && dayjs(d).isAfter(dayjs()) }
function statusTag(s) { return { available: 'success', assigned: 'warning', expired: 'danger', disabled: 'info', released: 'info' }[s] || 'info' }
function statusLabel(s) { return { available: '可用', assigned: '已分配', expired: '已过期', disabled: '已停用', released: '已释放' }[s] || s }

async function fetchData() {
  loading.value = true
  try {
    const params = { page: pagination.page, per_page: pagination.per_page }
    if (searchForm.status) params['filter[status]'] = searchForm.status
    if (searchForm.asset_name) params['filter[asset_name]'] = searchForm.asset_name
    if (searchForm.ip_address) params['filter[ip_address]'] = searchForm.ip_address
    if (searchForm.source_name) params['filter[source_name]'] = searchForm.source_name
    const res = await getProxyIps(params)
    tableData.value = res?.items || []
    pagination.total = res?.pagination?.total || 0
  } catch { /* handled */ }
  finally { loading.value = false }
}

function handleSearch() { pagination.page = 1; fetchData() }
function handleReset() {
  Object.keys(searchForm).forEach(k => searchForm[k] = '')
  pagination.page = 1; fetchData()
}

// Release
const releaseVisible = ref(false)
const releaseLoading = ref(false)
const releaseTarget = ref(null)
const releaseForm = reactive({ reason: '', auto_release_spark: true })

function openRelease(row) {
  releaseTarget.value = row
  releaseForm.reason = ''
  releaseForm.auto_release_spark = true
  releaseVisible.value = true
}

async function submitRelease() {
  releaseLoading.value = true
  try {
    await releaseProxyIp(releaseTarget.value.id, { ...releaseForm })
    ElMessage.success('IP 已释放')
    releaseVisible.value = false
    fetchData()
  } catch { /* handled */ }
  finally { releaseLoading.value = false }
}

async function handleDelete(row) {
  try {
    await ElMessageBox.confirm(`删除IP「${row.ip_address}」？`, '确认', { type: 'warning' })
    await deleteProxyIp(row.id)
    ElMessage.success('已删除')
    fetchData()
  } catch { /* cancelled */ }
}

onMounted(fetchData)
</script>

<style lang="scss" scoped>
.proxy-ip-list {
  .page-title { margin: 0 0 20px; font-size: 20px; font-weight: 600; color: #2C3E50; }
  .search-card { margin-bottom: 16px; :deep(.el-card__body) { padding-bottom: 2px; } }
  .pagination-wrap { display: flex; justify-content: flex-end; margin-top: 16px; }
  .mono { font-family: 'SF Mono', Consolas, Monaco, monospace; font-size: 13px; color: #4A5568; }
  .forward-display {
    margin-top: 3px;
    font-size: 11px;
    color: #E8913A;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 2px 6px;
    background: linear-gradient(135deg, #FFF8F0, #FDF0E2);
    border-radius: 4px;
    border: 1px solid #F5D9B5;
    .mono { color: #E8913A; font-weight: 600; font-size: 11px; }
  }
}
</style>
