<template>
  <div class="customer-detail" v-loading="loading">
    <div class="page-header">
      <el-button @click="$router.back()" :icon="ArrowLeft">返回</el-button>
      <h2 class="page-title">客户详情</h2>
    </div>

    <template v-if="customer">
      <!-- Basic Info -->
      <el-card class="info-card">
        <template #header>
          <div class="card-header">
            <span><el-icon><User /></el-icon> 客户信息</span>
            <div style="display: flex; gap: 8px">
              <el-button type="warning" size="small" plain @click="openResetPassword">
                <el-icon><Key /></el-icon> 重置密码
              </el-button>
              <el-button type="success" size="small" @click="topupVisible = true">
                <el-icon><Wallet /></el-icon> 充值
              </el-button>
            </div>
          </div>
        </template>
        <el-descriptions :column="3" border>
          <el-descriptions-item label="客户名称">
            <strong>{{ customer.customer_name }}</strong>
          </el-descriptions-item>
          <el-descriptions-item label="登录用户名">
            <span class="mono">{{ customer.username }}</span>
          </el-descriptions-item>
          <el-descriptions-item label="状态">
            <el-tag :type="customer.status === 1 ? 'success' : 'info'" size="small">
              {{ customer.status === 1 ? '正常' : '停用' }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="业务归属">
            <el-tag size="small" type="warning" effect="plain">{{ customer.sales_person || '-' }}</el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="账户余额">
            <span style="color: #E8913A; font-weight: 600; font-size: 16px">
              ¥{{ Number(customer.balance || 0).toFixed(2) }}
            </span>
          </el-descriptions-item>
          <el-descriptions-item label="活跃订阅">
            {{ customer.active_subscriptions_count || 0 }} / {{ customer.proxy_ips_count || 0 }}
          </el-descriptions-item>
          <el-descriptions-item label="手机">{{ customer.phone || '-' }}</el-descriptions-item>
          <el-descriptions-item label="邮箱">{{ customer.email || '-' }}</el-descriptions-item>
          <el-descriptions-item label="公司">{{ customer.company_name || '-' }}</el-descriptions-item>
          <el-descriptions-item label="地址" :span="3">{{ customer.address || '-' }}</el-descriptions-item>
          <el-descriptions-item v-if="customer.remark" label="备注" :span="3">{{ customer.remark }}</el-descriptions-item>
        </el-descriptions>
      </el-card>

      <el-tabs v-model="activeTab">
        <el-tab-pane label="持有IP资产" name="ips">
          <el-card>
            <el-table :data="customer.proxy_ips || []" stripe size="small">
              <el-table-column prop="id" label="ID" width="60" />
              <el-table-column label="资产名称" min-width="200" show-overflow-tooltip>
                <template #default="{ row }">
                  <el-link type="primary" @click="$router.push(`/proxy-ips/${row.id}`)">
                    {{ row.asset_name || '-' }}
                  </el-link>
                </template>
              </el-table-column>
              <el-table-column label="IP:端口" min-width="160">
                <template #default="{ row }">
                  <span class="mono">{{ row.ip_address }}:{{ row.port }}</span>
                </template>
              </el-table-column>
              <el-table-column prop="country_name" label="地区" width="80" />
              <el-table-column label="IP归属" width="100">
                <template #default="{ row }">
                  <el-tag size="small" type="info" effect="plain">{{ row.source_name || '-' }}</el-tag>
                </template>
              </el-table-column>
              <el-table-column label="状态" width="90" align="center">
                <template #default="{ row }">
                  <el-tag :type="ipStatusTag(row.status)" size="small">{{ ipStatusLabel(row.status) }}</el-tag>
                </template>
              </el-table-column>
              <el-table-column label="上游到期" width="110">
                <template #default="{ row }">{{ formatDate(row.upstream_expires_at) }}</template>
              </el-table-column>
            </el-table>
            <el-empty v-if="!customer.proxy_ips?.length" description="暂无持有资产" />
          </el-card>
        </el-tab-pane>

        <el-tab-pane label="订阅列表" name="subs">
          <el-card>
            <el-table :data="customer.subscriptions || []" stripe size="small">
              <el-table-column prop="id" label="ID" width="60" />
              <el-table-column label="资产名称" min-width="200" show-overflow-tooltip>
                <template #default="{ row }">{{ row.proxy_ip?.asset_name || '-' }}</template>
              </el-table-column>
              <el-table-column label="地区" width="80">
                <template #default="{ row }">{{ row.proxy_ip?.country_name || '-' }}</template>
              </el-table-column>
              <el-table-column label="单价/月" width="100" align="right">
                <template #default="{ row }">¥{{ Number(row.price || 0).toFixed(2) }}</template>
              </el-table-column>
              <el-table-column label="开始时间" width="110">
                <template #default="{ row }">{{ formatDate(row.started_at) }}</template>
              </el-table-column>
              <el-table-column label="到期时间" width="110">
                <template #default="{ row }">{{ formatDate(row.expires_at) }}</template>
              </el-table-column>
              <el-table-column label="状态" width="90" align="center">
                <template #default="{ row }">
                  <el-tag :type="subStatusTag(row.status)" size="small">{{ subStatusLabel(row.status) }}</el-tag>
                </template>
              </el-table-column>
              <el-table-column label="" width="80" align="center">
                <template #default="{ row }">
                  <el-button type="primary" link size="small" @click="$router.push(`/subscriptions/${row.id}`)">详情</el-button>
                </template>
              </el-table-column>
            </el-table>
            <el-empty v-if="!customer.subscriptions?.length" description="暂无订阅记录" />
          </el-card>
        </el-tab-pane>

        <el-tab-pane label="交易流水" name="tx">
          <el-card>
            <el-table :data="customer.transactions || []" stripe size="small">
              <el-table-column label="时间" width="160">
                <template #default="{ row }">{{ formatDateTime(row.created_at) }}</template>
              </el-table-column>
              <el-table-column label="类型" width="100">
                <template #default="{ row }">
                  <el-tag :type="txTag(row.type)" size="small">{{ txLabel(row.type) }}</el-tag>
                </template>
              </el-table-column>
              <el-table-column label="金额" width="120" align="right">
                <template #default="{ row }">
                  <span :style="{ color: row.amount >= 0 ? '#67C23A' : '#F56C6C', fontWeight: 600 }">
                    {{ row.amount >= 0 ? '+' : '' }}¥{{ Number(row.amount).toFixed(2) }}
                  </span>
                </template>
              </el-table-column>
              <el-table-column label="余额(变更后)" width="120" align="right">
                <template #default="{ row }">¥{{ Number(row.balance_after || 0).toFixed(2) }}</template>
              </el-table-column>
              <el-table-column label="备注" min-width="200">
                <template #default="{ row }">{{ row.description || '-' }}</template>
              </el-table-column>
            </el-table>
            <el-empty v-if="!customer.transactions?.length" description="暂无交易记录" />
          </el-card>
        </el-tab-pane>
      </el-tabs>
    </template>

    <!-- Topup Dialog -->
    <el-dialog v-model="topupVisible" title="客户充值" width="450px">
      <el-form :model="topupForm" label-width="80px">
        <el-form-item label="客户">
          <el-input :value="customer?.customer_name" disabled />
        </el-form-item>
        <el-form-item label="当前余额">
          <el-input :value="`¥${Number(customer?.balance || 0).toFixed(2)}`" disabled />
        </el-form-item>
        <el-form-item label="充值金额">
          <el-input-number v-model="topupForm.amount" :min="0.01" :precision="2" style="width: 100%" />
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="topupForm.description" type="textarea" :rows="2" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="topupVisible = false">取消</el-button>
        <el-button type="primary" :loading="topupLoading" @click="submitTopup">确认充值</el-button>
      </template>
    </el-dialog>

    <!-- Reset Password Dialog -->
    <el-dialog v-model="resetPasswordVisible" title="重置客户密码" width="480px">
      <el-alert type="warning" :closable="false" show-icon style="margin-bottom: 16px">
        重置后该客户当前登录会话将被踢出，请务必把新密码转告客户。
      </el-alert>
      <el-form :model="resetPasswordForm" label-width="100px">
        <el-form-item label="客户">
          <el-input :value="customer?.customer_name" disabled />
        </el-form-item>
        <el-form-item label="登录用户名">
          <el-input :value="customer?.username" disabled class="mono" />
        </el-form-item>
        <el-form-item label="新密码">
          <el-input
            v-model="resetPasswordForm.password"
            placeholder="留空将自动生成 10 位随机密码"
            show-password
          />
          <div style="font-size: 12px; color: #909399; margin-top: 4px">
            至少 6 位字符；留空则由系统自动生成
          </div>
        </el-form-item>
      </el-form>

      <!-- 重置成功后展示生成的密码 -->
      <el-alert
        v-if="resetResult"
        type="success"
        :closable="false"
        show-icon
        style="margin-top: 12px"
      >
        <template #title>
          密码已更新：
          <span class="mono" style="font-weight: 600; color: #E8913A">{{ resetResult }}</span>
          <el-button link type="primary" size="small" @click="copyText(resetResult)" style="margin-left: 8px">
            复制
          </el-button>
        </template>
      </el-alert>

      <template #footer>
        <el-button @click="closeResetPassword">{{ resetResult ? '关闭' : '取消' }}</el-button>
        <el-button
          v-if="!resetResult"
          type="warning"
          :loading="resetPasswordLoading"
          @click="submitResetPassword"
        >
          确认重置
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { ArrowLeft, User, Wallet, Key } from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import dayjs from 'dayjs'
import { getCustomer, topupCustomer, resetCustomerPassword } from '@/api/customers'

const route = useRoute()
const loading = ref(false)
const customer = ref(null)
const activeTab = ref('ips')

function formatDate(d) { return d ? dayjs(d).format('YYYY-MM-DD') : '-' }
function formatDateTime(d) { return d ? dayjs(d).format('YYYY-MM-DD HH:mm') : '-' }
function ipStatusTag(s) { return { available: 'success', assigned: 'warning', expired: 'danger', disabled: 'info' }[s] || 'info' }
function ipStatusLabel(s) { return { available: '可用', assigned: '已分配', expired: '已过期', disabled: '已停用' }[s] || s }
function subStatusTag(s) { return { active: 'success', expired: 'danger', cancelled: 'info' }[s] || 'info' }
function subStatusLabel(s) { return { active: '活跃', expired: '已过期', cancelled: '已取消' }[s] || s }
function txTag(t) { return { topup: 'success', deduction: 'danger', refund: 'warning' }[t] || 'info' }
function txLabel(t) { return { topup: '充值', deduction: '扣费', refund: '退款', adjustment: '调整' }[t] || t }

async function fetchData() {
  loading.value = true
  try {
    const res = await getCustomer(route.params.id)
    customer.value = res
  } catch { /* handled */ }
  finally { loading.value = false }
}

// Topup
const topupVisible = ref(false)
const topupLoading = ref(false)
const topupForm = reactive({ amount: 100, description: '' })

async function submitTopup() {
  if (!topupForm.amount || topupForm.amount <= 0) {
    ElMessage.warning('请输入充值金额')
    return
  }
  topupLoading.value = true
  try {
    await topupCustomer(customer.value.id, { ...topupForm })
    ElMessage.success('充值成功')
    topupVisible.value = false
    topupForm.amount = 100
    topupForm.description = ''
    fetchData()
  } catch { /* handled */ }
  finally { topupLoading.value = false }
}

// Reset Password
const resetPasswordVisible = ref(false)
const resetPasswordLoading = ref(false)
const resetPasswordForm = reactive({ password: '' })
const resetResult = ref('')

function openResetPassword() {
  resetPasswordForm.password = ''
  resetResult.value = ''
  resetPasswordVisible.value = true
}

function closeResetPassword() {
  resetPasswordVisible.value = false
  resetPasswordForm.password = ''
  resetResult.value = ''
}

async function submitResetPassword() {
  if (resetPasswordForm.password && resetPasswordForm.password.length < 6) {
    ElMessage.warning('密码至少 6 位')
    return
  }
  try {
    await ElMessageBox.confirm(
      `确认重置「${customer.value.customer_name}」的登录密码？该客户的所有会话将被踢出。`,
      '重置确认',
      { type: 'warning' }
    )
  } catch { return }

  resetPasswordLoading.value = true
  try {
    const res = await resetCustomerPassword(customer.value.id, {
      password: resetPasswordForm.password || undefined,
    })
    resetResult.value = res?.password || ''
    ElMessage.success('密码重置成功')
  } catch { /* handled */ }
  finally { resetPasswordLoading.value = false }
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text)
    ElMessage.success('已复制到剪贴板')
  } catch {
    ElMessage.warning('复制失败，请手动复制')
  }
}

onMounted(fetchData)
</script>

<style lang="scss" scoped>
.customer-detail {
  .page-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 20px;
    .page-title { margin: 0; font-size: 20px; font-weight: 600; color: #2C3E50; }
  }
  .info-card {
    margin-bottom: 16px;
    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-weight: 600;
      .el-icon { margin-right: 6px; vertical-align: middle; }
    }
  }
  .mono { font-family: 'SF Mono', Consolas, Monaco, monospace; font-size: 13px; }
}
</style>
