<template>
  <div class="customer-list">
    <h2 class="page-title">客户管理</h2>

    <!-- Search Bar -->
    <el-card class="search-card">
      <el-form :inline="true" :model="searchForm">
        <el-form-item label="关键字">
          <el-input
            v-model="searchForm.keyword"
            placeholder="客户名 / 用户名 / 手机 / 邮箱"
            clearable
            style="width: 220px"
            @keyup.enter="handleSearch"
          />
        </el-form-item>
        <el-form-item label="业务归属">
          <el-input v-model="searchForm.sales_person" placeholder="输入业务人员" clearable />
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="searchForm.status" placeholder="全部" clearable style="width: 120px">
            <el-option label="正常" value="active" />
            <el-option label="停用" value="inactive" />
            <el-option label="欠费" value="overdue" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="handleSearch">
            <el-icon><Search /></el-icon>搜索
          </el-button>
          <el-button @click="handleReset">重置</el-button>
          <el-button type="success" @click="$router.push('/customers/create')">
            <el-icon><Plus /></el-icon>新建客户
          </el-button>
          <el-button v-if="isSuperAdmin" type="warning" @click="openMerge">
            <el-icon><Connection /></el-icon>合并客户
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <!-- Table -->
    <el-card>
      <el-table :data="tableData" v-loading="loading" stripe>
        <el-table-column prop="id" label="ID" width="70" />
        <el-table-column prop="customer_name" label="客户名称" min-width="130" />
        <el-table-column prop="username" label="用户名" min-width="120" />
        <el-table-column prop="phone" label="手机" min-width="120" />
        <el-table-column prop="balance" label="余额" min-width="100" align="right">
          <template #default="{ row }">
            <span :class="{ 'text-danger': row.balance < 0 }">
              {{ formatMoney(row.balance) }}
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="sales_person" label="业务归属" min-width="100" />
        <el-table-column prop="status" label="状态" width="90" align="center">
          <template #default="{ row }">
            <el-tag :type="statusTagType(row.status)" size="small">
              {{ statusLabel(row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="ip_count" label="IP数量" width="80" align="center" />
        <el-table-column label="操作" width="240" align="center" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" link size="small" @click="$router.push(`/customers/${row.id}`)">
              查看
            </el-button>
            <el-button type="warning" link size="small" @click="openEdit(row)">
              编辑
            </el-button>
            <el-button type="success" link size="small" @click="openTopup(row)">
              充值
            </el-button>
            <el-button type="danger" link size="small" @click="handleDelete(row)">
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-wrap">
        <el-pagination
          v-model:current-page="pagination.page"
          v-model:page-size="pagination.page_size"
          :total="pagination.total"
          :page-sizes="[10, 20, 50, 100, 200, 500]"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="onSizeChange"
          @current-change="fetchData"
        />
      </div>
    </el-card>

    <!-- Topup Dialog -->
    <el-dialog v-model="topupDialogVisible" title="客户充值" width="450px">
      <el-form ref="topupFormRef" :model="topupForm" :rules="topupRules" label-width="80px">
        <el-form-item label="客户">
          <el-input :value="topupCustomer?.customer_name" disabled />
        </el-form-item>
        <el-form-item label="充值金额" prop="amount">
          <el-input-number v-model="topupForm.amount" :min="0.01" :precision="2" style="width: 100%" />
        </el-form-item>
        <el-form-item label="备注" prop="description">
          <el-input v-model="topupForm.description" type="textarea" :rows="3" placeholder="充值备注信息" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="topupDialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="topupLoading" @click="submitTopup">确认充值</el-button>
      </template>
    </el-dialog>

    <!-- Edit Dialog -->
    <el-dialog v-model="editDialogVisible" title="编辑客户信息" width="560px" :close-on-click-modal="false">
      <el-form ref="editFormRef" :model="editForm" :rules="editRules" label-width="100px">
        <el-form-item label="客户名称" prop="customer_name">
          <el-input v-model="editForm.customer_name" />
        </el-form-item>
        <el-form-item label="登录用户名">
          <el-input :value="editingCustomer?.username" disabled />
          <div class="hint">用户名不可修改</div>
        </el-form-item>
        <el-form-item label="业务归属" prop="sales_person">
          <el-input
            v-model="editForm.sales_person"
            placeholder="业务员姓名"
            :disabled="!isSuperAdmin && !isAdmin"
          />
          <div v-if="!isSuperAdmin && !isAdmin" class="hint">业务员无权修改归属</div>
        </el-form-item>
        <el-form-item label="手机">
          <el-input v-model="editForm.phone" />
        </el-form-item>
        <el-form-item label="邮箱">
          <el-input v-model="editForm.email" />
        </el-form-item>
        <el-form-item label="公司名">
          <el-input v-model="editForm.company_name" />
        </el-form-item>
        <el-form-item label="公司编号">
          <el-input v-model="editForm.company_id" />
        </el-form-item>
        <el-form-item label="地址">
          <el-input v-model="editForm.address" type="textarea" :rows="2" />
        </el-form-item>
        <el-form-item label="状态">
          <el-radio-group v-model="editForm.status">
            <el-radio :value="1">正常</el-radio>
            <el-radio :value="0">停用</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="editForm.remark" type="textarea" :rows="2" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="editDialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="editLoading" @click="submitEdit">保存</el-button>
      </template>
    </el-dialog>

    <!-- Merge Customers Dialog -->
    <el-dialog
      v-model="mergeDialogVisible"
      title="合并客户"
      width="640px"
      :close-on-click-modal="false"
    >
      <el-alert type="warning" :closable="false" show-icon style="margin-bottom: 16px">
        <template #title>
          <strong>不可逆操作</strong>：将「源客户」的所有 IP 资产 / 订阅 / 流水 / 余额合并到「目标客户」，源客户会被软删除。
          <br>建议先在「源客户详情」确认所有数据，再执行合并。
        </template>
      </el-alert>

      <el-form label-width="100px">
        <el-form-item label="源客户" required>
          <el-select
            v-model="mergeForm.source_id"
            filterable
            remote
            reserve-keyword
            placeholder="搜索（将被合并删除）"
            :remote-method="searchMergeCustomers"
            :loading="mergeSearchLoading"
            style="width: 100%"
          >
            <el-option
              v-for="c in mergeCustomerOptions"
              :key="c.id"
              :label="`#${c.id} ${c.customer_name} (余额 ¥${Number(c.balance || 0).toFixed(2)}, IP ${c.proxy_ips_count || 0})`"
              :value="c.id"
              :disabled="c.id === mergeForm.target_id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="目标客户" required>
          <el-select
            v-model="mergeForm.target_id"
            filterable
            remote
            reserve-keyword
            placeholder="搜索（保留的主号）"
            :remote-method="searchMergeCustomers"
            :loading="mergeSearchLoading"
            style="width: 100%"
          >
            <el-option
              v-for="c in mergeCustomerOptions"
              :key="c.id"
              :label="`#${c.id} ${c.customer_name} (余额 ¥${Number(c.balance || 0).toFixed(2)}, IP ${c.proxy_ips_count || 0})`"
              :value="c.id"
              :disabled="c.id === mergeForm.source_id"
            />
          </el-select>
        </el-form-item>
      </el-form>

      <div class="merge-preview" v-if="mergeForm.source_id && mergeForm.target_id">
        合并后：所有数据归到「目标客户」名下，源客户「{{ mergeSourceName }}」将从客户列表移除（软删除可恢复）
      </div>

      <template #footer>
        <el-button @click="mergeDialogVisible = false">取消</el-button>
        <el-button
          type="warning"
          :loading="mergeLoading"
          :disabled="!mergeForm.source_id || !mergeForm.target_id"
          @click="submitMerge"
        >
          确认合并
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  getCustomers, deleteCustomer, updateCustomer,
  topupCustomer as topupCustomerApi, mergeCustomers,
} from '@/api/customers'
import { useAuthStore } from '@/stores/auth'

const authStore = useAuthStore()
const isSuperAdmin = computed(() => authStore.hasRole('super_admin'))
const isAdmin = computed(() => authStore.hasRole('admin') || isSuperAdmin.value)

const loading = ref(false)
const tableData = ref([])

const searchForm = reactive({
  keyword: '',
  sales_person: '',
  status: '',
})

const pagination = reactive({
  page: 1,
  page_size: 20,
  total: 0,
})

function formatMoney(val) {
  if (val == null) return '-'
  return `¥${Number(val).toFixed(2)}`
}

function statusTagType(status) {
  const map = { active: 'success', inactive: 'info', overdue: 'danger' }
  return map[status] || 'info'
}

function statusLabel(status) {
  const map = { active: '正常', inactive: '停用', overdue: '欠费' }
  return map[status] || status
}

async function fetchData() {
  loading.value = true
  try {
    // 后端用 Spatie QueryBuilder，筛选字段需要 filter[xxx] 格式
    // 分页用 per_page（不是 page_size）
    const params = {
      page: pagination.page,
      per_page: pagination.page_size,
    }
    if (searchForm.keyword) params['filter[keyword]'] = searchForm.keyword
    if (searchForm.sales_person) params['filter[sales_person]'] = searchForm.sales_person
    if (searchForm.status) params['filter[status]'] = searchForm.status

    const res = await getCustomers(params)
    tableData.value = res?.items || (Array.isArray(res) ? res : [])
    pagination.total = res?.pagination?.total || 0
  } catch {
    // Error handled by interceptor
  } finally {
    loading.value = false
  }
}

function handleSearch() {
  pagination.page = 1
  fetchData()
}

function onSizeChange(size) {
  pagination.page_size = size
  pagination.page = 1
  fetchData()
}

function handleReset() {
  searchForm.keyword = ''
  searchForm.sales_person = ''
  searchForm.status = ''
  pagination.page = 1
  fetchData()
}

async function handleDelete(row) {
  try {
    await ElMessageBox.confirm(`确定要删除客户「${row.customer_name}」吗？此操作不可撤销。`, '删除确认', {
      type: 'warning',
      confirmButtonText: '确定删除',
      cancelButtonText: '取消',
    })
    await deleteCustomer(row.id)
    ElMessage.success('删除成功')
    fetchData()
  } catch {
    // Cancelled or error handled by interceptor
  }
}

// Topup
const topupDialogVisible = ref(false)
const topupLoading = ref(false)
const topupFormRef = ref(null)
const topupCustomer = ref(null)
const topupForm = reactive({
  amount: 100,
  description: '',
})

const topupRules = {
  amount: [{ required: true, message: '请输入充值金额', trigger: 'blur' }],
}

function openTopup(row) {
  topupCustomer.value = row
  topupForm.amount = 100
  topupForm.description = ''
  topupDialogVisible.value = true
}

async function submitTopup() {
  const valid = await topupFormRef.value.validate().catch(() => false)
  if (!valid) return
  topupLoading.value = true
  try {
    await topupCustomerApi(topupCustomer.value.id, {
      amount: topupForm.amount,
      description: topupForm.description,
    })
    ElMessage.success('充值成功')
    topupDialogVisible.value = false
    fetchData()
  } catch {
    // Error handled by interceptor
  } finally {
    topupLoading.value = false
  }
}

// ========== Edit Dialog ==========
const editDialogVisible = ref(false)
const editLoading = ref(false)
const editFormRef = ref(null)
const editingCustomer = ref(null)
const editForm = reactive({
  customer_name: '',
  sales_person: '',
  phone: '',
  email: '',
  company_name: '',
  company_id: '',
  address: '',
  status: 1,
  remark: '',
})
const editRules = {
  customer_name: [
    { required: true, message: '请输入客户名称', trigger: 'blur' },
    { max: 100, message: '不超过 100 字符', trigger: 'blur' },
  ],
}

function openEdit(row) {
  editingCustomer.value = row
  editForm.customer_name = row.customer_name || ''
  editForm.sales_person = row.sales_person || ''
  editForm.phone = row.phone || ''
  editForm.email = row.email || ''
  editForm.company_name = row.company_name || ''
  editForm.company_id = row.company_id || ''
  editForm.address = row.address || ''
  editForm.status = row.status ?? 1
  editForm.remark = row.remark || ''
  editDialogVisible.value = true
}

async function submitEdit() {
  const valid = await editFormRef.value.validate().catch(() => false)
  if (!valid) return
  editLoading.value = true
  try {
    await updateCustomer(editingCustomer.value.id, { ...editForm })
    ElMessage.success('已保存')
    editDialogVisible.value = false
    fetchData()
  } catch { /* handled */ }
  finally { editLoading.value = false }
}

// ========== Merge Customers ==========
const mergeDialogVisible = ref(false)
const mergeLoading = ref(false)
const mergeSearchLoading = ref(false)
const mergeCustomerOptions = ref([])
const mergeForm = reactive({
  source_id: null,
  target_id: null,
})

const mergeSourceName = computed(() => {
  const c = mergeCustomerOptions.value.find(x => x.id === mergeForm.source_id)
  return c?.customer_name || '?'
})

function openMerge() {
  mergeForm.source_id = null
  mergeForm.target_id = null
  mergeCustomerOptions.value = []
  mergeDialogVisible.value = true
  // 默认拉一批最近的客户作为初始选项
  searchMergeCustomers('')
}

async function searchMergeCustomers(keyword) {
  mergeSearchLoading.value = true
  try {
    const params = { per_page: 30 }
    if (keyword) params['filter[keyword]'] = keyword
    const res = await getCustomers(params)
    mergeCustomerOptions.value = res?.items || []
  } catch { /* handled */ }
  finally { mergeSearchLoading.value = false }
}

async function submitMerge() {
  if (!mergeForm.source_id || !mergeForm.target_id) {
    ElMessage.warning('请选择源客户和目标客户')
    return
  }
  if (mergeForm.source_id === mergeForm.target_id) {
    ElMessage.warning('源客户和目标客户不能相同')
    return
  }

  const sourceCust = mergeCustomerOptions.value.find(x => x.id === mergeForm.source_id)
  const targetCust = mergeCustomerOptions.value.find(x => x.id === mergeForm.target_id)
  const msg = `确认合并？\n\n源：${sourceCust?.customer_name} (#${sourceCust?.id})\n目标：${targetCust?.customer_name} (#${targetCust?.id})\n\n源客户的所有 IP/订阅/流水/余额都会归到目标客户名下，源客户会被软删除。此操作不可逆。`

  try {
    await ElMessageBox.confirm(msg, '合并确认', {
      type: 'warning',
      confirmButtonText: '确认合并',
      cancelButtonText: '取消',
    })
  } catch { return }

  mergeLoading.value = true
  try {
    const res = await mergeCustomers({
      source_id: mergeForm.source_id,
      target_id: mergeForm.target_id,
    })
    const stats = res?.stats || {}
    ElMessageBox.alert(
      `<div>合并完成。已转移：</div>
      <div style="margin-top:8px;font-size:13px">
        <div>IP 资产：${stats.proxy_ips || 0}</div>
        <div>订阅：${stats.subscriptions || 0}</div>
        <div>交易流水：${stats.transactions || 0}</div>
        <div>分配日志：${stats.ip_logs || 0}</div>
        ${stats.payment_orders ? `<div>支付订单：${stats.payment_orders}</div>` : ''}
        ${stats.provision_orders ? `<div>开通订单：${stats.provision_orders}</div>` : ''}
      </div>`,
      '合并成功',
      { dangerouslyUseHTMLString: true, type: 'success' }
    )
    mergeDialogVisible.value = false
    fetchData()
  } catch { /* handled */ }
  finally { mergeLoading.value = false }
}

onMounted(() => {
  fetchData()
})
</script>

<style lang="scss" scoped>
.customer-list {
  .page-title {
    margin: 0 0 20px 0;
    font-size: 20px;
    color: #303133;
  }

  .search-card {
    margin-bottom: 16px;

    :deep(.el-card__body) {
      padding-bottom: 2px;
    }
  }

  .pagination-wrap {
    display: flex;
    justify-content: flex-end;
    margin-top: 16px;
  }

  .text-danger {
    color: #f56c6c;
  }
}
.hint {
  font-size: 12px;
  color: #909399;
  margin-top: 4px;
}
.merge-preview {
  margin-top: 8px;
  padding: 10px 14px;
  background: linear-gradient(135deg, #FFF8F0, #FDF0E2);
  border: 1px solid #F5D9B5;
  border-radius: 6px;
  font-size: 13px;
  color: #4A5568;
}
</style>
