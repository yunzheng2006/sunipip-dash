<template>
  <div class="dashboard">
    <div class="page-header">
      <h2>仪表盘</h2>
      <p class="page-desc">数据概览与运营监控</p>
    </div>

    <!-- Stat Cards -->
    <el-row :gutter="16" class="stat-row">
      <el-col :span="6" v-for="card in statCards" :key="card.key">
        <div class="stat-card" :class="card.theme">
          <div class="stat-card-inner">
            <div class="stat-top">
              <span class="stat-label">{{ card.label }}</span>
              <div class="stat-icon-wrap">
                <el-icon :size="20"><component :is="card.icon" /></el-icon>
              </div>
            </div>
            <div class="stat-value">{{ stats[card.key] ?? '-' }}</div>
            <div class="stat-footer" v-if="card.sub">
              {{ card.sub }}
            </div>
          </div>
        </div>
      </el-col>
    </el-row>

    <!-- Expiring Subscriptions Table -->
    <el-card class="table-card">
      <template #header>
        <div class="card-header">
          <div class="card-title">
            <el-icon :size="18" color="#E8913A"><Warning /></el-icon>
            <span>即将到期的订阅</span>
          </div>
          <el-button type="primary" link @click="$router.push('/subscriptions')">
            查看全部 <el-icon><ArrowRight /></el-icon>
          </el-button>
        </div>
      </template>
      <el-table :data="expiringList" v-loading="loadingExpiring" stripe>
        <el-table-column prop="customer_name" label="客户名称" min-width="140">
          <template #default="{ row }">
            <span class="customer-link">{{ row.customer_name || row.customer?.customer_name || '-' }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="asset_name" label="资产名称" min-width="180">
          <template #default="{ row }">
            {{ row.asset_name || row.proxy_ip?.asset_name || '-' }}
          </template>
        </el-table-column>
        <el-table-column prop="expires_at" label="到期时间" min-width="160">
          <template #default="{ row }">
            {{ formatDate(row.expires_at) }}
          </template>
        </el-table-column>
        <el-table-column label="剩余" width="90" align="center">
          <template #default="{ row }">
            <el-tag
              :type="getDaysTagType(row.days_remaining)"
              size="small"
              round
              effect="dark"
            >
              {{ row.days_remaining }}天
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="80" align="center">
          <template #default="{ row }">
            <el-button type="primary" link size="small" @click="$router.push(`/subscriptions/${row.id}`)">
              详情
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-if="!loadingExpiring && expiringList.length === 0" description="暂无即将到期的订阅" :image-size="80" />
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import dayjs from 'dayjs'
import { getDashboardStats, getExpiringList } from '@/api/dashboard'

const stats = ref({})
const expiringList = ref([])
const loadingExpiring = ref(false)

const statCards = [
  { key: 'total_customers', label: '客户总数', icon: 'User', theme: 'theme-amber', sub: '累计注册客户' },
  { key: 'total_ips', label: 'IP总数', icon: 'Monitor', theme: 'theme-emerald', sub: null },
  { key: 'active_subscriptions', label: '活跃订阅', icon: 'Calendar', theme: 'theme-blue', sub: '当前进行中' },
  { key: 'expiring_soon', label: '即将到期', icon: 'Warning', theme: 'theme-rose', sub: '7天内到期' },
]

function formatDate(date) {
  return date ? dayjs(date).format('YYYY-MM-DD HH:mm') : '-'
}

function getDaysTagType(days) {
  if (days <= 1) return 'danger'
  if (days <= 3) return 'warning'
  return 'info'
}

async function fetchStats() {
  try {
    const res = await getDashboardStats()
    stats.value = res
  } catch { /* handled */ }
}

async function fetchExpiring() {
  loadingExpiring.value = true
  try {
    const res = await getExpiringList()
    expiringList.value = Array.isArray(res) ? res : res.items || []
  } catch { /* handled */ }
  finally { loadingExpiring.value = false }
}

onMounted(() => {
  fetchStats()
  fetchExpiring()
})
</script>

<style lang="scss" scoped>
.dashboard {
  .page-header {
    margin-bottom: 24px;

    h2 {
      font-size: 22px;
      font-weight: 600;
      color: #2C3E50;
      margin: 0 0 4px 0;
    }

    .page-desc {
      font-size: 13px;
      color: #909399;
      margin: 0;
    }
  }
}

// ===== 统计卡片 =====
.stat-row {
  margin-bottom: 20px;
}

.stat-card {
  border-radius: 14px;
  padding: 22px 20px;
  transition: all 0.3s ease;
  cursor: default;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.06);
  }

  &.theme-amber {
    background: linear-gradient(135deg, #FFF8F0, #FDF0E2);
    border: 1px solid #F5D9B5;
    .stat-icon-wrap { background: #E8913A; }
    .stat-value { color: #C87A2E; }
  }

  &.theme-emerald {
    background: linear-gradient(135deg, #F0FFF4, #E0F5E8);
    border: 1px solid #B8E6C8;
    .stat-icon-wrap { background: #48BB78; }
    .stat-value { color: #2D8A50; }
  }

  &.theme-blue {
    background: linear-gradient(135deg, #F0F7FF, #E0EFFD);
    border: 1px solid #B3D4F5;
    .stat-icon-wrap { background: #4299E1; }
    .stat-value { color: #2B6CB0; }
  }

  &.theme-rose {
    background: linear-gradient(135deg, #FFF5F5, #FEE2E2);
    border: 1px solid #FECACA;
    .stat-icon-wrap { background: #F56565; }
    .stat-value { color: #C53030; }
  }

  .stat-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 12px;

    .stat-label {
      font-size: 13px;
      color: #718096;
      font-weight: 500;
    }

    .stat-icon-wrap {
      width: 36px;
      height: 36px;
      border-radius: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #fff;
    }
  }

  .stat-value {
    font-size: 32px;
    font-weight: 700;
    line-height: 1.1;
    margin-bottom: 6px;
  }

  .stat-footer {
    font-size: 12px;
    color: #A0AEC0;
  }
}

// ===== 表格卡片 =====
.table-card {
  .card-header {
    display: flex;
    align-items: center;
    justify-content: space-between;

    .card-title {
      display: flex;
      align-items: center;
      gap: 8px;
      font-weight: 600;
      font-size: 15px;
      color: #2C3E50;
    }
  }

  .customer-link {
    color: #E8913A;
    font-weight: 500;
  }
}
</style>
