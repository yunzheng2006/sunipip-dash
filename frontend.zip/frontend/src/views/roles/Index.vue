<template>
  <div class="roles-page">
    <h2 class="page-title">权限组管理</h2>
    <p style="color: #909399; margin: -12px 0 20px; font-size: 13px;">
      管理系统角色及其权限。超级管理员的权限不可修改。
    </p>

    <el-row :gutter="16">
      <!-- 左侧：角色列表 -->
      <el-col :span="8">
        <el-card>
          <template #header>
            <div class="card-header">
              <span><el-icon><UserFilled /></el-icon> 角色列表</span>
              <el-button type="primary" size="small" @click="openCreate">
                <el-icon><Plus /></el-icon>新建角色
              </el-button>
            </div>
          </template>
          <div class="role-list">
            <div
              v-for="role in roles"
              :key="role.id"
              class="role-item"
              :class="{ active: selectedRoleId === role.id }"
              @click="selectRole(role.id)"
            >
              <div class="role-info">
                <div class="role-name">
                  {{ role.label }}
                  <el-tag v-if="role.is_system" size="small" type="info" effect="plain">系统</el-tag>
                </div>
                <div class="role-meta">
                  <span>{{ role.permissions_count }} 项权限</span>
                  <span>·</span>
                  <span>{{ role.users_count }} 个用户</span>
                </div>
              </div>
              <el-icon v-if="selectedRoleId === role.id" class="arrow"><ArrowRight /></el-icon>
            </div>
          </div>
        </el-card>
      </el-col>

      <!-- 右侧：权限配置 -->
      <el-col :span="16">
        <el-card v-loading="loading">
          <template #header>
            <div class="card-header">
              <span v-if="selectedRole">
                <el-icon><Key /></el-icon>
                <strong>{{ selectedRole.label }}</strong> 权限配置
                <el-tag size="small" type="info" style="margin-left: 8px">{{ selectedRole.name }}</el-tag>
              </span>
              <span v-else>请选择左侧角色</span>

              <div v-if="selectedRole && !selectedRole.is_super">
                <el-button size="small" @click="selectAll">全选</el-button>
                <el-button size="small" @click="clearAll">清空</el-button>
                <el-button type="primary" size="small" :loading="saving" @click="save" :disabled="selectedRole.is_super">
                  保存权限
                </el-button>
                <el-button
                  v-if="!selectedRole.is_system"
                  type="danger"
                  size="small"
                  @click="handleDelete"
                >
                  删除角色
                </el-button>
              </div>
            </div>
          </template>

          <div v-if="selectedRole">
            <el-alert v-if="selectedRole.name === 'super_admin'" type="warning" :closable="false" show-icon style="margin-bottom: 16px">
              超级管理员拥有所有权限，不可修改。
            </el-alert>

            <!-- 按模块分组展示 -->
            <div v-for="(module, key) in modules" :key="key" class="module-block">
              <div class="module-header">
                <el-checkbox
                  :model-value="isModuleAllSelected(module)"
                  :indeterminate="isModuleIndeterminate(module)"
                  :disabled="selectedRole.name === 'super_admin'"
                  @change="toggleModule(module, $event)"
                >
                  <strong>{{ module.label }}</strong>
                </el-checkbox>
                <span class="module-count">
                  {{ countSelectedInModule(module) }} / {{ Object.keys(module.permissions).length }}
                </span>
              </div>
              <div class="permissions-grid">
                <el-checkbox
                  v-for="(label, permKey) in module.permissions"
                  :key="permKey"
                  :model-value="selectedPermissions.includes(permKey)"
                  :disabled="selectedRole.name === 'super_admin'"
                  @change="togglePermission(permKey, $event)"
                >
                  {{ label }}
                  <span class="perm-code">{{ permKey }}</span>
                </el-checkbox>
              </div>
            </div>
          </div>
          <el-empty v-else description="请从左侧选择角色" />
        </el-card>
      </el-col>
    </el-row>

    <!-- Create Role Dialog -->
    <el-dialog v-model="createVisible" title="新建角色" width="460px">
      <el-form :model="createForm" label-width="80px">
        <el-form-item label="角色标识" required>
          <el-input v-model="createForm.name" placeholder="英文/下划线，如 finance_manager" />
          <div style="font-size: 12px; color: #909399">只能使用小写字母和下划线</div>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="createVisible = false">取消</el-button>
        <el-button type="primary" :loading="creating" @click="submitCreate">创建</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Key, UserFilled, ArrowRight } from '@element-plus/icons-vue'
import { getRoles, getRole, createRole, updateRole, deleteRole, getAllPermissions } from '@/api/roles'

const roles = ref([])
const modules = ref({})
const selectedRoleId = ref(null)
const selectedRole = ref(null)
const selectedPermissions = ref([])
const loading = ref(false)
const saving = ref(false)

const createVisible = ref(false)
const creating = ref(false)
const createForm = reactive({ name: '' })

async function loadRoles() {
  try {
    const res = await getRoles()
    roles.value = Array.isArray(res) ? res : []
    // 自动选第一个
    if (roles.value.length && !selectedRoleId.value) {
      selectRole(roles.value[0].id)
    }
  } catch { /* handled */ }
}

async function loadModules() {
  try {
    const res = await getAllPermissions()
    modules.value = res?.modules || {}
  } catch { /* handled */ }
}

async function selectRole(id) {
  selectedRoleId.value = id
  loading.value = true
  try {
    const res = await getRole(id)
    selectedRole.value = {
      ...res,
      is_super: res.name === 'super_admin',
    }
    selectedPermissions.value = res.permissions || []
  } catch { /* handled */ }
  finally { loading.value = false }
}

function togglePermission(key, checked) {
  if (checked) {
    if (!selectedPermissions.value.includes(key)) selectedPermissions.value.push(key)
  } else {
    selectedPermissions.value = selectedPermissions.value.filter(p => p !== key)
  }
}

function isModuleAllSelected(module) {
  const keys = Object.keys(module.permissions)
  return keys.length > 0 && keys.every(k => selectedPermissions.value.includes(k))
}

function isModuleIndeterminate(module) {
  const keys = Object.keys(module.permissions)
  const selected = keys.filter(k => selectedPermissions.value.includes(k))
  return selected.length > 0 && selected.length < keys.length
}

function countSelectedInModule(module) {
  return Object.keys(module.permissions).filter(k => selectedPermissions.value.includes(k)).length
}

function toggleModule(module, checked) {
  const keys = Object.keys(module.permissions)
  if (checked) {
    selectedPermissions.value = [...new Set([...selectedPermissions.value, ...keys])]
  } else {
    selectedPermissions.value = selectedPermissions.value.filter(p => !keys.includes(p))
  }
}

function selectAll() {
  const all = []
  Object.values(modules.value).forEach(m => {
    all.push(...Object.keys(m.permissions))
  })
  selectedPermissions.value = all
}

function clearAll() { selectedPermissions.value = [] }

async function save() {
  saving.value = true
  try {
    await updateRole(selectedRoleId.value, { permissions: selectedPermissions.value })
    ElMessage.success('权限保存成功')
    loadRoles()
  } catch { /* handled */ }
  finally { saving.value = false }
}

function openCreate() {
  createForm.name = ''
  createVisible.value = true
}

async function submitCreate() {
  if (!createForm.name) { ElMessage.warning('请输入角色标识'); return }
  if (!/^[a-z_]+$/.test(createForm.name)) {
    ElMessage.warning('只能使用小写字母和下划线')
    return
  }
  creating.value = true
  try {
    await createRole({ name: createForm.name, permissions: [] })
    ElMessage.success('角色创建成功')
    createVisible.value = false
    loadRoles()
  } catch { /* handled */ }
  finally { creating.value = false }
}

async function handleDelete() {
  try {
    await ElMessageBox.confirm(`确定删除角色「${selectedRole.value.label}」？`, '确认', { type: 'warning' })
    await deleteRole(selectedRoleId.value)
    ElMessage.success('已删除')
    selectedRoleId.value = null
    selectedRole.value = null
    loadRoles()
  } catch { /* cancelled */ }
}

onMounted(() => {
  loadRoles()
  loadModules()
})
</script>

<style lang="scss" scoped>
.roles-page {
  .page-title { margin: 0 0 4px; font-size: 20px; font-weight: 600; color: #2C3E50; }

  .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-weight: 600;
    .el-icon { margin-right: 6px; vertical-align: middle; }
  }

  .role-list {
    .role-item {
      padding: 14px 16px;
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.2s;
      display: flex;
      align-items: center;
      justify-content: space-between;
      border: 1px solid transparent;

      &:hover {
        background: #FEF7F0;
      }

      &.active {
        background: linear-gradient(135deg, #FFF8F0, #FDF0E2);
        border-color: #F5D9B5;
      }

      .role-info {
        flex: 1;
        .role-name {
          font-size: 15px;
          font-weight: 600;
          color: #2C3E50;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .role-meta {
          font-size: 12px;
          color: #909399;
          margin-top: 4px;
          display: flex;
          gap: 4px;
        }
      }

      .arrow { color: #E8913A; }
    }
  }

  .module-block {
    margin-bottom: 20px;
    padding-bottom: 16px;
    border-bottom: 1px dashed #F0E6DA;

    &:last-child { border-bottom: none; }

    .module-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 12px;
      padding-bottom: 8px;
      border-bottom: 2px solid #F0E6DA;

      .module-count {
        font-size: 13px;
        color: #E8913A;
        font-weight: 500;
      }
    }

    .permissions-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 10px 16px;
      padding-left: 8px;

      :deep(.el-checkbox) {
        margin-right: 0;
        height: auto;
        .el-checkbox__label {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 13px;
        }
      }

      .perm-code {
        font-size: 11px;
        color: #C0C4CC;
        font-family: 'SF Mono', Consolas, monospace;
      }
    }
  }
}
</style>
