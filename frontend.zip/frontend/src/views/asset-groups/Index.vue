<template>
  <div class="asset-group-list">
    <h2 class="page-title">资产组管理</h2>
    <p style="color: #909399; margin: -12px 0 20px; font-size: 13px;">
      资产组按来源管理IP，如"手动导入"、"Spark-美国"、"自有-西雅图"等。
    </p>

    <el-card>
      <div class="toolbar">
        <el-button type="primary" @click="openDialog()">
          <el-icon><Plus /></el-icon>新建资产组
        </el-button>
      </div>

      <el-table :data="tableData" v-loading="loading" stripe>
        <el-table-column prop="id" label="ID" width="70" />
        <el-table-column prop="name" label="组名称" min-width="160">
          <template #default="{ row }">
            <span style="font-weight: 500">{{ row.name }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="source_type" label="来源类型" width="110">
          <template #default="{ row }">
            <el-tag :type="sourceTypeTag(row.source_type)" size="small" effect="plain">
              {{ sourceTypeLabel(row.source_type) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="source_name" label="供应商" min-width="100" />
        <el-table-column prop="country_name" label="国家" width="80" />
        <el-table-column prop="city" label="城市" width="80" />
        <el-table-column prop="proxy_ips_count" label="IP总数" width="80" align="center" />
        <el-table-column prop="available_ips_count" label="可用" width="70" align="center">
          <template #default="{ row }">
            <span :style="{ color: row.available_ips_count > 0 ? '#67C23A' : '#909399' }">
              {{ row.available_ips_count ?? '-' }}
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="80" align="center">
          <template #default="{ row }">
            <el-tag :type="row.status === 1 ? 'success' : 'info'" size="small">
              {{ row.status === 1 ? '启用' : '停用' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="150" align="center" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" link size="small" @click="openDialog(row)">编辑</el-button>
            <el-button type="danger" link size="small" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-wrap">
        <el-pagination
          v-model:current-page="pagination.page"
          v-model:page-size="pagination.per_page"
          :total="pagination.total"
          :page-sizes="[10, 20, 50]"
          layout="total, sizes, prev, pager, next"
          @size-change="fetchData"
          @current-change="fetchData"
        />
      </div>
    </el-card>

    <!-- Dialog -->
    <el-dialog v-model="dialogVisible" :title="isEdit ? '编辑资产组' : '新建资产组'" width="560px">
      <el-form ref="formRef" :model="form" :rules="formRules" label-width="90px">
        <el-form-item label="来源类型" prop="source_type">
          <el-select v-model="form.source_type" style="width: 100%" @change="onSourceTypeChange">
            <el-option label="手动导入" value="manual" />
            <el-option label="Spark API" value="spark_api" />
            <el-option label="第三方API" value="third_party_api" />
            <el-option label="自有资源" value="self_owned" />
          </el-select>
        </el-form-item>
        <el-form-item label="供应商名称" prop="source_name">
          <el-input v-model="form.source_name" placeholder="如 斯帕克, 自有, 涛哥" />
        </el-form-item>
        <el-form-item label="组名称" prop="name">
          <el-input v-model="form.name" placeholder="如 Spark-美国-西雅图, 手动-巴西" />
        </el-form-item>
        <template v-if="form.source_type !== 'spark_api'">
          <el-row :gutter="16">
            <el-col :span="8">
              <el-form-item label="国家代码" :rules="form.source_type !== 'spark_api' ? [{ required: true, message: '必填', trigger: 'blur' }] : []">
                <el-input v-model="form.country_code" placeholder="US" maxlength="2" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="国家">
                <el-input v-model="form.country_name" placeholder="美国" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="城市">
                <el-input v-model="form.city" placeholder="西雅图" />
              </el-form-item>
            </el-col>
          </el-row>
        </template>
        <el-form-item label="描述">
          <el-input v-model="form.description" type="textarea" :rows="2" placeholder="选填" />
        </el-form-item>
        <el-alert v-if="form.source_type === 'spark_api'" type="info" :closable="false" show-icon style="margin-bottom: 16px">
          Spark API 资产组不需要填写国家/城市。创建订单时选择"Spark API 开通"即可实时拉取产品列表。
        </el-alert>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="submitting" @click="handleSubmit">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getAssetGroups, createAssetGroup, updateAssetGroup, deleteAssetGroup } from '@/api/assetGroups'

const loading = ref(false)
const tableData = ref([])
const pagination = reactive({ page: 1, per_page: 20, total: 0 })

const dialogVisible = ref(false)
const isEdit = ref(false)
const editingId = ref(null)
const submitting = ref(false)
const formRef = ref(null)

const form = reactive({
  name: '', source_type: 'manual', source_name: '',
  country_code: '', country_name: '', city: '', description: '',
})

const formRules = {
  name: [{ required: true, message: '请输入组名称', trigger: 'blur' }],
  source_type: [{ required: true, message: '请选择来源类型', trigger: 'change' }],
  source_name: [{ required: true, message: '请输入供应商名称', trigger: 'blur' }],
}

function sourceTypeLabel(t) {
  const map = { manual: '手动导入', spark_api: 'Spark API', third_party_api: '第三方API', self_owned: '自有' }
  return map[t] || t
}

function sourceTypeTag(t) {
  const map = { manual: '', spark_api: 'warning', third_party_api: 'success', self_owned: 'info' }
  return map[t] || ''
}

function onSourceTypeChange(val) {
  if (val === 'spark_api') form.source_name = '斯帕克'
}

async function fetchData() {
  loading.value = true
  try {
    const res = await getAssetGroups({ page: pagination.page, per_page: pagination.per_page })
    tableData.value = res?.items || []
    pagination.total = res?.pagination?.total || 0
  } catch { /* handled */ }
  finally { loading.value = false }
}

function openDialog(row) {
  if (row) {
    isEdit.value = true
    editingId.value = row.id
    Object.assign(form, {
      name: row.name, source_type: row.source_type || 'manual',
      source_name: row.source_name || '', country_code: row.country_code || '',
      country_name: row.country_name || '', city: row.city || '',
      description: row.description || '',
    })
  } else {
    isEdit.value = false
    editingId.value = null
    Object.assign(form, {
      name: '', source_type: 'manual', source_name: '',
      country_code: '', country_name: '', city: '', description: '',
    })
  }
  dialogVisible.value = true
}

async function handleSubmit() {
  const valid = await formRef.value.validate().catch(() => false)
  if (!valid) return
  submitting.value = true
  try {
    if (isEdit.value) {
      await updateAssetGroup(editingId.value, { ...form })
      ElMessage.success('更新成功')
    } else {
      await createAssetGroup({ ...form })
      ElMessage.success('创建成功')
    }
    dialogVisible.value = false
    fetchData()
  } catch { /* handled */ }
  finally { submitting.value = false }
}

async function handleDelete(row) {
  try {
    await ElMessageBox.confirm(`确定删除资产组「${row.name}」？`, '确认', { type: 'warning' })
    await deleteAssetGroup(row.id)
    ElMessage.success('删除成功')
    fetchData()
  } catch { /* cancelled */ }
}

onMounted(fetchData)
</script>

<style lang="scss" scoped>
.asset-group-list {
  .toolbar { margin-bottom: 16px; }
  .pagination-wrap { display: flex; justify-content: flex-end; margin-top: 16px; }
}
</style>
