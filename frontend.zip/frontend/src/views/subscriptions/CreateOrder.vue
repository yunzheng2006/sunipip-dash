<template>
  <div class="create-order">
    <h2 class="page-title">创建订单</h2>

    <el-card class="section-card">
      <!-- 1. 选客户 -->
      <div class="section-header">1. 选择客户</div>
      <el-select
        v-model="customerId"
        filterable
        remote
        reserve-keyword
        placeholder="搜索客户名称"
        :remote-method="searchCustomers"
        :loading="customerLoading"
        style="width: 360px"
      >
        <el-option
          v-for="c in customerOptions"
          :key="c.id"
          :label="`${c.customer_name} (${c.username})`"
          :value="c.id"
        />
      </el-select>
    </el-card>

    <!-- 2. 选来源模式 -->
    <el-card class="section-card">
      <div class="section-header">2. 选择IP来源</div>
      <el-radio-group v-model="sourceMode" size="large">
        <el-radio-button value="own">
          <el-icon><Box /></el-icon> 自有IP库存
        </el-radio-button>
        <el-radio-button value="spark">
          <el-icon><Connection /></el-icon> Spark API 开通
        </el-radio-button>
      </el-radio-group>
    </el-card>

    <!-- 3A. 自有IP模式 -->
    <el-card v-if="sourceMode === 'own'" class="section-card">
      <div class="section-header">3. 选择IP (自有库存)</div>
      <el-table :data="ownItems" border>
        <el-table-column label="IP组" min-width="180">
          <template #default="{ row }">
            <el-select v-model="row.ip_group_id" placeholder="选择IP组" style="width: 100%" @change="onOwnIpGroupChange(row)">
              <el-option v-for="g in ipGroupOptions" :key="g.id" :label="g.name" :value="g.id" />
            </el-select>
          </template>
        </el-table-column>
        <el-table-column label="资产组(可选)" min-width="180">
          <template #default="{ row }">
            <el-select v-model="row.asset_group_id" placeholder="不限" clearable style="width: 100%" @change="fetchAvailable(row)">
              <el-option v-for="g in assetGroupOptions" :key="g.id" :label="g.name" :value="g.id" />
            </el-select>
          </template>
        </el-table-column>
        <el-table-column label="可用" width="70" align="center">
          <template #default="{ row }">
            <span :style="{ color: row.available > 0 ? '#67C23A' : '#F56C6C', fontWeight: 600 }">{{ row.available ?? '-' }}</span>
          </template>
        </el-table-column>
        <el-table-column label="数量" width="100">
          <template #default="{ row }">
            <el-input-number v-model="row.quantity" :min="1" :max="row.available || 999" size="small" controls-position="right" />
          </template>
        </el-table-column>
        <el-table-column label="单价(元/月)" width="140">
          <template #default="{ row }">
            <el-input-number v-model="row.unit_price" :min="0" :precision="2" size="small" controls-position="right" />
          </template>
        </el-table-column>
        <el-table-column label="小计" width="100" align="right">
          <template #default="{ row }">
            <span class="subtotal">¥{{ (row.quantity * row.unit_price).toFixed(2) }}</span>
          </template>
        </el-table-column>
        <el-table-column width="60" align="center">
          <template #default="{ $index }">
            <el-button type="danger" link size="small" @click="ownItems.splice($index, 1)">
              <el-icon><Delete /></el-icon>
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-button class="add-row-btn" @click="addOwnItem">
        <el-icon><Plus /></el-icon> 添加项目
      </el-button>
    </el-card>

    <!-- 3B. Spark模式 -->
    <el-card v-if="sourceMode === 'spark'" class="section-card spark-panel">
      <div class="section-header">
        <span>3. 选择 Spark 产品</span>
        <el-button type="primary" size="small" @click="fetchSparkProductList" :loading="sparkLoading" style="margin-left: auto">
          <el-icon><Refresh /></el-icon> {{ sparkProducts.length ? '刷新' : '拉取产品列表' }}
        </el-button>
      </div>

      <el-alert v-if="!sparkProducts.length && !sparkLoading" type="info" :closable="false" show-icon>
        点击"拉取产品列表"从 Spark API 实时获取可选产品、库存和成本价。
      </el-alert>

      <el-alert
        v-if="sparkProducts.length && !priceAuthorized"
        type="warning"
        :closable="false"
        show-icon
        style="margin-bottom: 12px"
      >
        <template #title>
          <strong>成本价格未授权</strong> - Spark API 未返回真实成本价。请联系 Spark 运营开通价格授权，下单时业务员必须手动填写售价。
        </template>
      </el-alert>

      <!-- 筛选工具栏 -->
      <div v-if="sparkProducts.length" class="filter-bar">
        <el-input
          v-model="sparkKeyword"
          placeholder="搜索产品/城市/国家"
          clearable
          :prefix-icon="Search"
          size="default"
          style="width: 240px"
        />
        <el-select v-model="filterIspType" placeholder="ISP类型" clearable size="default" style="width: 140px">
          <el-option label="全部ISP" value="" />
          <el-option label="单ISP" :value="1" />
          <el-option label="双ISP" :value="2" />
          <el-option label="原生ISP" :value="3" />
          <el-option label="机房数据中心" :value="4" />
        </el-select>
        <el-select v-model="filterNetType" placeholder="网络类型" clearable size="default" style="width: 130px">
          <el-option label="全部类型" value="" />
          <el-option label="原生" :value="1" />
          <el-option label="广播" :value="2" />
          <el-option label="未知" :value="0" />
        </el-select>
        <el-select v-model="filterProxyType" placeholder="代理类型" clearable size="default" style="width: 140px">
          <el-option label="全部类型" value="" />
          <el-option label="静态住宅" :value="103" />
          <el-option label="动态住宅" :value="104" />
        </el-select>
        <el-select v-model="filterStock" placeholder="库存" clearable size="default" style="width: 130px">
          <el-option label="全部" value="" />
          <el-option label="有库存" value="available" />
          <el-option label="库存 > 100" value="high" />
          <el-option label="已售罄" value="sold_out" />
        </el-select>
        <el-select v-model="sortBy" size="default" style="width: 150px">
          <el-option label="库存优先" value="stock" />
          <el-option label="国家名称" value="country" />
          <el-option label="库存降序" value="stock_desc" />
        </el-select>
        <el-button @click="resetFilters" size="default" plain>
          <el-icon><Refresh /></el-icon> 重置
        </el-button>
        <div class="result-count">共 <strong>{{ totalFiltered }}</strong> 个产品</div>
      </div>

      <!-- 按大洲分组 -->
      <div v-if="groupedProducts.length" class="continent-tabs">
        <el-tabs v-model="activeContinent">
          <el-tab-pane v-for="group in groupedProducts" :key="group.name" :name="group.name">
            <template #label>
              <span>{{ group.name }}</span>
              <el-badge :value="group.total" :max="999" class="tab-badge" />
            </template>

            <div class="product-grid">
              <div
                v-for="p in group.products"
                :key="p.product_id"
                class="product-card"
                :class="{ 'out-of-stock': p.inventory <= 0, 'selected': isSelected(p.product_id) }"
                @click="p.inventory > 0 && addSparkItem(p)"
              >
                <div class="card-top">
                  <div class="country-flag">{{ p.flag }}</div>
                  <el-tag :type="stockTagType(p.inventory)" size="small" effect="dark">
                    {{ p.inventory > 0 ? `库存 ${p.inventory}` : '售罄' }}
                  </el-tag>
                </div>
                <div class="country-name">{{ p.country_cn }}</div>
                <div class="product-name" :title="p.product_name">{{ p.display_name }}</div>
                <div class="tags">
                  <el-tag v-if="p.proxy_type === 103" size="small" effect="plain" type="info">静态</el-tag>
                  <el-tag v-if="p.proxy_type === 104" size="small" effect="plain" type="info">动态</el-tag>
                  <el-tag v-if="p.isp_label" size="small" effect="plain">{{ p.isp_label }}</el-tag>
                  <el-tag v-if="p.net_label" size="small" effect="plain" :type="p.net_type === 1 ? 'success' : 'warning'">{{ p.net_label }}</el-tag>
                </div>
                <div class="card-bottom">
                  <span class="duration">⏱ {{ p.duration }}{{ unitLabel(p.unit) }}</span>
                  <span v-if="p.cost_price !== null" class="cost">成本 ¥{{ p.cost_price }}</span>
                  <el-tooltip v-else content="Spark 未授权成本价，请联系运营">
                    <span class="cost-unavailable">价格未授权</span>
                  </el-tooltip>
                </div>
              </div>
            </div>
            <el-empty v-if="!group.products.length" description="暂无产品" :image-size="60" />
          </el-tab-pane>
        </el-tabs>
      </div>
      <el-empty v-else-if="sparkProducts.length && !groupedProducts.length" description="无符合条件的产品" />

      <!-- 已选 Spark 产品 -->
      <template v-if="sparkItems.length">
        <div class="section-sub-header">
          已选 {{ sparkItems.length }} 个产品（请填写售价）
        </div>
        <el-table :data="sparkItems" border size="small">
          <el-table-column label="产品" min-width="280">
            <template #default="{ row }">
              <span style="font-size: 18px; margin-right: 6px">{{ row.flag }}</span>
              <strong>{{ row.country_cn }}</strong>
              <span style="color: #909399; margin-left: 6px">{{ row.display_name }}</span>
            </template>
          </el-table-column>
          <el-table-column label="成本" width="90" align="right">
            <template #default="{ row }">
              <span v-if="row.cost_price !== null" style="color: #909399">¥{{ row.cost_price }}</span>
              <span v-else style="color: #C0C4CC; font-size: 12px">未授权</span>
            </template>
          </el-table-column>
          <el-table-column label="数量" width="110">
            <template #default="{ row }">
              <el-input-number v-model="row.quantity" :min="1" :max="row.inventory" size="small" controls-position="right" />
            </template>
          </el-table-column>
          <el-table-column label="售价(元/条)" width="140">
            <template #default="{ row }">
              <el-input-number v-model="row.sale_price" :min="0" :precision="2" size="small" controls-position="right" placeholder="请填写" />
            </template>
          </el-table-column>
          <el-table-column label="利润/条" width="90" align="right">
            <template #default="{ row }">
              <span v-if="row.cost_price !== null" :style="{ color: row.sale_price - row.cost_price >= 0 ? '#67C23A' : '#F56C6C' }">
                ¥{{ (row.sale_price - row.cost_price).toFixed(2) }}
              </span>
              <span v-else style="color: #C0C4CC">-</span>
            </template>
          </el-table-column>
          <el-table-column label="小计" width="100" align="right">
            <template #default="{ row }">
              <span class="subtotal">¥{{ (row.quantity * row.sale_price).toFixed(2) }}</span>
            </template>
          </el-table-column>
          <el-table-column width="50" align="center">
            <template #default="{ $index }">
              <el-button type="danger" link size="small" @click="sparkItems.splice($index, 1)">
                <el-icon><Delete /></el-icon>
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </template>
    </el-card>

    <!-- 4. 增值服务 - 端口转发 -->
    <el-card class="section-card" v-if="sourceMode === 'spark'">
      <div class="section-header">
        <span>4. 增值服务 · 端口转发 (可选)</span>
        <el-switch v-model="forwardEnabled" style="margin-left: auto" />
      </div>

      <el-alert v-if="!forwardEnabled" type="info" :closable="false" show-icon>
        打开开关后，可为本次下单的每条 IP 自动创建 NY 面板转发规则。客户看到的将是转发后的地址。
      </el-alert>

      <div v-else>
        <el-form :model="forwardForm" label-width="120px" size="default">
          <el-form-item label="转发类型">
            <el-radio-group v-model="forwardForm.forward_type">
              <el-radio-button value="ny">NY socks5 转发</el-radio-button>
              <el-radio-button value="xui">3x-ui vless+reality 中转</el-radio-button>
            </el-radio-group>
          </el-form-item>

          <!-- NY 分支 -->
          <template v-if="forwardForm.forward_type === 'ny'">
            <el-alert type="warning" :closable="false" show-icon style="margin-bottom: 12px">
              <template #title>
                NY 转发费为<strong>额外收费</strong>，会加到每条 IP 的原价上作为总价。退订时自动删除转发规则。
              </template>
            </el-alert>

            <el-form-item label="转发节点">
              <el-select v-model="forwardForm.device_group_id" placeholder="选择 NY 设备组" style="width: 100%" filterable>
                <el-option
                  v-for="dg in deviceGroupOptions"
                  :key="dg.id"
                  :label="`[${dg.panel?.name}] ${dg.name}`"
                  :value="dg.id"
                >
                  <div style="display: flex; justify-content: space-between; align-items: center">
                    <span>{{ dg.name }}</span>
                    <span class="mono" style="font-size: 11px; color: #909399">
                      {{ dg.custom_connect_host || dg.original_connect_host }}
                    </span>
                  </div>
                </el-option>
              </el-select>
              <div class="field-hint" v-if="selectedDeviceGroup">
                对客展示地址：
                <span class="mono" style="color: #E8913A">
                  {{ selectedDeviceGroup.custom_connect_host || selectedDeviceGroup.original_connect_host }}:{监听端口}
                </span>
              </div>
            </el-form-item>

            <el-form-item label="限速 (Mbps)">
              <el-input-number
                v-model="forwardForm.speed_limit_mbps"
                :min="1"
                :max="10000"
                placeholder="留空不限速"
                controls-position="right"
                style="width: 220px"
              />
              <span class="field-hint" style="margin-left: 8px">留空 = 不限速</span>
            </el-form-item>

            <el-form-item label="转发费用 (元/月/条)">
              <el-input-number
                v-model="forwardForm.forward_fee"
                :min="0"
                :precision="2"
                controls-position="right"
                style="width: 220px"
              />
              <span class="field-hint" style="margin-left: 8px">加到每条 IP 售价上</span>
            </el-form-item>
          </template>

          <!-- 3x-ui 分支 -->
          <template v-else>
            <el-alert type="info" :closable="false" show-icon style="margin-bottom: 12px">
              <template #title>
                3x-ui 中转为 vless+reality 协议。当前流程<strong>不收额外转发费</strong>，客户扫 vless:// 链接直接使用。
              </template>
            </el-alert>

            <el-form-item label="3x-ui 面板">
              <el-select v-model="forwardForm.xui_panel_id" placeholder="选择 3x-ui 主面板" style="width: 100%" filterable>
                <el-option
                  v-for="p in xuiPanelOptions"
                  :key="p.id"
                  :label="`${p.name} (${p.connect_host || p.api_url})`"
                  :value="p.id"
                />
              </el-select>
              <div class="field-hint">
                备机会自动同步，不用在这里选
              </div>
            </el-form-item>
          </template>
        </el-form>
      </div>
    </el-card>

    <!-- 5. 汇总提交 -->
    <el-card class="section-card summary-card">
      <el-form-item label="备注">
        <el-input v-model="remark" type="textarea" :rows="2" placeholder="选填" style="max-width: 500px" />
      </el-form-item>
      <div class="summary-row">
        <div class="total-label">
          订单总额：
          <span class="total-amount">¥{{ totalAmount }}</span>
          <div v-if="forwardEnabled && forwardForm.forward_fee > 0" class="forward-breakdown">
            <span>含转发费：¥{{ forwardTotal.toFixed(2) }}</span>
          </div>
        </div>
        <el-button type="primary" size="large" :loading="submitting" :disabled="!canSubmit" @click="handleSubmit">
          确认下单
        </el-button>
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Search } from '@element-plus/icons-vue'
import { getCustomers } from '@/api/customers'
import { getAllIpGroups } from '@/api/ipGroups'
import { getAllAssetGroups } from '@/api/assetGroups'
import { lookupPricing } from '@/api/pricingRules'
import { createOrder, getAvailableIps } from '@/api/subscriptions'
import { getSparkProducts, sparkProvision } from '@/api/spark'
import { getNyEnabledDeviceGroups } from '@/api/nyPanels'
import { getUsableXuiPanels } from '@/api/xuiPanels'
import { getCountryInfo, extractCityFromName, CONTINENTS } from '@/utils/countries'

const router = useRouter()

// ===== 客户 =====
const customerId = ref(null)
const customerOptions = ref([])
const customerLoading = ref(false)

async function searchCustomers(keyword) {
  if (!keyword) {
    // 关键字为空时加载最近的客户
    loadRecentCustomers()
    return
  }
  customerLoading.value = true
  try {
    const res = await getCustomers({ 'filter[keyword]': keyword, per_page: 30 })
    customerOptions.value = res?.items || (Array.isArray(res) ? res : [])
  } catch { /* handled */ }
  finally { customerLoading.value = false }
}

async function loadRecentCustomers() {
  try {
    const res = await getCustomers({ per_page: 30 })
    customerOptions.value = res?.items || []
  } catch { /* handled */ }
}

// ===== 来源模式 =====
const sourceMode = ref('own')

// ===== 下拉选项 =====
const ipGroupOptions = ref([])
const assetGroupOptions = ref([])

async function loadOptions() {
  try {
    const [ipRes, assetRes] = await Promise.all([getAllIpGroups(), getAllAssetGroups()])
    ipGroupOptions.value = Array.isArray(ipRes) ? ipRes : []
    assetGroupOptions.value = Array.isArray(assetRes) ? assetRes : []
  } catch { /* handled */ }
}

// ===== 自有IP模式 =====
const ownItems = ref([])

function addOwnItem() {
  ownItems.value.push({ ip_group_id: null, asset_group_id: null, quantity: 1, unit_price: 0, available: null })
}

async function onOwnIpGroupChange(row) {
  if (row.ip_group_id) {
    try {
      const rule = await lookupPricing({ ip_group_id: row.ip_group_id })
      if (rule) row.unit_price = parseFloat(rule.price) || 0
    } catch { /* no rule */ }
  }
  fetchAvailable(row)
}

async function fetchAvailable(row) {
  if (!row.ip_group_id) return
  try {
    const params = { ip_group_id: row.ip_group_id }
    if (row.asset_group_id) params.asset_group_id = row.asset_group_id
    const res = await getAvailableIps(params)
    row.available = res?.available_count ?? 0
  } catch { row.available = 0 }
}

// ===== Spark 模式 =====
const sparkLoading = ref(false)
const sparkProducts = ref([])
const sparkItems = ref([])
const sparkKeyword = ref('')
const activeContinent = ref('')

// 筛选条件
const filterIspType = ref('')
const filterNetType = ref('')
const filterProxyType = ref('')
const filterStock = ref('')
const sortBy = ref('stock')

const ISP_LABELS = { 1: '单ISP', 2: '双ISP', 3: '原生ISP', 4: '机房数据中心' }

function resetFilters() {
  sparkKeyword.value = ''
  filterIspType.value = ''
  filterNetType.value = ''
  filterProxyType.value = ''
  filterStock.value = ''
  sortBy.value = 'stock'
}

function stockTagType(n) {
  if (n <= 0) return 'danger'
  if (n < 10) return 'warning'
  return 'success'
}

const priceAuthorized = ref(false) // 价格是否已授权

async function fetchSparkProductList() {
  sparkLoading.value = true
  try {
    const res = await getSparkProducts({ pageSize: 200 })
    const raw = res?.products || []

    // 检测价格是否授权：如果所有产品 costPrice 都相同且 >= 3 条产品，视为未授权（占位值）
    const prices = raw
      .map(p => parseFloat(p.cost_price))
      .filter(v => !isNaN(v) && v > 0)
    const uniquePrices = [...new Set(prices)]
    // 有效的授权：至少2种不同价格 或 只有1个产品
    priceAuthorized.value = raw.length < 3 || uniquePrices.length >= 2

    sparkProducts.value = raw.map(p => {
      const info = getCountryInfo(p.country_code)
      const rawCost = parseFloat(p.cost_price)
      return {
        ...p,
        // 价格授权时才显示真实价格，否则为 null
        cost_price: priceAuthorized.value && !isNaN(rawCost) && rawCost > 0 ? rawCost : null,
        flag: info.flag,
        country_cn: info.cn,
        continent: info.continent,
        display_name: extractCityFromName(p.product_name, p.country_code) || p.product_name,
        isp_label: ISP_LABELS[p.isp_type],
        net_label: p.net_type === 1 ? '原生' : (p.net_type === 2 ? '广播' : null),
      }
    })
    if (groupedProducts.value.length) {
      activeContinent.value = groupedProducts.value[0].name
    }
  } catch { /* handled */ }
  finally { sparkLoading.value = false }
}

const filteredProducts = computed(() => {
  const kw = sparkKeyword.value.trim().toLowerCase()
  return sparkProducts.value.filter(p => {
    // 关键字
    if (kw) {
      const match = p.country_cn.toLowerCase().includes(kw) ||
        (p.country_code || '').toLowerCase().includes(kw) ||
        (p.product_name || '').toLowerCase().includes(kw) ||
        (p.display_name || '').toLowerCase().includes(kw)
      if (!match) return false
    }
    // ISP 类型
    if (filterIspType.value !== '' && p.isp_type !== filterIspType.value) return false
    // 网络类型
    if (filterNetType.value !== '' && p.net_type !== filterNetType.value) return false
    // 代理类型
    if (filterProxyType.value !== '' && p.proxy_type !== filterProxyType.value) return false
    // 库存
    if (filterStock.value === 'available' && p.inventory <= 0) return false
    if (filterStock.value === 'high' && p.inventory < 100) return false
    if (filterStock.value === 'sold_out' && p.inventory > 0) return false
    return true
  })
})

const totalFiltered = computed(() => filteredProducts.value.length)

const groupedProducts = computed(() => {
  const map = new Map()
  for (const cont of CONTINENTS) map.set(cont, [])
  map.set('其他', [])

  for (const p of filteredProducts.value) {
    const key = map.has(p.continent) ? p.continent : '其他'
    map.get(key).push(p)
  }

  // 排序函数
  const sortFn = (a, b) => {
    switch (sortBy.value) {
      case 'stock':
        return (b.inventory > 0) - (a.inventory > 0) || a.country_cn.localeCompare(b.country_cn)
      case 'stock_desc':
        return b.inventory - a.inventory
      case 'country':
        return a.country_cn.localeCompare(b.country_cn)
      default:
        return 0
    }
  }

  return Array.from(map.entries())
    .map(([name, products]) => ({
      name,
      products: [...products].sort(sortFn),
      total: products.length,
    }))
    .filter(g => g.products.length > 0)
})

function isSelected(productId) {
  return sparkItems.value.some(i => i.product_id === productId)
}

function addSparkItem(product) {
  const exists = sparkItems.value.find(i => i.product_id === product.product_id)
  if (exists) { exists.quantity++; return }
  sparkItems.value.push({
    product_id: product.product_id,
    product_name: product.product_name,
    display_name: product.display_name,
    country_code: product.country_code,
    country_cn: product.country_cn,
    flag: product.flag,
    cost_price: product.cost_price, // 可能为 null
    duration: product.duration,
    unit: product.unit,
    inventory: product.inventory,
    quantity: 1,
    // 售价默认为 0，强制业务员手动填写（无论是否授权）
    sale_price: 0,
  })
}

function unitLabel(u) {
  return { 1: '天', 2: '周', 3: '月', 4: '年' }[u] || ''
}

// ===== 转发 =====
const forwardEnabled = ref(false)
const deviceGroupOptions = ref([])
const xuiPanelOptions = ref([])
const forwardForm = reactive({
  forward_type: 'ny',            // ny | xui
  device_group_id: null,
  speed_limit_mbps: null,
  forward_fee: 0,
  xui_panel_id: null,
})

const selectedDeviceGroup = computed(() =>
  deviceGroupOptions.value.find(dg => dg.id === forwardForm.device_group_id)
)

async function loadDeviceGroups() {
  try {
    deviceGroupOptions.value = (await getNyEnabledDeviceGroups()) || []
  } catch { /* handled */ }
}

async function loadXuiPanels() {
  try {
    xuiPanelOptions.value = (await getUsableXuiPanels()) || []
  } catch { /* handled */ }
}

// ===== 汇总 =====
const remark = ref('')
const submitting = ref(false)

const sparkBaseTotal = computed(() =>
  sparkItems.value.reduce((s, i) => s + i.quantity * i.sale_price, 0)
)

const forwardTotal = computed(() => {
  if (!forwardEnabled.value || sourceMode.value !== 'spark') return 0
  // 只有 NY 转发会加价；3x-ui 当前流程不收转发费
  if (forwardForm.forward_type !== 'ny') return 0
  const qty = sparkItems.value.reduce((s, i) => s + (i.quantity || 0), 0)
  return qty * (forwardForm.forward_fee || 0)
})

const totalAmount = computed(() => {
  if (sourceMode.value === 'own') {
    return ownItems.value.reduce((s, i) => s + i.quantity * i.unit_price, 0).toFixed(2)
  }
  return (sparkBaseTotal.value + forwardTotal.value).toFixed(2)
})

const canSubmit = computed(() => {
  if (!customerId.value) return false
  if (sourceMode.value === 'own') return ownItems.value.some(i => i.ip_group_id)
  if (!sparkItems.value.length) return false
  if (forwardEnabled.value) {
    if (forwardForm.forward_type === 'ny') {
      if (!forwardForm.device_group_id) return false
      if (forwardForm.forward_fee < 0) return false
    } else if (forwardForm.forward_type === 'xui') {
      if (!forwardForm.xui_panel_id) return false
    }
  }
  return true
})

async function handleSubmit() {
  if (!customerId.value) { ElMessage.warning('请选择客户'); return }

  // Spark 模式：校验所有已选产品必须填写售价
  if (sourceMode.value === 'spark') {
    const unpriced = sparkItems.value.filter(i => !i.sale_price || i.sale_price <= 0)
    if (unpriced.length) {
      ElMessage.warning(`有 ${unpriced.length} 个产品未填写售价，请先填写`)
      return
    }
  }

  try {
    await ElMessageBox.confirm(`确认下单？总金额：¥${totalAmount.value}`, '确认', { type: 'warning' })
  } catch { return }

  submitting.value = true
  try {
    if (sourceMode.value === 'own') {
      await createOrder({
        customer_id: customerId.value,
        items: ownItems.value.filter(i => i.ip_group_id).map(i => ({
          ip_group_id: i.ip_group_id,
          asset_group_id: i.asset_group_id || undefined,
          quantity: i.quantity,
          unit_price: i.unit_price,
          duration: 1,
          unit: 3,
        })),
        remark: remark.value || undefined,
      })
      ElMessage.success('订单创建成功，IP已分配')
    } else {
      // Spark: 找到Spark资产组
      const sparkGroup = assetGroupOptions.value.find(g => g.source_type === 'spark_api')
      if (!sparkGroup) {
        ElMessage.warning('请先在"资产组管理"中创建一个 Spark API 类型的资产组')
        submitting.value = false
        return
      }
      // 构造转发 payload
      // NY：sale_price 要加上 forward_fee（写入 subscription.price 作为续费/退订基准）
      // 3x-ui：免费，sale_price 保持原样
      let forwardPayload = null
      let xuiPayload = null
      if (forwardEnabled.value) {
        if (forwardForm.forward_type === 'ny' && forwardForm.device_group_id) {
          forwardPayload = {
            device_group_id: forwardForm.device_group_id,
            speed_limit_mbps: forwardForm.speed_limit_mbps || null,
            forward_fee: Number(forwardForm.forward_fee || 0),
          }
        } else if (forwardForm.forward_type === 'xui' && forwardForm.xui_panel_id) {
          xuiPayload = { xui_panel_id: forwardForm.xui_panel_id }
        }
      }

      for (const item of sparkItems.value) {
        const finalSalePrice = Number(item.sale_price)
          + (forwardPayload ? forwardPayload.forward_fee : 0)
        await sparkProvision({
          product_id: item.product_id,
          product_name: item.product_name,
          country_code: item.country_code,
          country_cn: item.country_cn,
          sale_price: finalSalePrice,
          quantity: item.quantity,
          duration: item.duration,
          unit: item.unit,
          asset_group_id: sparkGroup.id,
          customer_id: customerId.value,
          forward: forwardPayload || undefined,
          xui_forward: xuiPayload || undefined,
        })
      }
      ElMessage.success('Spark 开通请求已提交，IP开通后自动入库')
    }
    router.push('/subscriptions')
  } catch { /* handled */ }
  finally { submitting.value = false }
}

onMounted(() => {
  loadOptions()
  loadRecentCustomers()
  loadDeviceGroups()
  loadXuiPanels()
  addOwnItem()
})
</script>

<style lang="scss" scoped>
.create-order {
  .page-title {
    font-size: 22px;
    font-weight: 600;
    color: #2C3E50;
    margin-bottom: 20px;
  }
  .section-card { margin-bottom: 16px; }
  .section-header {
    font-size: 15px;
    font-weight: 600;
    color: #2C3E50;
    margin-bottom: 16px;
    display: flex;
    align-items: center;
  }
  .section-sub-header {
    font-size: 14px;
    font-weight: 500;
    color: #4A5568;
    margin: 16px 0 8px;
  }
  .add-row-btn { margin-top: 12px; width: 100%; border-style: dashed; }
  .subtotal { color: #E8913A; font-weight: 600; }
  .summary-card {
    .summary-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding-top: 16px;
      border-top: 1px solid #F0E6DA;
    }
    .total-label { font-size: 16px; color: #4A5568; }
    .total-amount { font-size: 28px; font-weight: 700; color: #E8913A; margin-left: 8px; }
    .forward-breakdown {
      margin-top: 4px;
      font-size: 12px;
      color: #909399;
    }
  }
  .field-hint { font-size: 12px; color: #909399; }
  .mono { font-family: 'SF Mono', Consolas, Monaco, monospace; }
  :deep(.el-radio-button__inner) { display: flex; align-items: center; gap: 6px; }

  // Spark 产品选择器
  .spark-panel {
    .filter-bar {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      align-items: center;
      padding: 14px 16px;
      background: linear-gradient(135deg, #FFF8F0, #FDF0E2);
      border: 1px solid #F5D9B5;
      border-radius: 10px;
      margin-bottom: 16px;

      .result-count {
        margin-left: auto;
        font-size: 13px;
        color: #4A5568;
        strong {
          color: #E8913A;
          font-size: 16px;
          margin: 0 2px;
        }
      }
    }

    .continent-tabs {
      :deep(.el-tabs__item) {
        font-size: 14px;
        padding-right: 30px;
      }
      .tab-badge {
        margin-left: 6px;
        :deep(.el-badge__content) {
          background: #E8913A !important;
        }
      }
    }

    .product-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
      gap: 12px;
      margin-top: 8px;
    }

    .product-card {
      border: 1px solid #EADFD2;
      border-radius: 12px;
      padding: 14px;
      cursor: pointer;
      transition: all 0.2s;
      background: #fff;
      position: relative;

      &:hover:not(.out-of-stock) {
        border-color: #E8913A;
        box-shadow: 0 4px 16px rgba(232, 145, 58, 0.15);
        transform: translateY(-2px);
      }

      &.out-of-stock {
        opacity: 0.55;
        cursor: not-allowed;
        background: #FAFAFA;
      }

      &.selected {
        border-color: #E8913A;
        background: linear-gradient(135deg, #FFF8F0, #FDF0E2);
        box-shadow: 0 0 0 2px rgba(232, 145, 58, 0.2);

        &::after {
          content: '✓';
          position: absolute;
          top: 10px;
          right: 10px;
          width: 22px;
          height: 22px;
          border-radius: 50%;
          background: #E8913A;
          color: #fff;
          font-size: 14px;
          font-weight: 700;
          display: flex;
          align-items: center;
          justify-content: center;
        }
      }

      .card-top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 8px;
      }

      .country-flag {
        font-size: 32px;
        line-height: 1;
      }

      .country-name {
        font-size: 15px;
        font-weight: 600;
        color: #2C3E50;
        margin-bottom: 4px;
      }

      .product-name {
        font-size: 12px;
        color: #718096;
        margin-bottom: 8px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .tags {
        display: flex;
        gap: 4px;
        margin-bottom: 10px;
        flex-wrap: wrap;

        :deep(.el-tag) {
          font-size: 11px;
          height: 20px;
          padding: 0 6px;
          line-height: 18px;
        }
      }

      .card-bottom {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 12px;
        padding-top: 8px;
        border-top: 1px dashed #F0E6DA;

        .duration {
          color: #909399;
        }

        .cost {
          color: #E8913A;
          font-weight: 600;
        }

        .cost-unavailable {
          color: #C0C4CC;
          font-size: 11px;
          font-style: italic;
        }
      }
    }
  }
}
</style>
