<template>
  <div class="subscription-list">
    <h2 class="page-title">订阅管理</h2>

    <!-- Quick Actions -->
    <el-card class="quick-actions">
      <div class="quick-row">
        <div class="quick-left">
          <span class="quick-label">快捷筛选：</span>
          <el-button :type="quickFilter === 3 ? 'danger' : ''" @click="applyQuickFilter(3)">3天内到期</el-button>
          <el-button :type="quickFilter === 5 ? 'warning' : ''" @click="applyQuickFilter(5)">5天内到期</el-button>
          <el-button :type="quickFilter === 7 ? 'warning' : ''" @click="applyQuickFilter(7)">7天内到期</el-button>
          <el-button :type="quickFilter === 15 ? '' : ''" @click="applyQuickFilter(15)">15天内到期</el-button>
          <el-button :type="quickFilter === 30 ? '' : ''" @click="applyQuickFilter(30)">30天内到期</el-button>
          <el-button v-if="quickFilter" link @click="clearQuickFilter">清除</el-button>
        </div>
        <div class="quick-right">
          <el-button
            type="primary"
            :disabled="!selectedMainIds.length"
            @click="openBatchForward"
          >
            <el-icon><Share /></el-icon>
            NY 转发
            <el-tag v-if="selectedMainIds.length" size="small" type="primary" style="margin-left: 6px">
              {{ selectedMainIds.length }}
            </el-tag>
          </el-button>
          <el-button
            type="success"
            :disabled="!selectedMainIds.length"
            @click="openBatchXuiForward"
          >
            <el-icon><Connection /></el-icon>
            3x-ui 中转
            <el-tag v-if="selectedMainIds.length" size="small" type="success" style="margin-left: 6px">
              {{ selectedMainIds.length }}
            </el-tag>
          </el-button>
          <el-button
            type="info"
            :disabled="!selectedMainIds.length"
            @click="openBatchExpiry"
          >
            <el-icon><Calendar /></el-icon>
            批量改到期
            <el-tag v-if="selectedMainIds.length" size="small" type="info" style="margin-left: 6px">
              {{ selectedMainIds.length }}
            </el-tag>
          </el-button>
          <el-button type="warning" :disabled="!expiringCount" @click="openBulkRenew">
            <el-icon><Refresh /></el-icon>
            一键续费 <el-tag v-if="expiringCount" size="small" type="warning" style="margin-left: 6px">{{ expiringCount }}</el-tag>
          </el-button>
          <el-button type="success" @click="$router.push('/subscriptions/create')">
            <el-icon><Plus /></el-icon>创建订单
          </el-button>
        </div>
      </div>
    </el-card>

    <el-card class="search-card">
      <el-form :inline="true" :model="searchForm">
        <el-form-item label="状态">
          <el-select v-model="searchForm.status" placeholder="全部" clearable style="width: 120px">
            <el-option label="活跃" value="active" />
            <el-option label="已过期" value="expired" />
            <el-option label="已取消" value="cancelled" />
          </el-select>
        </el-form-item>
        <el-form-item label="客户名称">
          <el-input v-model="searchForm.customer_name" placeholder="模糊搜索" clearable style="width: 160px" />
        </el-form-item>
        <el-form-item label="地区">
          <el-input v-model="searchForm.country" placeholder="如美国" clearable style="width: 120px" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="handleSearch"><el-icon><Search /></el-icon>搜索</el-button>
          <el-button @click="handleReset">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-card>
      <el-table
        :data="tableData"
        v-loading="loading"
        stripe
        ref="mainTableRef"
        @selection-change="onMainSelectionChange"
      >
        <el-table-column type="selection" width="50" :selectable="row => row.status === 'active'" />
        <el-table-column prop="id" label="ID" width="60" />
        <el-table-column label="客户" min-width="110">
          <template #default="{ row }">
            <span style="font-weight: 500">{{ row.customer?.customer_name || '-' }}</span>
          </template>
        </el-table-column>
        <el-table-column label="资产名称" min-width="200" show-overflow-tooltip>
          <template #default="{ row }">
            <div>{{ row.proxy_ip?.asset_name || '-' }}</div>
            <div v-if="row.forward_rule && row.forward_rule.status === 'active'" class="forward-tag">
              <el-tag size="small" type="warning" effect="plain">
                转发 {{ row.forward_rule.device_group?.custom_connect_host || row.forward_rule.device_group?.original_connect_host }}:{{ row.forward_rule.listen_port }}
                <span v-if="row.forward_rule.speed_limit_mbps">· {{ row.forward_rule.speed_limit_mbps }}Mbps</span>
              </el-tag>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="地区" width="80">
          <template #default="{ row }">
            {{ row.proxy_ip?.country_name || '-' }}
          </template>
        </el-table-column>
        <el-table-column label="IP归属" width="80">
          <template #default="{ row }">
            <el-tag size="small" type="info" effect="plain">{{ row.proxy_ip?.source_name || '-' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="IP组" width="90">
          <template #default="{ row }">
            {{ row.proxy_ip?.ip_group?.name || '-' }}
          </template>
        </el-table-column>
        <el-table-column label="单价/月" width="100" align="right">
          <template #default="{ row }">
            <span :style="{ color: row.price > 0 ? '#E8913A' : '#C0C4CC' }">
              ¥{{ Number(row.price || 0).toFixed(2) }}
            </span>
          </template>
        </el-table-column>
        <el-table-column label="到期时间" width="110">
          <template #default="{ row }">
            <span :style="{ color: isExpiringSoon(row.expires_at) ? '#F56C6C' : '' }">
              {{ formatDate(row.expires_at) }}
            </span>
          </template>
        </el-table-column>
        <el-table-column label="状态" width="80" align="center">
          <template #default="{ row }">
            <el-tag :type="statusTag(row.status)" size="small">{{ statusLabel(row.status) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="240" align="center" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" link size="small" @click="$router.push(`/subscriptions/${row.id}`)">详情</el-button>
            <el-button v-if="row.status === 'active'" type="success" link size="small" @click="openRenew(row)">续费</el-button>
            <el-button v-if="row.status === 'active' && canRefund(row)" type="warning" link size="small" @click="openRefund(row)">退订</el-button>
            <el-button v-if="row.status === 'active'" type="danger" link size="small" @click="handleCancel(row)">取消</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-wrap">
        <el-pagination
          v-model:current-page="pagination.page"
          v-model:page-size="pagination.per_page"
          :total="pagination.total"
          :page-sizes="[10, 20, 50, 100, 200, 500, 1000, 2000]"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="onPageSizeChange"
          @current-change="fetchData"
        />
        <div class="custom-size">
          自定义每页：
          <el-input-number
            v-model="customPageSize"
            :min="1"
            :max="5000"
            :step="50"
            size="small"
            controls-position="right"
            style="width: 130px"
          />
          <el-button size="small" type="primary" plain @click="applyCustomSize">应用</el-button>
        </div>
      </div>
    </el-card>

    <!-- Refund Dialog -->
    <el-dialog v-model="refundVisible" title="退订订阅" width="500px">
      <el-alert type="warning" :closable="false" show-icon style="margin-bottom: 16px">
        退订将退款到客户余额，并解绑IP。如果是 Spark IP 将同时调用 API 释放并获得上游退款。
      </el-alert>
      <el-form :model="refundForm" label-width="90px">
        <el-form-item label="客户">
          <el-input :value="refundTarget?.customer?.customer_name" disabled />
        </el-form-item>
        <el-form-item label="资产">
          <el-input :value="refundTarget?.proxy_ip?.asset_name" disabled />
        </el-form-item>
        <el-form-item label="原价">
          <el-input :value="`¥${Number(refundTarget?.price || 0).toFixed(2)}`" disabled />
        </el-form-item>
        <el-form-item label="退款金额">
          <el-input-number v-model="refundForm.refund_amount" :min="0" :precision="2" style="width: 100%" />
          <div style="font-size: 12px; color: #909399">默认全额退款</div>
        </el-form-item>
        <el-form-item label="退订原因">
          <el-input v-model="refundForm.reason" type="textarea" :rows="2" placeholder="选填，如客户反馈IP质量问题" />
        </el-form-item>
        <el-form-item v-if="refundTarget?.proxy_ip?.source_name === '斯帕克'" label="Spark释放">
          <el-switch v-model="refundForm.auto_release" />
          <span style="margin-left: 8px; font-size: 12px; color: #909399">
            同时调用 Spark API 释放（获得上游退款）
          </span>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="refundVisible = false">取消</el-button>
        <el-button type="warning" :loading="refundLoading" @click="submitRefund">确认退订</el-button>
      </template>
    </el-dialog>

    <!-- Renew Dialog -->
    <el-dialog v-model="renewVisible" title="续费订阅" width="480px">
      <el-form :model="renewForm" label-width="80px">
        <el-form-item label="客户">
          <el-input :value="renewTarget?.customer?.customer_name" disabled />
        </el-form-item>
        <el-form-item label="资产">
          <el-input :value="renewTarget?.proxy_ip?.asset_name" disabled />
        </el-form-item>
        <el-form-item label="续费时长">
          <div style="display: flex; gap: 8px; width: 100%">
            <el-input-number v-model="renewForm.duration" :min="1" style="flex: 1" />
            <el-select v-model="renewForm.unit" style="width: 100px">
              <el-option label="月" :value="3" />
              <el-option label="天" :value="1" />
              <el-option label="年" :value="4" />
            </el-select>
          </div>
        </el-form-item>
        <el-form-item label="单价">
          <el-input-number v-model="renewForm.price" :min="0" :precision="2" style="width: 100%" />
          <div style="font-size: 12px; color: #909399; margin-top: 4px">
            填写后将更新该订阅的续费价格（元/月）
          </div>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="renewVisible = false">取消</el-button>
        <el-button type="primary" :loading="renewLoading" @click="submitRenew">确认续费</el-button>
      </template>
    </el-dialog>

    <!-- Bulk Renew Dialog -->
    <el-dialog
      v-model="bulkRenewVisible"
      title=""
      width="1180px"
      :close-on-click-modal="false"
      destroy-on-close
      top="3vh"
      class="bulk-renew-dialog"
    >
      <template #header>
        <div class="bulk-header">
          <div class="header-title">
            <el-icon :size="22" color="#E8913A"><Refresh /></el-icon>
            <span>一键续费</span>
          </div>
          <div class="header-sub">
            批量续费即将到期的订阅，减少重复操作
          </div>
        </div>
      </template>

      <!-- 顶部汇总卡片 -->
      <div class="bulk-summary">
        <div class="summary-item">
          <div class="label">候选订阅</div>
          <div class="value">{{ filteredBulkItems.length }}<span class="unit">条</span></div>
        </div>
        <div class="summary-divider"></div>
        <div class="summary-item">
          <div class="label">涉及客户</div>
          <div class="value">{{ uniqueCustomerCount }}<span class="unit">个</span></div>
        </div>
        <div class="summary-divider"></div>
        <div class="summary-item">
          <div class="label">已勾选</div>
          <div class="value selected">{{ selectedBulkIds.length }}<span class="unit">条</span></div>
        </div>
        <div class="summary-divider"></div>
        <div class="summary-item total">
          <div class="label">合计扣费</div>
          <div class="value highlight">¥{{ bulkTotal.toFixed(2) }}</div>
        </div>
      </div>

      <!-- 筛选 + 统一价栏 -->
      <div class="bulk-control-bar">
        <el-input
          v-model="bulkFilter"
          placeholder="搜索：客户名 / 资产名 / IP / 地区"
          clearable
          :prefix-icon="Search"
          size="default"
          style="width: 280px"
        />

        <div class="control-divider"></div>

        <div class="unified-price-group">
          <span class="label">统一价：</span>
          <el-input-number
            v-model="bulkUnifiedPrice"
            :min="0"
            :precision="2"
            placeholder="填入价格"
            size="default"
            style="width: 160px"
          />
          <el-button
            type="primary"
            size="default"
            :disabled="!bulkUnifiedPrice || !selectedBulkIds.length"
            @click="applyUnifiedPrice"
          >
            应用到勾选
          </el-button>
          <el-button
            size="default"
            link
            @click="resetBulkPrices"
          >
            重置原价
          </el-button>
        </div>

        <div class="control-divider"></div>

        <div class="duration-group">
          <span class="label">时长：</span>
          <el-input-number v-model="bulkDuration" :min="1" :max="36" size="default" style="width: 90px" />
          <el-select v-model="bulkUnit" size="default" style="width: 80px; margin-left: 4px">
            <el-option label="月" :value="3" />
            <el-option label="天" :value="1" />
            <el-option label="年" :value="4" />
          </el-select>
        </div>
      </div>

      <!-- 客户分组列表 -->
      <div class="bulk-groups" v-loading="!bulkItems.length && bulkRenewVisible">
        <div
          v-for="group in groupedBulkItems"
          :key="group.customerId"
          class="customer-group"
        >
          <div class="group-header">
            <div class="group-left">
              <el-checkbox
                :model-value="isGroupFullySelected(group)"
                :indeterminate="isGroupPartiallySelected(group)"
                @change="toggleGroupSelection(group, $event)"
              />
              <div class="customer-info">
                <div class="customer-name">
                  {{ group.customerName }}
                  <el-tag v-if="group.salesPerson" size="small" type="info" effect="plain">
                    业务：{{ group.salesPerson }}
                  </el-tag>
                </div>
                <div class="customer-meta">
                  {{ group.items.length }} 条订阅，合计 ¥{{ group.totalCurrentPrice.toFixed(2) }} / 月
                </div>
              </div>
            </div>
            <div class="group-right">
              <div class="group-select-count" v-if="group.selectedCount > 0">
                已选 <strong>{{ group.selectedCount }}</strong> / {{ group.items.length }}
                ·
                <span class="group-charged">¥{{ group.selectedCharged.toFixed(2) }}</span>
              </div>
            </div>
          </div>

          <div class="group-items">
            <div
              v-for="item in group.items"
              :key="item.id"
              class="item-row"
              :class="{ selected: selectedBulkIds.includes(item.id) }"
              @click="toggleItem(item)"
            >
              <div class="row-check" @click.stop>
                <el-checkbox
                  :model-value="selectedBulkIds.includes(item.id)"
                  :disabled="item.status !== 'active'"
                  @change="toggleItem(item)"
                />
              </div>
              <div class="row-asset">
                <div class="asset-name">{{ item.proxy_ip?.asset_name || '-' }}</div>
                <div class="asset-ip mono">{{ item.proxy_ip?.ip_address }}:{{ item.proxy_ip?.port }}</div>
              </div>
              <div class="row-country">
                <el-tag size="small" type="info" effect="plain">
                  {{ item.proxy_ip?.country_name || '-' }}
                </el-tag>
                <div class="source-name">{{ item.proxy_ip?.source_name || '-' }}</div>
              </div>
              <div class="row-expires">
                <div class="expires-date" :class="{ urgent: daysToExpire(item.expires_at) <= 3 }">
                  {{ formatDate(item.expires_at) }}
                </div>
                <div class="days-left">
                  剩 <strong>{{ daysToExpire(item.expires_at) }}</strong> 天
                </div>
              </div>
              <div class="row-current-price">
                <div class="label">当前</div>
                <div class="value">¥{{ Number(item.price || 0).toFixed(2) }}</div>
              </div>
              <div class="row-new-price" @click.stop>
                <div class="label">续费价</div>
                <el-input-number
                  v-model="bulkPrices[item.id]"
                  :min="0"
                  :precision="2"
                  size="small"
                  controls-position="right"
                  :disabled="item.status !== 'active'"
                  @change="onRowPriceChange(item.id, $event)"
                  style="width: 110px"
                />
                <el-tag
                  v-if="rowPriceOverrides[item.id]"
                  size="small"
                  type="warning"
                  effect="plain"
                  style="margin-left: 4px; font-size: 10px"
                >
                  自定义
                </el-tag>
              </div>
            </div>
          </div>
        </div>

        <el-empty
          v-if="!filteredBulkItems.length && bulkItems.length"
          description="无符合筛选条件的订阅"
          :image-size="80"
        />
        <el-empty
          v-if="!bulkItems.length"
          description="暂无即将到期的订阅"
          :image-size="80"
        />
      </div>

      <template #footer>
        <div class="bulk-footer">
          <div class="footer-hint">
            <el-icon><InfoFilled /></el-icon>
            单独修改行价格后会标记为"自定义"，应用统一价时不会覆盖
          </div>
          <div class="footer-actions">
            <el-button @click="bulkRenewVisible = false" size="default">取消</el-button>
            <el-button
              type="warning"
              :loading="bulkRenewLoading"
              :disabled="!selectedBulkIds.length"
              size="default"
              @click="submitBulkRenew"
            >
              一键续费 {{ selectedBulkIds.length }} 条 · 共扣费 ¥{{ bulkTotal.toFixed(2) }}
            </el-button>
          </div>
        </div>
      </template>
    </el-dialog>

    <!-- Batch Attach Forward Dialog -->
    <el-dialog v-model="batchForwardVisible" title="批量开通端口转发" width="680px" :close-on-click-modal="false">
      <el-alert type="warning" :closable="false" show-icon style="margin-bottom: 16px">
        将为 <strong>{{ selectedMainIds.length }}</strong> 条选中的订阅创建 NY 转发规则。
        <strong>已有转发/非活跃订阅会自动跳过</strong>。转发费会加到订阅月单价上，下次续费生效。
      </el-alert>

      <el-form :model="batchForwardForm" label-width="120px">
        <el-form-item label="选中条数">
          <el-tag type="primary">{{ selectedMainIds.length }} 条订阅</el-tag>
        </el-form-item>

        <el-form-item label="转发节点">
          <el-select
            v-model="batchForwardForm.device_group_id"
            placeholder="选择 NY 设备组"
            style="width: 100%"
            filterable
          >
            <el-option
              v-for="dg in deviceGroupOptions"
              :key="dg.id"
              :label="`[${dg.panel?.name}] ${dg.name}`"
              :value="dg.id"
            >
              <div style="display: flex; justify-content: space-between; align-items: center">
                <span>{{ dg.name }}</span>
                <span class="mono" style="font-size: 11px; color: #909399">
                  {{ dg.custom_connect_host || dg.original_connect_host }}
                </span>
              </div>
            </el-option>
          </el-select>
        </el-form-item>

        <el-form-item label="限速 (Mbps)">
          <el-input-number
            v-model="batchForwardForm.speed_limit_mbps"
            :min="1"
            :max="10000"
            placeholder="留空不限速"
            controls-position="right"
            style="width: 220px"
          />
          <span class="hint">留空 = 不限速</span>
        </el-form-item>

        <el-form-item label="额外转发费">
          <el-input-number
            v-model="batchForwardForm.forward_fee"
            :min="0"
            :precision="2"
            controls-position="right"
            style="width: 220px"
          />
          <span class="hint">每条每月，0 = 免费（不改订阅价格）</span>
        </el-form-item>
      </el-form>

      <template #footer>
        <el-button @click="batchForwardVisible = false">取消</el-button>
        <el-button
          type="primary"
          :loading="batchForwardLoading"
          :disabled="!batchForwardForm.device_group_id"
          @click="submitBatchForward"
        >
          确认开通 {{ selectedMainIds.length }} 条
        </el-button>
      </template>
    </el-dialog>

    <!-- Batch Attach XUI Dialog -->
    <el-dialog
      v-model="batchXuiVisible"
      title="批量开通 3x-ui 中转"
      width="600px"
      :close-on-click-modal="false"
    >
      <el-alert type="info" :closable="false" show-icon style="margin-bottom: 14px">
        将为 <strong>{{ selectedMainIds.length }}</strong> 条选中订阅在 3x-ui 面板创建 vless+reality 中转。
        <br>每条约需 3-5 秒，任务会进入队列逐条处理，失败和已有中转的会自动跳过。
      </el-alert>

      <el-form label-width="130px">
        <el-form-item label="选中条数">
          <el-tag type="success">{{ selectedMainIds.length }} 条订阅</el-tag>
        </el-form-item>
        <el-form-item label="3x-ui 面板">
          <el-select
            v-model="batchXuiForm.xui_panel_id"
            placeholder="选择主面板（非备机）"
            style="width: 100%"
            filterable
          >
            <el-option
              v-for="p in xuiPanelOptions"
              :key="p.id"
              :label="`${p.name} (${p.connect_host || p.api_url})`"
              :value="p.id"
            />
          </el-select>
          <div class="hint">备机会自动同步，不用在这里选</div>
        </el-form-item>
      </el-form>

      <template #footer>
        <el-button @click="batchXuiVisible = false">取消</el-button>
        <el-button
          type="success"
          :loading="batchXuiLoading"
          :disabled="!batchXuiForm.xui_panel_id"
          @click="submitBatchXui"
        >
          确认开通 {{ selectedMainIds.length }} 条
        </el-button>
      </template>
    </el-dialog>

    <!-- Batch Forward Progress Dialog -->
    <el-dialog
      v-model="batchProgressVisible"
      title="批量转发任务进度"
      width="600px"
      :close-on-click-modal="false"
      :show-close="batchProgress.finished"
      @close="closeBatchProgress"
    >
      <el-alert v-if="!batchProgress.finished" type="info" :closable="false" show-icon style="margin-bottom: 14px">
        任务正在队列中逐条处理，每条约需 1-2 秒。本弹窗可以关闭，稍后在订阅列表刷新即可查看结果。
      </el-alert>
      <el-alert v-else :type="batchProgress.failed > 0 ? 'warning' : 'success'" :closable="false" show-icon style="margin-bottom: 14px">
        {{ batchProgress.failed > 0
          ? `已完成：${batchProgress.active} 条成功 / ${batchProgress.failed} 条失败`
          : `全部完成：${batchProgress.active} 条转发成功 🎉` }}
      </el-alert>

      <el-progress
        :percentage="batchProgress.progress_pct"
        :status="batchProgress.finished ? (batchProgress.failed > 0 ? 'warning' : 'success') : undefined"
        :stroke-width="18"
      />

      <div class="batch-stats">
        <div class="stat-item"><span class="label">总数</span><span class="val">{{ batchProgress.total }}</span></div>
        <div class="stat-item"><span class="label">待处理</span><span class="val pending">{{ batchProgress.pending }}</span></div>
        <div class="stat-item"><span class="label">处理中</span><span class="val processing">{{ batchProgress.processing }}</span></div>
        <div class="stat-item"><span class="label">已成功</span><span class="val success">{{ batchProgress.active }}</span></div>
        <div class="stat-item"><span class="label">失败</span><span class="val fail">{{ batchProgress.failed }}</span></div>
      </div>

      <div v-if="batchProgress.failed > 0 && batchProgress.failed_rules?.length" class="failed-list">
        <div class="failed-title">失败详情（前 10 条）：</div>
        <div v-for="f in batchProgress.failed_rules.slice(0, 10)" :key="f.id" class="failed-row">
          <strong>#{{ f.subscription_id }}</strong>
          <span style="color: #909399">· {{ f.customer || '-' }} · {{ f.asset_name }}</span>
          <div style="color: #F56C6C; font-size: 12px; margin-top: 2px">{{ f.error }}</div>
        </div>
      </div>

      <template #footer>
        <el-button v-if="!batchProgress.finished" @click="closeBatchProgress">后台处理</el-button>
        <el-button v-else type="primary" @click="closeBatchProgress">关闭</el-button>
      </template>
    </el-dialog>

    <!-- Batch Update Expiry Dialog -->
    <el-dialog v-model="batchExpiryVisible" title="批量修改到期时间" width="540px" :close-on-click-modal="false">
      <el-alert type="warning" :closable="false" show-icon style="margin-bottom: 16px">
        将为 <strong>{{ selectedMainIds.length }}</strong> 条订阅强制设置到期时间。
        <br>此操作不会扣费、不会调用 Spark API，仅修改本地记录。
      </el-alert>

      <el-form :model="batchExpiryForm" label-width="120px">
        <el-form-item label="选中条数">
          <el-tag type="info">{{ selectedMainIds.length }} 条订阅</el-tag>
        </el-form-item>
        <el-form-item label="新到期日期">
          <el-date-picker
            v-model="batchExpiryForm.expires_at"
            type="date"
            placeholder="选择日期"
            value-format="YYYY-MM-DD"
            :disabled-date="(d) => d < dayjs().subtract(1, 'year').toDate()"
            style="width: 100%"
          />
          <div class="hint" style="margin-top: 4px">未来日期 → 状态自动设为 active；过去日期 → expired</div>
        </el-form-item>
        <el-form-item label="同步 IP 资产">
          <el-switch v-model="batchExpiryForm.sync_proxy_ip" />
          <span class="hint">同时更新 ProxyIp.upstream_expires_at（推荐开启）</span>
        </el-form-item>
      </el-form>

      <template #footer>
        <el-button @click="batchExpiryVisible = false">取消</el-button>
        <el-button
          type="primary"
          :loading="batchExpiryLoading"
          :disabled="!batchExpiryForm.expires_at"
          @click="submitBatchExpiry"
        >
          确认修改 {{ selectedMainIds.length }} 条
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Search, Refresh, InfoFilled, Share, Plus, Calendar, Connection } from '@element-plus/icons-vue'
import dayjs from 'dayjs'
import {
  getSubscriptions, renewSubscription, cancelSubscription, refundSubscription,
  bulkRenewSubscriptions, batchAttachForward, getBatchForwardStatus,
  batchUpdateExpiry, batchAttachXuiForward, getBatchXuiForwardStatus,
} from '@/api/subscriptions'
import { getNyEnabledDeviceGroups } from '@/api/nyPanels'
import { getUsableXuiPanels } from '@/api/xuiPanels'

const loading = ref(false)
const tableData = ref([])
const searchForm = reactive({ status: '', customer_name: '', country: '', expiring_soon: null })
const pagination = reactive({ page: 1, per_page: 20, total: 0 })
const customPageSize = ref(100)
const quickFilter = ref(null) // 当前快捷筛选天数
const expiringCount = ref(0)  // 5 天内到期的总数，用于"一键续费"徽章

function onPageSizeChange(size) {
  pagination.per_page = size
  pagination.page = 1
  fetchData()
}

function applyCustomSize() {
  if (!customPageSize.value || customPageSize.value < 1) return
  pagination.per_page = customPageSize.value
  pagination.page = 1
  fetchData()
}

function formatDate(d) { return d ? dayjs(d).format('YYYY-MM-DD') : '-' }
function isExpiringSoon(d) { return d && dayjs(d).diff(dayjs(), 'day') <= 7 && dayjs(d).isAfter(dayjs()) }
function daysToExpire(d) { return d ? Math.max(0, dayjs(d).diff(dayjs(), 'day')) : 0 }
function statusTag(s) { return { active: 'success', expired: 'danger', cancelled: 'info' }[s] || 'info' }
function statusLabel(s) { return { active: '活跃', expired: '已过期', cancelled: '已取消', refunded: '已退订', suspended: '已暂停' }[s] || s }

// 1天内可退订
function canRefund(row) {
  if (!row.started_at) return false
  const hours = dayjs().diff(dayjs(row.started_at), 'hour')
  return hours <= 24
}

async function fetchData() {
  loading.value = true
  try {
    const params = { page: pagination.page, per_page: pagination.per_page }
    if (searchForm.status) params['filter[status]'] = searchForm.status
    if (searchForm.customer_name) params['filter[customer_name]'] = searchForm.customer_name
    if (searchForm.country) params['filter[country]'] = searchForm.country
    if (searchForm.expiring_soon) params['filter[expiring_soon]'] = searchForm.expiring_soon
    const res = await getSubscriptions(params)
    tableData.value = res?.items || []
    pagination.total = res?.pagination?.total || 0
  } catch { /* handled */ }
  finally { loading.value = false }
}

function handleSearch() { pagination.page = 1; fetchData() }
function handleReset() {
  Object.assign(searchForm, { status: '', customer_name: '', country: '', expiring_soon: null })
  quickFilter.value = null
  pagination.page = 1
  fetchData()
}

function applyQuickFilter(days) {
  quickFilter.value = days
  searchForm.status = 'active'
  searchForm.expiring_soon = days
  pagination.page = 1
  fetchData()
}

function clearQuickFilter() {
  quickFilter.value = null
  searchForm.expiring_soon = null
  pagination.page = 1
  fetchData()
}

// 统计 5 天内到期数量（用于徽章）
async function fetchExpiringCount() {
  try {
    const res = await getSubscriptions({
      page: 1,
      per_page: 1,
      'filter[status]': 'active',
      'filter[expiring_soon]': 5,
    })
    expiringCount.value = res?.pagination?.total || 0
  } catch { expiringCount.value = 0 }
}

async function handleCancel(row) {
  try {
    await ElMessageBox.confirm(`取消「${row.customer?.customer_name}」的订阅？IP将释放为可用状态`, '取消订阅', { type: 'warning' })
    await cancelSubscription(row.id)
    ElMessage.success('已取消')
    fetchData()
  } catch { /* cancelled */ }
}

// Renew
const renewVisible = ref(false)
const renewLoading = ref(false)
const renewTarget = ref(null)
const renewForm = reactive({ duration: 1, unit: 3, price: 0 })

function openRenew(row) {
  renewTarget.value = row
  renewForm.duration = 1
  renewForm.unit = 3
  renewForm.price = parseFloat(row.price) || 0
  renewVisible.value = true
}

async function submitRenew() {
  renewLoading.value = true
  try {
    await renewSubscription(renewTarget.value.id, renewForm)
    ElMessage.success('续费成功')
    renewVisible.value = false
    fetchData()
  } catch { /* handled */ }
  finally { renewLoading.value = false }
}

// Refund
const refundVisible = ref(false)
const refundLoading = ref(false)
const refundTarget = ref(null)
const refundForm = reactive({ refund_amount: 0, reason: '', auto_release: true })

function openRefund(row) {
  refundTarget.value = row
  refundForm.refund_amount = parseFloat(row.price) || 0
  refundForm.reason = ''
  refundForm.auto_release = true
  refundVisible.value = true
}

async function submitRefund() {
  refundLoading.value = true
  try {
    const res = await refundSubscription(refundTarget.value.id, { ...refundForm })
    const spark = res?.spark_release
    if (spark && spark.status === 'failed') {
      ElMessage({
        type: 'warning',
        message: `退订已处理，但 Spark 释放失败：${spark.message}。请到 IP 详情页查看并重试。`,
        duration: 8000,
      })
    } else if (spark && spark.status === 'confirmed') {
      ElMessage.success('退订成功，Spark 已确认释放')
    } else if (spark && spark.status === 'pending') {
      ElMessage({
        type: 'success',
        message: '退订成功，Spark 已受理释放请求（等待上游确认）',
        duration: 5000,
      })
    } else {
      ElMessage.success('退订成功')
    }
    refundVisible.value = false
    fetchData()
  } catch { /* handled */ }
  finally { refundLoading.value = false }
}

// ========== Bulk Renew ==========
const bulkRenewVisible = ref(false)
const bulkRenewLoading = ref(false)
const bulkItems = ref([])          // 对话框内的候选订阅列表
const bulkPrices = reactive({})    // { subscriptionId: price } 每行单价
const rowPriceOverrides = reactive({}) // 标记被手动修改过的行，不受统一价影响
const selectedBulkIds = ref([])
const bulkFilter = ref('')
const bulkUnifiedPrice = ref(null)
const bulkDuration = ref(1)
const bulkUnit = ref(3)

const filteredBulkItems = computed(() => {
  const kw = bulkFilter.value.trim().toLowerCase()
  if (!kw) return bulkItems.value
  return bulkItems.value.filter(i => {
    return (i.customer?.customer_name || '').toLowerCase().includes(kw)
      || (i.proxy_ip?.asset_name || '').toLowerCase().includes(kw)
      || (i.proxy_ip?.ip_address || '').toLowerCase().includes(kw)
      || (i.proxy_ip?.country_name || '').toLowerCase().includes(kw)
  })
})

const bulkTotal = computed(() => {
  return selectedBulkIds.value.reduce((sum, id) => sum + (Number(bulkPrices[id]) || 0), 0)
})

// 涉及客户数量
const uniqueCustomerCount = computed(() => {
  const s = new Set(filteredBulkItems.value.map(i => i.customer?.id).filter(Boolean))
  return s.size
})

// 按客户分组
const groupedBulkItems = computed(() => {
  const map = new Map()
  for (const item of filteredBulkItems.value) {
    const id = item.customer?.id || 0
    if (!map.has(id)) {
      map.set(id, {
        customerId: id,
        customerName: item.customer?.customer_name || '未知客户',
        salesPerson: item.customer?.sales_person,
        items: [],
        totalCurrentPrice: 0,
      })
    }
    const group = map.get(id)
    group.items.push(item)
    group.totalCurrentPrice += Number(item.price || 0)
  }
  // 计算每组的选中数和选中后扣费
  for (const g of map.values()) {
    g.selectedCount = g.items.filter(i => selectedBulkIds.value.includes(i.id)).length
    g.selectedCharged = g.items
      .filter(i => selectedBulkIds.value.includes(i.id))
      .reduce((s, i) => s + Number(bulkPrices[i.id] || 0), 0)
  }
  // 按剩余天数最紧迫的排前面
  return Array.from(map.values()).sort((a, b) => {
    const dayA = Math.min(...a.items.map(i => daysToExpire(i.expires_at)))
    const dayB = Math.min(...b.items.map(i => daysToExpire(i.expires_at)))
    return dayA - dayB
  })
})

function isGroupFullySelected(group) {
  return group.items.length > 0 && group.items.every(i => selectedBulkIds.value.includes(i.id))
}

function isGroupPartiallySelected(group) {
  const selected = group.items.filter(i => selectedBulkIds.value.includes(i.id)).length
  return selected > 0 && selected < group.items.length
}

function toggleGroupSelection(group, checked) {
  const ids = group.items.filter(i => i.status === 'active').map(i => i.id)
  if (checked) {
    const set = new Set([...selectedBulkIds.value, ...ids])
    selectedBulkIds.value = Array.from(set)
  } else {
    selectedBulkIds.value = selectedBulkIds.value.filter(id => !ids.includes(id))
  }
}

function toggleItem(item) {
  if (item.status !== 'active') return
  const idx = selectedBulkIds.value.indexOf(item.id)
  if (idx >= 0) {
    selectedBulkIds.value.splice(idx, 1)
  } else {
    selectedBulkIds.value.push(item.id)
  }
}

function resetBulkPrices() {
  bulkItems.value.forEach(i => {
    bulkPrices[i.id] = Number(i.price) || 0
    delete rowPriceOverrides[i.id]
  })
  ElMessage.success('已重置为原价')
}

async function openBulkRenew() {
  bulkRenewLoading.value = false
  bulkRenewVisible.value = true
  bulkItems.value = []

  // 拉取 5 天内到期的全部活跃订阅
  try {
    const res = await getSubscriptions({
      page: 1,
      per_page: 200,
      'filter[status]': 'active',
      'filter[expiring_soon]': 5,
    })
    const items = res?.items || []
    bulkItems.value = items
    // 初始化每行价格为当前订阅的 price
    Object.keys(bulkPrices).forEach(k => delete bulkPrices[k])
    Object.keys(rowPriceOverrides).forEach(k => delete rowPriceOverrides[k])
    items.forEach(i => { bulkPrices[i.id] = Number(i.price) || 0 })
    bulkUnifiedPrice.value = null
    // 默认全选所有活跃项
    selectedBulkIds.value = items.filter(i => i.status === 'active').map(i => i.id)
  } catch { /* handled */ }
}

function onRowPriceChange(id, value) {
  // 标记这一行为"手动覆盖"，不被统一价再同步
  rowPriceOverrides[id] = true
}

function applyUnifiedPrice() {
  if (!bulkUnifiedPrice.value) return
  selectedBulkIds.value.forEach(id => {
    // 只对未被手动覆盖的行应用统一价
    if (!rowPriceOverrides[id]) {
      bulkPrices[id] = bulkUnifiedPrice.value
    }
  })
  ElMessage.success(`已应用到 ${selectedBulkIds.value.filter(id => !rowPriceOverrides[id]).length} 行`)
}

async function submitBulkRenew() {
  if (!selectedBulkIds.value.length) {
    ElMessage.warning('请至少勾选一条')
    return
  }
  // 校验所有勾选行都有价格
  const invalid = selectedBulkIds.value.filter(id => !bulkPrices[id] || bulkPrices[id] <= 0)
  if (invalid.length) {
    ElMessage.warning(`有 ${invalid.length} 行未填写续费价格`)
    return
  }

  try {
    await ElMessageBox.confirm(
      `确认对 ${selectedBulkIds.value.length} 条订阅进行续费？合计扣费 ¥${bulkTotal.value.toFixed(2)}`,
      '批量续费确认',
      { type: 'warning' }
    )
  } catch { return }

  bulkRenewLoading.value = true
  try {
    const payload = {
      duration: bulkDuration.value,
      unit: bulkUnit.value,
      items: selectedBulkIds.value.map(id => ({
        id,
        price: bulkPrices[id],
      })),
    }
    const res = await bulkRenewSubscriptions(payload)
    const { succeeded_count, failed_count, failed } = res || {}

    if (failed_count > 0) {
      const failDetail = failed.slice(0, 5).map(f => `#${f.id} ${f.customer || ''} - ${f.reason}`).join('<br>')
      ElMessageBox.alert(
        `<div>成功 <strong style="color:#67C23A">${succeeded_count}</strong> 条，
        失败 <strong style="color:#F56C6C">${failed_count}</strong> 条</div>
        <div style="margin-top:12px;font-size:13px;color:#606266">
          <div>失败原因：</div>
          ${failDetail}
          ${failed.length > 5 ? `<div style="margin-top:4px">... 还有 ${failed.length - 5} 条</div>` : ''}
        </div>`,
        '批量续费结果',
        { dangerouslyUseHTMLString: true, type: failed_count === succeeded_count + failed_count ? 'error' : 'warning' }
      )
    } else {
      ElMessage.success(`已成功续费 ${succeeded_count} 条`)
    }

    bulkRenewVisible.value = false
    fetchData()
    fetchExpiringCount()
  } catch { /* handled */ }
  finally { bulkRenewLoading.value = false }
}

// ========== Batch Attach Forward ==========
const mainTableRef = ref()
const selectedMainIds = ref([])
const deviceGroupOptions = ref([])

const batchForwardVisible = ref(false)
const batchForwardLoading = ref(false)
const batchForwardForm = reactive({
  device_group_id: null,
  speed_limit_mbps: null,
  forward_fee: 0,
})

function onMainSelectionChange(rows) {
  selectedMainIds.value = rows.map(r => r.id)
}

async function loadDeviceGroups() {
  try {
    deviceGroupOptions.value = (await getNyEnabledDeviceGroups()) || []
  } catch { /* handled */ }
}

function openBatchForward() {
  if (!selectedMainIds.value.length) {
    ElMessage.warning('请先勾选订阅')
    return
  }
  batchForwardForm.device_group_id = null
  batchForwardForm.speed_limit_mbps = null
  batchForwardForm.forward_fee = 0
  batchForwardVisible.value = true
}

async function submitBatchForward() {
  if (!batchForwardForm.device_group_id) {
    ElMessage.warning('请选择转发节点')
    return
  }
  try {
    await ElMessageBox.confirm(
      `确认为 ${selectedMainIds.value.length} 条订阅提交批量转发任务？\n每条月费 +¥${Number(batchForwardForm.forward_fee || 0).toFixed(2)}\n\n任务会进入队列后台逐条处理，本界面可以关闭，处理完后可以刷新列表查看结果。`,
      '批量开通确认',
      { type: 'warning' }
    )
  } catch { return }

  batchForwardLoading.value = true
  try {
    const res = await batchAttachForward({
      subscription_ids: selectedMainIds.value,
      device_group_id: batchForwardForm.device_group_id,
      speed_limit_mbps: batchForwardForm.speed_limit_mbps || null,
      forward_fee: Number(batchForwardForm.forward_fee || 0),
    })

    const { batch_id, queued_count, skipped_count, skipped } = res || {}

    ElMessage.success(`已入队 ${queued_count} 条${skipped_count ? `，跳过 ${skipped_count} 条` : ''}`)

    batchForwardVisible.value = false
    mainTableRef.value?.clearSelection()
    selectedMainIds.value = []

    // 打开进度弹窗并启动轮询
    if (batch_id && queued_count > 0) {
      openBatchProgress(batch_id)
    } else if (skipped_count > 0) {
      showSkippedDetail(skipped)
    }

    fetchData()
  } catch { /* handled */ }
  finally { batchForwardLoading.value = false }
}

// ========== Batch Forward Progress Polling ==========
const batchProgressVisible = ref(false)
const batchProgress = reactive({
  batch_id: '',
  total: 0,
  pending: 0,
  processing: 0,
  active: 0,
  failed: 0,
  finished: false,
  progress_pct: 0,
  failed_rules: [],
})
let batchPollTimer = null
let batchPollKind = 'ny' // ny | xui

function openBatchProgress(batchId, kind = 'ny') {
  batchProgress.batch_id = batchId
  batchPollKind = kind
  batchProgress.total = 0
  batchProgress.pending = 0
  batchProgress.processing = 0
  batchProgress.active = 0
  batchProgress.failed = 0
  batchProgress.finished = false
  batchProgress.progress_pct = 0
  batchProgress.failed_rules = []
  batchProgressVisible.value = true
  pollBatchProgress()
}

async function pollBatchProgress() {
  if (!batchProgress.batch_id) return
  try {
    const res = batchPollKind === 'xui'
      ? await getBatchXuiForwardStatus(batchProgress.batch_id)
      : await getBatchForwardStatus(batchProgress.batch_id)
    Object.assign(batchProgress, res)
  } catch { /* 网络错误继续重试 */ }

  if (!batchProgress.finished && batchProgressVisible.value) {
    batchPollTimer = setTimeout(pollBatchProgress, 3000)
  } else if (batchProgress.finished) {
    fetchData()
  }
}

function closeBatchProgress() {
  batchProgressVisible.value = false
  if (batchPollTimer) {
    clearTimeout(batchPollTimer)
    batchPollTimer = null
  }
}

function showSkippedDetail(skipped) {
  const detail = (skipped || []).slice(0, 10)
    .map(s => `<div>#${s.id}: ${s.reason}</div>`).join('')
  ElMessageBox.alert(
    `<div>跳过的订阅：</div><div style="margin-top:8px;font-size:12px;color:#E6A23C">${detail}</div>`,
    '跳过详情',
    { dangerouslyUseHTMLString: true, type: 'info' }
  )
}

// ========== Batch Update Expiry ==========
const batchExpiryVisible = ref(false)
const batchExpiryLoading = ref(false)
const batchExpiryForm = reactive({
  expires_at: null,
  sync_proxy_ip: true,
})

function openBatchExpiry() {
  if (!selectedMainIds.value.length) {
    ElMessage.warning('请先勾选订阅')
    return
  }
  batchExpiryForm.expires_at = null
  batchExpiryForm.sync_proxy_ip = true
  batchExpiryVisible.value = true
}

async function submitBatchExpiry() {
  if (!batchExpiryForm.expires_at) {
    ElMessage.warning('请选择新到期日期')
    return
  }
  try {
    await ElMessageBox.confirm(
      `确认将 ${selectedMainIds.value.length} 条订阅的到期时间设置为 ${batchExpiryForm.expires_at}？`,
      '批量修改确认',
      { type: 'warning' }
    )
  } catch { return }

  batchExpiryLoading.value = true
  try {
    const res = await batchUpdateExpiry({
      subscription_ids: selectedMainIds.value,
      expires_at: batchExpiryForm.expires_at,
      sync_proxy_ip: batchExpiryForm.sync_proxy_ip,
    })
    ElMessage.success(`已更新 ${res?.updated_count || 0} 条订阅`)
    batchExpiryVisible.value = false
    mainTableRef.value?.clearSelection()
    selectedMainIds.value = []
    fetchData()
  } catch { /* handled */ }
  finally { batchExpiryLoading.value = false }
}

// ========== Batch 3x-ui Forward ==========
const batchXuiVisible = ref(false)
const batchXuiLoading = ref(false)
const xuiPanelOptions = ref([])
const batchXuiForm = reactive({
  xui_panel_id: null,
})

async function loadXuiPanels() {
  try {
    xuiPanelOptions.value = (await getUsableXuiPanels()) || []
  } catch { /* handled */ }
}

function openBatchXuiForward() {
  if (!selectedMainIds.value.length) {
    ElMessage.warning('请先勾选订阅')
    return
  }
  batchXuiForm.xui_panel_id = null
  // 如果只有一个可用主面板，默认选上
  if (xuiPanelOptions.value.length === 1) {
    batchXuiForm.xui_panel_id = xuiPanelOptions.value[0].id
  }
  batchXuiVisible.value = true
}

async function submitBatchXui() {
  if (!batchXuiForm.xui_panel_id) {
    ElMessage.warning('请选择 3x-ui 面板')
    return
  }
  try {
    await ElMessageBox.confirm(
      `确认为 ${selectedMainIds.value.length} 条订阅创建 3x-ui 中转？\n\n任务会进入队列处理，每条 3-5 秒，可以关闭弹窗在后台跑。`,
      '批量开通 3x-ui 中转',
      { type: 'warning' }
    )
  } catch { return }

  batchXuiLoading.value = true
  try {
    const res = await batchAttachXuiForward({
      subscription_ids: selectedMainIds.value,
      xui_panel_id: batchXuiForm.xui_panel_id,
    })

    const { batch_id, queued_count, skipped_count, skipped } = res || {}
    ElMessage.success(`已入队 ${queued_count} 条${skipped_count ? `，跳过 ${skipped_count} 条` : ''}`)

    batchXuiVisible.value = false
    mainTableRef.value?.clearSelection()
    selectedMainIds.value = []

    if (batch_id && queued_count > 0) {
      openBatchProgress(batch_id, 'xui')
    } else if (skipped_count > 0) {
      showSkippedDetail(skipped)
    }
    fetchData()
  } catch { /* handled */ }
  finally { batchXuiLoading.value = false }
}

onMounted(() => {
  fetchData()
  fetchExpiringCount()
  loadDeviceGroups()
  loadXuiPanels()
})
</script>

<style lang="scss" scoped>
.subscription-list {
  .page-title { margin: 0 0 20px; font-size: 20px; font-weight: 600; color: #2C3E50; }
  .search-card { margin-bottom: 16px; :deep(.el-card__body) { padding-bottom: 2px; } }
  .pagination-wrap {
    display: flex;
    justify-content: flex-end;
    align-items: center;
    gap: 16px;
    margin-top: 16px;
    flex-wrap: wrap;
    .custom-size {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 13px;
      color: #606266;
      padding: 4px 10px;
      background: #FAF7F2;
      border-radius: 6px;
    }
  }

  .quick-actions {
    margin-bottom: 12px;
    :deep(.el-card__body) { padding: 14px 18px; }
    .quick-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 10px;
    }
    .quick-left {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 8px;
      .quick-label { font-size: 13px; color: #4A5568; margin-right: 4px; }
    }
    .quick-right { display: flex; gap: 8px; }
  }

  .mono { font-family: 'SF Mono', Consolas, Monaco, monospace; font-size: 12px; color: #4A5568; }
  .forward-tag { margin-top: 2px; }
  .hint { margin-left: 8px; font-size: 12px; color: #909399; }
}

.batch-stats {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 8px;
  margin-top: 16px;
  .stat-item {
    text-align: center;
    padding: 10px 6px;
    background: #FAF7F2;
    border-radius: 8px;
    .label { display: block; font-size: 11px; color: #909399; }
    .val {
      display: block;
      font-size: 20px;
      font-weight: 700;
      color: #2C3E50;
      margin-top: 4px;
      font-family: 'SF Mono', Consolas, Monaco, monospace;
      &.pending { color: #909399; }
      &.processing { color: #409EFF; }
      &.success { color: #67C23A; }
      &.fail { color: #F56C6C; }
    }
  }
}
.failed-list {
  margin-top: 14px;
  max-height: 220px;
  overflow-y: auto;
  padding: 10px 12px;
  background: #FEF0F0;
  border: 1px solid #FDE2E2;
  border-radius: 6px;
  .failed-title { font-size: 13px; font-weight: 600; color: #F56C6C; margin-bottom: 6px; }
  .failed-row {
    padding: 6px 0;
    font-size: 12px;
    border-bottom: 1px dashed #FDE2E2;
    &:last-child { border-bottom: none; }
  }
}

// ========== Bulk Renew Dialog ==========
.bulk-renew-dialog {
  :deep(.el-dialog__header) {
    padding: 20px 24px 14px;
    border-bottom: 1px solid #F0E6DA;
  }
  :deep(.el-dialog__body) {
    padding: 16px 24px;
    background: #FAFAFA;
  }
  :deep(.el-dialog__footer) {
    padding: 14px 24px;
    border-top: 1px solid #F0E6DA;
    background: #fff;
  }
}

.bulk-header {
  .header-title {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 19px;
    font-weight: 700;
    color: #2C3E50;
  }
  .header-sub {
    margin-top: 4px;
    margin-left: 32px;
    font-size: 12px;
    color: #909399;
  }
}

.bulk-summary {
  display: flex;
  align-items: stretch;
  background: #fff;
  border: 1px solid #EADFD2;
  border-radius: 10px;
  padding: 14px 0;
  margin-bottom: 14px;

  .summary-item {
    flex: 1;
    text-align: center;
    padding: 0 12px;
    .label {
      font-size: 12px;
      color: #909399;
      margin-bottom: 4px;
    }
    .value {
      font-size: 22px;
      font-weight: 700;
      color: #2C3E50;
      .unit {
        font-size: 12px;
        font-weight: 400;
        color: #909399;
        margin-left: 2px;
      }
      &.selected { color: #409EFF; }
      &.highlight { color: #E8913A; font-size: 24px; }
    }
    &.total {
      background: linear-gradient(135deg, #FFF8F0, #FDF0E2);
      border-radius: 0 8px 8px 0;
    }
  }
  .summary-divider {
    width: 1px;
    background: #F0E6DA;
  }
}

.bulk-control-bar {
  display: flex;
  align-items: center;
  gap: 14px;
  background: #fff;
  border: 1px solid #EADFD2;
  border-radius: 10px;
  padding: 10px 14px;
  margin-bottom: 14px;
  flex-wrap: wrap;

  .control-divider {
    width: 1px;
    height: 22px;
    background: #E4E7ED;
  }

  .unified-price-group, .duration-group {
    display: flex;
    align-items: center;
    gap: 6px;
    .label {
      font-size: 13px;
      color: #4A5568;
      font-weight: 500;
    }
  }
}

.bulk-groups {
  max-height: 520px;
  overflow-y: auto;
  padding-right: 4px;
}

.customer-group {
  background: #fff;
  border: 1px solid #EADFD2;
  border-radius: 10px;
  margin-bottom: 12px;
  overflow: hidden;

  .group-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 16px;
    background: linear-gradient(135deg, #FFF8F0, #FDF0E2);
    border-bottom: 1px solid #F5D9B5;

    .group-left {
      display: flex;
      align-items: center;
      gap: 12px;
      .customer-info {
        .customer-name {
          font-size: 15px;
          font-weight: 700;
          color: #2C3E50;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .customer-meta {
          font-size: 12px;
          color: #909399;
          margin-top: 2px;
        }
      }
    }

    .group-select-count {
      font-size: 13px;
      color: #4A5568;
      strong { color: #409EFF; }
      .group-charged { color: #E8913A; font-weight: 600; }
    }
  }

  .group-items {
    .item-row {
      display: grid;
      grid-template-columns: 44px 1fr 140px 120px 90px 180px;
      gap: 12px;
      align-items: center;
      padding: 10px 16px;
      border-bottom: 1px dashed #F0E6DA;
      cursor: pointer;
      transition: background 0.15s;

      &:last-child { border-bottom: none; }
      &:hover { background: #FAFAFA; }
      &.selected {
        background: linear-gradient(90deg, rgba(232, 145, 58, 0.06), transparent);
        border-left: 3px solid #E8913A;
        padding-left: 13px;
      }

      .row-asset {
        .asset-name {
          font-size: 13px;
          font-weight: 500;
          color: #2C3E50;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .asset-ip {
          font-size: 11px;
          color: #909399;
          margin-top: 2px;
        }
      }

      .row-country {
        .source-name {
          font-size: 11px;
          color: #909399;
          margin-top: 3px;
        }
      }

      .row-expires {
        .expires-date {
          font-size: 13px;
          color: #E6A23C;
          font-weight: 500;
          &.urgent { color: #F56C6C; }
        }
        .days-left {
          font-size: 11px;
          color: #909399;
          margin-top: 2px;
          strong { color: #F56C6C; }
        }
      }

      .row-current-price {
        text-align: right;
        .label {
          font-size: 10px;
          color: #C0C4CC;
        }
        .value {
          font-size: 13px;
          color: #606266;
        }
      }

      .row-new-price {
        display: flex;
        align-items: center;
        gap: 4px;
        .label {
          font-size: 11px;
          color: #909399;
          margin-right: 2px;
        }
      }
    }
  }
}

.bulk-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  .footer-hint {
    display: flex;
    align-items: center;
    gap: 4px;
    font-size: 12px;
    color: #909399;
  }
  .footer-actions {
    display: flex;
    gap: 8px;
  }
}
</style>
