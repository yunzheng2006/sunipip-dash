<template>
  <el-container class="app-layout">
    <!-- Sidebar -->
    <el-aside :width="appStore.sidebarCollapsed ? '64px' : '230px'" class="sidebar">
      <div class="logo">
        <div class="logo-icon">S</div>
        <transition name="fade">
          <span v-if="!appStore.sidebarCollapsed" class="logo-text">SuniPIP</span>
        </transition>
      </div>
      <el-scrollbar>
        <el-menu
          :default-active="activeMenu"
          :collapse="appStore.sidebarCollapsed"
          :collapse-transition="false"
          background-color="transparent"
          text-color="rgba(255,255,255,0.65)"
          active-text-color="#F2A85A"
          router
          class="sidebar-menu"
        >
          <el-menu-item v-if="can('dashboard.view')" index="/dashboard">
            <el-icon><Odometer /></el-icon>
            <template #title>仪表盘</template>
          </el-menu-item>

          <el-menu-item v-if="can('customer.view')" index="/customers">
            <el-icon><User /></el-icon>
            <template #title>客户管理</template>
          </el-menu-item>

          <el-sub-menu v-if="can('ip.view') || can('asset_group.view')" index="proxy-ips">
            <template #title>
              <el-icon><Monitor /></el-icon>
              <span>IP资产管理</span>
            </template>
            <el-menu-item v-if="can('ip.view')" index="/proxy-ips">IP列表</el-menu-item>
            <el-menu-item v-if="can('asset_group.view')" index="/ip-groups">IP组</el-menu-item>
            <el-menu-item v-if="can('asset_group.view')" index="/asset-groups">资产组</el-menu-item>
            <el-menu-item v-if="can('ip.import')" index="/proxy-ips/import">批量导入</el-menu-item>
          </el-sub-menu>

          <el-menu-item v-if="can('subscription.view')" index="/subscriptions">
            <el-icon><Calendar /></el-icon>
            <template #title>订阅管理</template>
          </el-menu-item>

          <el-sub-menu v-if="can('transaction.view') || can('pricing.view')" index="billing">
            <template #title>
              <el-icon><Wallet /></el-icon>
              <span>财务中心</span>
            </template>
            <el-menu-item v-if="can('transaction.view')" index="/billing/transactions">交易流水</el-menu-item>
            <el-menu-item v-if="can('pricing.view')" index="/billing/pricing">定价规则</el-menu-item>
          </el-sub-menu>

          <el-menu-item v-if="can('user.view')" index="/users">
            <el-icon><UserFilled /></el-icon>
            <template #title>用户管理</template>
          </el-menu-item>

          <el-menu-item v-if="can('user.assign_role')" index="/roles">
            <el-icon><Key /></el-icon>
            <template #title>权限组管理</template>
          </el-menu-item>

          <el-menu-item v-if="can('activity_log.view')" index="/activity-logs">
            <el-icon><Document /></el-icon>
            <template #title>操作日志</template>
          </el-menu-item>

          <el-sub-menu v-if="can('webhook.view') || can('notification.view')" index="notifications">
            <template #title>
              <el-icon><Bell /></el-icon>
              <span>通知管理</span>
            </template>
            <el-menu-item v-if="can('webhook.view')" index="/settings/webhooks">Webhook 配置</el-menu-item>
            <el-menu-item v-if="can('notification.view')" index="/settings/notification-logs">发送记录</el-menu-item>
          </el-sub-menu>

          <el-menu-item v-if="can('setting.manage')" index="/settings/payment-gateways">
            <el-icon><Money /></el-icon>
            <template #title>支付网关</template>
          </el-menu-item>

          <el-menu-item v-if="can('setting.manage')" index="/settings/ny-panels">
            <el-icon><Share /></el-icon>
            <template #title>NY 转发面板</template>
          </el-menu-item>

          <el-menu-item v-if="can('setting.manage')" index="/settings/xui-panels">
            <el-icon><Connection /></el-icon>
            <template #title>3x-ui 中转面板</template>
          </el-menu-item>

          <el-menu-item v-if="can('setting.manage')" index="/settings/dns-monitor">
            <el-icon><Aim /></el-icon>
            <template #title>DNS 容灾监控</template>
          </el-menu-item>

          <el-menu-item v-if="can('setting.view')" index="/settings">
            <el-icon><Setting /></el-icon>
            <template #title>系统设置</template>
          </el-menu-item>
        </el-menu>
      </el-scrollbar>
    </el-aside>

    <!-- Main area -->
    <el-container>
      <!-- Top navbar -->
      <el-header class="navbar">
        <div class="navbar-left">
          <div class="collapse-btn" @click="appStore.toggleSidebar">
            <el-icon :size="18">
              <Fold v-if="!appStore.sidebarCollapsed" />
              <Expand v-else />
            </el-icon>
          </div>
          <el-breadcrumb separator="/">
            <el-breadcrumb-item :to="{ path: '/dashboard' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item v-if="currentTitle">{{ currentTitle }}</el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        <div class="navbar-right">
          <el-dropdown trigger="click" @command="handleCommand">
            <div class="user-avatar-dropdown">
              <div class="avatar-circle">
                {{ (authStore.userName || '管')[0] }}
              </div>
              <span class="username">{{ authStore.userName || '管理员' }}</span>
              <el-icon :size="12"><ArrowDown /></el-icon>
            </div>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="profile">
                  <el-icon><User /></el-icon>个人信息
                </el-dropdown-item>
                <el-dropdown-item command="password">
                  <el-icon><Lock /></el-icon>修改密码
                </el-dropdown-item>
                <el-dropdown-item divided command="logout">
                  <el-icon><SwitchButton /></el-icon>退出登录
                </el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </el-header>

      <!-- Content -->
      <el-main class="main-content">
        <router-view v-slot="{ Component }">
          <transition name="fade-slide" mode="out-in">
            <component :is="Component" />
          </transition>
        </router-view>
      </el-main>
    </el-container>

    <!-- Change password dialog -->
    <el-dialog v-model="passwordDialogVisible" title="修改密码" width="420px">
      <el-form ref="passwordFormRef" :model="passwordForm" :rules="passwordRules" label-width="80px">
        <el-form-item label="旧密码" prop="old_password">
          <el-input v-model="passwordForm.old_password" type="password" show-password />
        </el-form-item>
        <el-form-item label="新密码" prop="new_password">
          <el-input v-model="passwordForm.new_password" type="password" show-password />
        </el-form-item>
        <el-form-item label="确认密码" prop="confirm_password">
          <el-input v-model="passwordForm.confirm_password" type="password" show-password />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="passwordDialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="passwordLoading" @click="submitPassword">确定</el-button>
      </template>
    </el-dialog>
  </el-container>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useAppStore } from '@/stores/app'
import { useAuthStore } from '@/stores/auth'
import { changePassword } from '@/api/auth'

const route = useRoute()
const router = useRouter()
const appStore = useAppStore()
const authStore = useAuthStore()

const activeMenu = computed(() => route.path)
const currentTitle = computed(() => route.meta?.title || '')

// 权限判断
function can(permission) {
  if (!authStore.user) return false
  if (authStore.user.roles?.includes('super_admin')) return true
  return (authStore.user.permissions || []).includes(permission)
}

// Change password
const passwordDialogVisible = ref(false)
const passwordLoading = ref(false)
const passwordFormRef = ref(null)
const passwordForm = ref({
  old_password: '',
  new_password: '',
  confirm_password: '',
})

const passwordRules = {
  old_password: [{ required: true, message: '请输入旧密码', trigger: 'blur' }],
  new_password: [
    { required: true, message: '请输入新密码', trigger: 'blur' },
    { min: 6, message: '密码至少6个字符', trigger: 'blur' },
  ],
  confirm_password: [
    { required: true, message: '请确认新密码', trigger: 'blur' },
    {
      validator: (rule, value, callback) => {
        if (value !== passwordForm.value.new_password) {
          callback(new Error('两次输入的密码不一致'))
        } else {
          callback()
        }
      },
      trigger: 'blur',
    },
  ],
}

async function submitPassword() {
  const valid = await passwordFormRef.value.validate().catch(() => false)
  if (!valid) return
  passwordLoading.value = true
  try {
    await changePassword({
      old_password: passwordForm.value.old_password,
      new_password: passwordForm.value.new_password,
    })
    ElMessage.success('密码修改成功')
    passwordDialogVisible.value = false
    passwordForm.value = { old_password: '', new_password: '', confirm_password: '' }
  } catch {
    // Error handled by interceptor
  } finally {
    passwordLoading.value = false
  }
}

function handleCommand(command) {
  if (command === 'logout') {
    authStore.logout()
    router.push('/login')
  } else if (command === 'password') {
    passwordDialogVisible.value = true
  } else if (command === 'profile') {
    router.push('/settings')
  }
}

if (authStore.isLoggedIn && !authStore.user) {
  authStore.fetchUser()
}
</script>

<style lang="scss" scoped>
.app-layout {
  height: 100vh;
}

// ===== 侧边栏 =====
.sidebar {
  background: linear-gradient(180deg, #1A1A2E 0%, #16213E 100%);
  overflow: hidden;
  transition: width 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  border-right: 1px solid rgba(255, 255, 255, 0.04);

  .logo {
    height: 56px;
    display: flex;
    align-items: center;
    padding: 0 16px;
    gap: 12px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.06);

    .logo-icon {
      width: 34px;
      height: 34px;
      border-radius: 10px;
      background: linear-gradient(135deg, #E8913A, #F2A85A);
      display: flex;
      align-items: center;
      justify-content: center;
      color: #fff;
      font-size: 18px;
      font-weight: 700;
      flex-shrink: 0;
    }

    .logo-text {
      color: #fff;
      font-size: 18px;
      font-weight: 700;
      letter-spacing: 2px;
    }
  }

  .sidebar-menu {
    border-right: none !important;

    :deep(.el-menu-item),
    :deep(.el-sub-menu__title) {
      height: 48px;
      line-height: 48px;
      margin: 2px 8px;
      border-radius: 8px;
      transition: all 0.2s;

      &:hover {
        background: rgba(242, 168, 90, 0.12) !important;
        color: rgba(255, 255, 255, 0.9) !important;
      }
    }

    :deep(.el-menu-item.is-active) {
      background: rgba(242, 168, 90, 0.15) !important;
      color: #F2A85A !important;
      font-weight: 500;

      &::before {
        content: '';
        position: absolute;
        left: 0;
        top: 50%;
        transform: translateY(-50%);
        width: 3px;
        height: 20px;
        border-radius: 0 2px 2px 0;
        background: #F2A85A;
      }
    }

    :deep(.el-sub-menu .el-menu-item) {
      padding-left: 52px !important;
      height: 44px;
      line-height: 44px;
      font-size: 13px;
    }
  }
}

// ===== 顶部导航栏 =====
.navbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #fff;
  border-bottom: 1px solid #F0E6DA;
  padding: 0 24px;
  height: 56px;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.03);

  .navbar-left {
    display: flex;
    align-items: center;
    gap: 16px;

    .collapse-btn {
      width: 36px;
      height: 36px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 8px;
      cursor: pointer;
      color: #4A5568;
      transition: all 0.2s;

      &:hover {
        background: #FEF7F0;
        color: #E8913A;
      }
    }
  }

  .navbar-right {
    .user-avatar-dropdown {
      display: flex;
      align-items: center;
      gap: 8px;
      cursor: pointer;
      padding: 4px 8px;
      border-radius: 8px;
      transition: background 0.2s;

      &:hover {
        background: #FEF7F0;
      }

      .avatar-circle {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        background: linear-gradient(135deg, #E8913A, #F2A85A);
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 14px;
        font-weight: 600;
      }

      .username {
        font-size: 14px;
        color: #4A5568;
        max-width: 100px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
    }
  }
}

// ===== 内容区 =====
.main-content {
  background: #FBF7F2;
  min-height: 0;
  overflow-y: auto;
  padding: 20px;
}

// ===== 过渡动画 =====
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.2s;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

.fade-slide-enter-active {
  transition: all 0.25s ease-out;
}
.fade-slide-leave-active {
  transition: all 0.15s ease-in;
}
.fade-slide-enter-from {
  opacity: 0;
  transform: translateY(8px);
}
.fade-slide-leave-to {
  opacity: 0;
}
</style>
