import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { resolve } from 'path'

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': resolve(__dirname, 'src'),
    },
  },
  // 构建产物输出到 backend/public，与 Laravel 同域部署
  build: {
    outDir: resolve(__dirname, '../backend/public'),
    emptyOutDir: false, // 不清空目录，保留 Laravel 的 index.php 等文件
    assetsDir: 'build', // 静态资源放到 /build/ 子目录避免冲突
  },
  server: {
    port: 3000,
    proxy: {
      '/api': {
        target: 'http://localhost:8000',
        changeOrigin: true,
      },
    },
  },
})
